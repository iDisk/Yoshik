import * as React from "react";
import { Table, Menu, Dropdown, Button, Icon } from "antd";
import { Scene } from "../redux/pre-survey/types";
import { DragDropContext, DragSource, DropTarget } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';

import { BodyRow } from "./BodyRow";

const Column = Table.Column;

interface QuestionsTableProps {
    items: Scene[];
    onDeleteRow: (id: string) => void;
    // onUpdateRow: (item: T) => void;
    onEditRow: (item: Scene) => void;
    // onCreateRow: (item: T) => void;
    onOrderChange: (item: Scene) => void;
}

const rowSource = {
    beginDrag(props: any) {
        return {
            index: props.index,
            record: props.record
        };
    },
};

const rowTarget = {
    drop(props: any, monitor: any) {
        const dragIndex = monitor.getItem().index;
        const record = monitor.getItem().record;
        const hoverIndex = props.index;

        // Don't replace items with themselves
        if (dragIndex === hoverIndex) {
            return;
        }

        // Time to actually perform the action
        props.moveRow(record, dragIndex, hoverIndex);

        // Note: we're mutating the monitor item here!
        // Generally it's better to avoid mutations,
        // but it's good here for the sake of performance
        // to avoid expensive index searches.
        monitor.getItem().index = hoverIndex;
    },
};


const DragableBodyRow = DropTarget('row', rowTarget, (connect, monitor) => ({
    connectDropTarget: connect.dropTarget(),
    isOver: monitor.isOver(),
    sourceClientOffset: monitor.getSourceClientOffset(),
}))(
    DragSource('row', rowSource, (connect, monitor) => ({
        connectDragSource: connect.dragSource(),
        dragRow: monitor.getItem(),
        clientOffset: monitor.getClientOffset(),
        rowSource,
        initialClientOffset: monitor.getInitialClientOffset(),
    }))(BodyRow)
);

class SceneTable extends React.Component<QuestionsTableProps> {
    components = {
        body: {
            row: DragableBodyRow,
        },
    }

    constructor(props: QuestionsTableProps) {
        super(props);
    }


    moveRow = (item: Scene, dragIndex: number, hoverIndex: number) => {
        const newItem = { ...item, ...{ order: hoverIndex + 1 } };
        this.props.onOrderChange(newItem);
    }

    handleActionsMenuClick = (item: Scene, onDelete: any, onEdit: any, e: any) => {
        if (e.key === "delete") {
            onDelete(item._id)
        } else if (e.key === "edit") {
            onEdit(item)
        }
    }

    rowMenu = (record: Scene, onDelete: any, onEdit: any) => {
        return <Menu onClick={(e) => this.handleActionsMenuClick(record, onDelete, onEdit, e)}>
            <Menu.Item key="edit">Edit</Menu.Item>
            <Menu.Item key="delete">Delete</Menu.Item>
        </Menu>
    }

    render() {
        return (
            <Table rowKey="_id"
                className="presurvey-table"
                pagination={false}
                dataSource={this.props.items} indentSize={50}
                components={this.components}
                onRow={(record, index) => ({
                    index,
                    moveRow: this.moveRow,
                    record
                })}>

                <Column width={100} align="center" title="Order" dataIndex="order" key="order" />
                <Column width={800} align="left" title="Title" dataIndex="title" key="title" />
                <Column width={800} align="left" title="Scenario" dataIndex="scenarioTitle" key="scenarioTitle" />
                <Column width={800} align="left" title="Learning Component" dataIndex="learningComponentTitle" key="learningComponentTitle" />
                <Column width={800} align="left" title="Scenario if Yes" dataIndex="nextScenarioIfYesText" key="nextScenarioIfYesText" />
                <Column width={800} align="left" title="Scenario if No" dataIndex="nextScenarioIfNoText" key="nextScenarioIfNoText" />
                <Column
                    width={200}
                    title="Action"
                    align="center"
                    key="action"
                    render={(text, record: Scene) => {
                        return <Dropdown overlay={this.rowMenu(record, this.props.onDeleteRow, this.props.onEditRow)}>
                            <Button>
                                Actions <Icon type="down" />
                            </Button>
                        </Dropdown>
                    }
                    }
                />
            </Table>
        )
    }
}

const GenericTableTableContext = DragDropContext(HTML5Backend)(SceneTable);

export default GenericTableTableContext;