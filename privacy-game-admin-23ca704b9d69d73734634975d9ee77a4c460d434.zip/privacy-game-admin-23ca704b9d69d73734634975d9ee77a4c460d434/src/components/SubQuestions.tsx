import * as React from "react";
import { SubQuestion, Answer } from "../redux/pre-survey/types";
import { FormikProps } from "formik";
import { Col, Form, Input, Button, Slider, Divider, Checkbox } from "antd";

const FormItem = Form.Item;

interface InputProps {
  value: SubQuestion[];
  onChange: any;
  onBlur: any;
  name: string;
  label: string;
  questionType: string;
  numberOfAnswers?: number;
}

interface State {
  marks: {}
}
type Props = FormikProps<InputProps> & InputProps;

export class SubQuestions extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      marks: {
        1: 'Muy De acuerdo',
        10: 'Muy en Desacuerdo'
      }
    }
  }
  // fix 
  addSubquestion = (value: SubQuestion[], maxValue?: number) => {
    const answers: Answer[] = [];
    if (maxValue) {
      for (let i = 1; i <= Number(maxValue); i++) {
        answers.push({
          isLastFixed: false,
          score: 0,
          text: ""
        })
      }
    }
    const newSubQuestions: SubQuestion[] = [...value,
    {
      text: "",
      answers,
      translations: []
    }
    ];
    this.props.onChange(this.props.name, newSubQuestions);
  }
  // fix get marks
  getMarks = (maxValue?: number, answers?: Answer[]) => {
    const result = {};
    if (maxValue) {
      for (let i = 1; i <= maxValue; i++) {
        if (answers) {
          result[i] = answers[i - 1].isLastFixed ? "" : answers[i - 1].text;
        } else {
          result[i] = i;
        }

      }
    }
    return result;
  }

  getMaxValue = (numberOfAnswers?: number, answers?: Answer[]) => {
    if (numberOfAnswers) {
      if (answers) {
        const itemsWithoutLastFixed = answers.filter(s => s.isLastFixed === false);
        return itemsWithoutLastFixed.length;
      } else {
        return numberOfAnswers;
      }
    } return 1;
  }


  getSpan = (numberOfAnswers?: number, answers?: Answer[]) => {
    if (numberOfAnswers) {
      if (answers) {
        const itemsWithoutLastFixed = answers.filter(s => s.isLastFixed === true);
        if (itemsWithoutLastFixed.length > 0) {
          return 14;
        }
      } else {
        return 18;
      }
    } return 18;
  }

  handleLastFixedChange = (
    e: any,
    answerIndex: number,
    subQuestionIndex: number,
    value: Answer[]
  ) => {
    const newAnswers = value.map((element, index) => {
      if (index === answerIndex) {
        element.isLastFixed = e.target.checked
      }
      return element;
    })
    const newSubquestion = { ...this.props.value[subQuestionIndex], answers: newAnswers };
    const newSubquestions = this.props.value.map((item, currentIndex) => {
      if (currentIndex === subQuestionIndex) {
        item = newSubquestion;
      }
      return item;
    });
    this.props.onChange(this.props.name, newSubquestions);
  };
  handleAnswerTextChange = (
    e: any,
    answerIndex: number,
    subQuestionIndex: number,
    value: Answer[]
  ) => {
    const newAnswers = value.map((element, index) => {
      if (index === answerIndex) {
        element.text = e.target.value
      }
      return element;
    })
    const newSubquestion = { ...this.props.value[subQuestionIndex], answers: newAnswers };
    const newSubquestions = this.props.value.map((item, currentIndex) => {
      if (currentIndex === subQuestionIndex) {
        item = newSubquestion;
      }
      return item;
    });
    this.props.onChange(this.props.name, newSubquestions);
  };

  handleAnswerChange = (
    e: any,
    answerIndex: number,
    subQuestionIndex: number,
    value: Answer[]
  ) => {
    const newAnswers = value.map((element, index) => {
      if (index === answerIndex) {
        element.score = Number(e.target.value)
      }
      return element;
    })
    const newSubquestion = { ...this.props.value[subQuestionIndex], answers: newAnswers };
    const newSubquestions = this.props.value.map((item, currentIndex) => {
      if (currentIndex === subQuestionIndex) {
        item = newSubquestion;
      }
      return item;
    });
    this.props.onChange(this.props.name, newSubquestions);
  };

  handleChange = (
    e: any,
    index: number,
    value: SubQuestion[]
  ) => {
    const newSubquestion = { ...value[index], [e.target.name]: e.target.value };
    const newSubquestions = value.map((item, currentIndex) => {
      if (currentIndex === index) {
        return newSubquestion;
      }
      return item;
    });
    this.props.onChange(this.props.name, newSubquestions);
  };
  handleBlur = () => {
    this.props.onBlur(this.props.name, true);
  };

  deleteSubquestion = (index: number, subquestions: SubQuestion[]) => {
    subquestions.splice(index, 1);
    this.props.onChange(this.props.name, subquestions);
  }

  render() {
    const { value, questionType, numberOfAnswers } = this.props;
    return (
      <div>
        {
          value &&
          value.map((subquestion: SubQuestion, index: number) => {
            return (
              <FormItem key={`answer-${index}`}>
                <Divider />
                <Col span={24}>
                  <FormItem label={index === 0 ? "Subquestions" : ""} colon={false} style={{ marginTop: "2px" }}>
                    < Col span={1} offset={1}>
                      <Button className="delete-answer" onClick={() => this.deleteSubquestion(index, value)} icon="delete" style={{ fontSize: "16", color: 'red' }} />
                    </Col>
                    <Col span={21}>
                      <Input
                        size="large"
                        name="text"
                        type="text"
                        onChange={e => this.handleChange(e, index, value)}
                        defaultValue={subquestion.text}
                        value={subquestion.text}
                      />
                    </Col>
                    <Col span={this.getSpan(numberOfAnswers, subquestion.answers)} offset={3} style={{ marginTop: "6px" }}>
                      <Slider marks={this.getMarks(numberOfAnswers, subquestion.answers)} min={1} max={this.getMaxValue(numberOfAnswers, subquestion.answers)} step={1} />
                    </Col>


                    <Col span={18} offset={3} style={{ marginTop: "6px" }}>
                      <div className="horizontal-div">
                        <h5 style={{ marginRight: "5px" }}>Text</h5>
                        {subquestion.answers && subquestion.answers.map((item: Answer, answerIndex) => {
                          return <Col key={`text-${answerIndex}`} span={Math.ceil(22 / subquestion.answers.length)}>
                            <Input
                              size="small"
                              name="text"
                              type="text"
                              onChange={e => this.handleAnswerTextChange(e, answerIndex, index, subquestion.answers)}
                              defaultValue={item.text ? item.text.toString() : ""}
                              value={item.text}
                            />
                          </Col>
                        })}
                      </div>
                    </Col>
                    <Col span={3} offset={18}>
                      <div id="last-fixed-div">
                        {subquestion.answers && subquestion.answers.map((item: Answer, answerIndex) => {
                          return (answerIndex === subquestion.answers.length - 1) &&
                            <FormItem label="Is last fixed" colon={false} className="custom-checkbox">
                              <Checkbox name="isLastFixed"
                                checked={item.isLastFixed}
                                onChange={e => this.handleLastFixedChange(e, answerIndex, index, subquestion.answers)} />
                            </FormItem>
                        })}
                      </div>
                    </Col>
                    <Col span={18} offset={3} style={{ marginTop: "6px" }}>
                      <div className="horizontal-div">
                        <h5 style={{ marginRight: "5px" }}>Score</h5>
                        {subquestion.answers && subquestion.answers.map((item: Answer, answerIndex) => {
                          return <Col key={`score-${answerIndex}`} span={Math.ceil(20 / subquestion.answers.length)}>
                            <Input
                              size="small"
                              name="score"
                              type="text"
                              onChange={e => this.handleAnswerChange(e, answerIndex, index, subquestion.answers)}
                              defaultValue={item.score ? item.score.toString() : ""}
                              value={item.score}
                            />
                          </Col>
                        })}
                      </div>
                    </Col>

                  </FormItem>
                </Col>

              </FormItem>
            );
          })
        }
        {questionType === "matrix" && <Button disabled={!numberOfAnswers} type="primary" onClick={() => this.addSubquestion(value, numberOfAnswers)}>Add</Button>}
      </div >

    );
  }
}
