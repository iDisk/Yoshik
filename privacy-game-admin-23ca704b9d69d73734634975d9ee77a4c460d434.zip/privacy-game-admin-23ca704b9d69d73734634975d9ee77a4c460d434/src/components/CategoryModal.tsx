import * as React from "react";
import { Form, Input, Modal, Button } from "antd";
import {
  Formik,
  FormikErrors,
  Field,
  withFormik,
  FieldProps,
  FormikProps
} from "formik";

import {
  Category
} from "../redux/pre-survey/types";

const FormItem = Form.Item;

interface ModalProps {
  onSubmit: (values: FormValues) => void;
  onCancel: () => void;
  visible: boolean;
  loading: boolean;
}

interface InputProps {
  label: string;
  placeHolder?: string;
}

type FormValues = Category;

type InputOwnProps = FieldProps<FormValues> & InputProps;

export const TextField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <Input type="text" {...field} placeholder={placeHolder} />
    </FormItem>
  );
};

const initialValues: FormValues = {
  text: "",
  _id: "",
  value: "",
  key: ""
};

type AllProps = FormikProps<FormValues> & ModalProps;

class CategoryForm extends React.Component<AllProps> {
  constructor(props: AllProps) {
    super(props);
  }
  onSubmit = (values: FormValues) => {
    this.props.onSubmit(values);
  };

  render() {
    const { visible, onCancel, loading } = this.props;
    return (
      <Modal
        visible={visible}
        title="Add a category"
        okText="Save Category"
        onCancel={onCancel}
        footer={[
          <Button key="cancel" onClick={onCancel}>
            Cancel
          </Button>,
          <Button
            form="CategoryForm"
            key="submit"
            htmlType="submit"
            type="primary"
            loading={loading}
          >
            Submit
          </Button>
        ]}
      >
        <Formik
          initialValues={initialValues}
          onSubmit={this.onSubmit}
          enableReinitialize={true}
          validate={(items: FormValues) => {
            const errors: FormikErrors<FormValues> = {};
            if (!items.text) {
              errors.text = "Required";
            }
            return errors;
          }}
          render={({
            handleSubmit,
            setFieldValue,
            setFieldTouched,
            values
          }: FormikProps<FormValues>) => (
              <Form id="CategoryForm" onSubmit={handleSubmit}>
                <Field
                  name="text"
                  render={(innerProps: any) => (
                    <TextField
                      {...innerProps}
                      label="Text"
                      placeHolder="Category"
                    />
                  )}
                />
              </Form>
            )}
        />
      </Modal>
    );
  }
}

const formikEnhancer = withFormik<ModalProps, {}, {}>({
  mapPropsToValues: props => ({}),
  handleSubmit: (values: FormValues, { setSubmitting }) => {
    setTimeout(() => {
      alert(JSON.stringify(values, null, 2));
      setSubmitting(false);
    }, 1000);
  },
  displayName: "CategoryForm"
})(CategoryForm);

export default formikEnhancer;
