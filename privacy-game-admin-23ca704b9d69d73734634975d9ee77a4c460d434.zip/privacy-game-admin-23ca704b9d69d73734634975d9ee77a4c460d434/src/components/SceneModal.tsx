import * as React from "react";
import { Form, Input, Modal, Button } from "antd";
import {
  Formik,
  FormikErrors,
  Field,
  withFormik,
  FieldProps,
  FormikProps
} from "formik";

import {
  Scene, LearningComponent, Scenario
} from "../redux/pre-survey/types";
import { SelectScenario } from "./SelectScenario";

const FormItem = Form.Item;
const FORM_TITLE = "SceneForm";

interface ModalProps {
  onSubmit: (values: FormValues) => void;
  onCancel: () => void;
  visible: boolean;
  loading: boolean;
  selectedItem?: Scene
  learningComponents: LearningComponent[];
  scenarios: Scenario[];
}

interface InputProps {
  label: string;
  placeHolder?: string;
}

type FormValues = Scene;

type InputOwnProps = FieldProps<FormValues> & InputProps;

export const TextField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <Input size="large" type="text" {...field} placeholder={placeHolder} />
    </FormItem>
  );
};

const initialValues: FormValues = {
  _id: "",
  title: "",
  scenarioId: "",
  learningComponentId: "",
  nextScenarioIfYesId: "",
  nextScenarioIfNoId: "",
  order: 0,
};

type AllProps = FormikProps<FormValues> & ModalProps;

class SceneModal extends React.Component<AllProps> {
  constructor(props: AllProps) {
    super(props);
  }

  onSubmit = (values: FormValues) => {

    this.props.onSubmit(values);
  }

  render() {
    const { visible, onCancel, selectedItem, loading } = this.props;
    return (
      <Modal
        width={1000}
        visible={visible}
        title={selectedItem ? `Edit` : "Add Scene"}
        okText="Save"
        onCancel={onCancel}
        footer={[
          <Button key="cancel" onClick={onCancel}>
            Cancel
          </Button>,
          <Button
            form={FORM_TITLE}
            key="submit"
            htmlType="submit"
            type="primary"
            loading={loading}
          >
            Submit
          </Button>
        ]}
      >
        <Formik
          initialValues={selectedItem || initialValues}
          onSubmit={this.onSubmit}
          enableReinitialize={true}
          validate={(items: FormValues) => {
            const errors: FormikErrors<FormValues> = {};
            if (!items.title) {
              errors.title = "Required";
            }
            if (!items.learningComponentId) {
              errors.learningComponentId = "Required";
            }
            if (!items.scenarioId) {
              errors.scenarioId = "Required";
            }
            if (!items.nextScenarioIfYesId) {
              errors.nextScenarioIfYesId = "Required";
            }
            if (!items.nextScenarioIfNoId) {
              errors.nextScenarioIfNoId = "Required";
            }
            return errors;
          }}
          render={({
            handleSubmit,
            setFieldValue,
            setFieldTouched,
            values
          }: FormikProps<FormValues>) => (
              <Form id={FORM_TITLE} onSubmit={handleSubmit}>
                <Field
                  name="title"
                  render={(innerProps: any) => (
                    <TextField
                      {...innerProps}
                      label="Title"
                      placeHolder="Title text"
                    />
                  )}
                />
                <Field
                  render={({ field, form }: any) => {
                    return (
                      <SelectScenario
                        {...field}
                        form={form}
                        name="learningComponentId"
                        label="Learning Component"
                        placeHolder="Select a learning component"
                        value={values.learningComponentId}
                        onChange={setFieldValue}
                        onBlur={setFieldTouched}
                        options={this.props.learningComponents}
                      />
                    );
                  }}
                />

                <Field
                  render={({ field, form }: any) => {
                    return (
                      <SelectScenario
                        {...field}
                        name="scenarioId"
                        form={form}
                        label="Scenario"
                        placeHolder="Select scenario"
                        value={values.scenarioId}
                        onChange={setFieldValue}
                        onBlur={setFieldTouched}
                        options={this.props.scenarios}
                      />
                    );
                  }}
                />

                <Field
                  render={({ field, form }: any) => {
                    return (
                      <SelectScenario
                        {...field}
                        form={form}
                        name="nextScenarioIfYesId"
                        label="Next Scenario if Yes"
                        placeHolder="Select scenario"
                        value={values.nextScenarioIfYesId}
                        onChange={setFieldValue}
                        onBlur={setFieldTouched}
                        options={this.props.scenarios}
                      />
                    );
                  }}
                />

                <Field
                  render={({ field, form }: any) => {
                    return (
                      <SelectScenario
                        {...field}
                        name="nextScenarioIfNoId"
                        form={form}
                        label="Next Scenario if No"
                        placeHolder="Select scenario"
                        value={values.nextScenarioIfNoId}
                        onChange={setFieldValue}
                        onBlur={setFieldTouched}
                        options={this.props.scenarios}
                      />
                    );
                  }}
                />

              </Form>
            )}
        />
      </Modal>
    );
  }
}

const formikEnhancer = withFormik<ModalProps, {}, {}>({
  mapPropsToValues: props => ({}),
  handleSubmit: (values: FormValues, { setSubmitting }) => {
    const payload = {
      ...values
    };
    setTimeout(() => {
      alert(JSON.stringify(payload, null, 2));
      setSubmitting(false);
    }, 1000);
  },
  displayName: FORM_TITLE
})(SceneModal);

export default formikEnhancer;
