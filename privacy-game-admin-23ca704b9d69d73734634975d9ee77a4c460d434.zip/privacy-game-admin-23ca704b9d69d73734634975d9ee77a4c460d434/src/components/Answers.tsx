import * as React from "react";
import { Answer } from "../redux/pre-survey/types";
import { FormikProps } from "formik";
import { Col, Form, Divider, Input, Button, Checkbox } from "antd";

const FormItem = Form.Item;

interface InputProps {
  value: Answer[];
  onChange: any;
  onBlur: any;
  name: string;
  label: string;
  questionType: string;
}

type Props = FormikProps<InputProps> & InputProps;

export class Answers extends React.Component<Props> {
  addAnswer = (value: Answer[]) => {
    const newAnswers = [...value,
    {
      text: "",
      score: 0,
      key: `option${value.length}`,
      isLastFixed: false
    }
    ];
    this.props.onChange(this.props.name, newAnswers);
  }

  handleChange = (
    e: any,
    index: number,
    value: Answer[]
  ) => {
    const newValue = e.target.name === "isLastFixed" ? e.target.checked : e.target.value;
    const newAnswer = { ...value[index], [e.target.name]: newValue };
    const newAnswers = value.map((item, currentIndex) => {
      if (currentIndex === index) {
        item = newAnswer;
      }
      return item;
    });
    this.props.onChange(this.props.name, newAnswers);
  };
  handleBlur = () => {
    this.props.onBlur(this.props.name, true);
  };

  deleteAnswer = (index: number, answers: Answer[]) => {
    answers.splice(index, 1);
    this.props.onChange(this.props.name, answers);
  }

  render() {
    const { value, questionType } = this.props;
    return (
      <div>
        {value && value.length > 0 && <Divider> Answers</Divider>}
        {value &&
          value.map((answer: Answer, index: number) => {
            return (
              <FormItem key={`answer-${index}`}>
                <Col span={16}>
                  <FormItem label={index === 0 ? "Text" : ""} colon={false} style={{ marginTop: "2px" }}>
                    {(questionType === "multiple" || questionType === "range") &&
                      < Col span={3}>
                        <Button className="delete-answer" onClick={() => this.deleteAnswer(index, value)} icon="delete" style={{ fontSize: "16", color: 'red' }} />
                      </Col>}
                    <Col span={(questionType === "multiple" || questionType === "range") ? 21 : 24}>
                      <Input
                        size="large"
                        name="text"
                        type="text"
                        onChange={e => this.handleChange(e, index, value)}
                        defaultValue={answer.text}
                        value={answer.text}
                      />
                    </Col>
                  </FormItem>
                </Col>
                <Col span={4} offset={1}>
                  <FormItem label={index === 0 ? "Score" : ""} colon={false}>
                    <Input
                      size="large"
                      type="text"
                      name="score"
                      onChange={e => this.handleChange(e, index, value)}
                      defaultValue={`${answer.score && answer.score.toString()}`}
                      value={answer.score}
                    />
                  </FormItem>
                </Col>
                <Col span={2} style={{ textAlign: "center" }} offset={1}>
                  <FormItem label={index === 0 ? "Is last fixed" : ""} colon={false}>
                    <Checkbox name="isLastFixed"
                      checked={answer.isLastFixed}
                      onChange={e => this.handleChange(e, index, value)} />
                  </FormItem>
                </Col>
              </FormItem>
            );
          })}
        {(questionType === "multiple" || questionType === "range" || questionType === "yesno" || questionType === "boolean") && <Button style={{ marginTop: "6px" }} type="primary" onClick={() => this.addAnswer(value)}>Add</Button>}

      </div>

    );
  }
}
