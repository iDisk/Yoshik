import * as React from "react";
import { Form, Input, Modal, Button } from "antd";
import {
  Formik,
  FormikErrors,
  Field,
  withFormik,
  FieldProps,
  FormikProps
} from "formik";

import { Select } from "./Select";

import {
  LearningComponent,
  Scenario,
  Translation,
  Term
} from "../redux/pre-survey/types";

const FormItem = Form.Item;
const FORM_TITLE = "ItemTranslationForm";
const { TextArea } = Input;

interface ModalProps {
  onSubmit: (values: LearningComponent | Scenario | Term) => void;
  onCancel: () => void;
  visible: boolean;
  loading: boolean;
  selectedItem?: LearningComponent | Scenario | Term
  selectedTranslation?: Translation;
}

interface InputProps {
  label: string;
  placeHolder?: string;
}

type FormValues = Translation

type InputOwnProps = FieldProps<FormValues> & InputProps;

const languages = [
  { text: "Spanish MX", id: "mx", value: "mx", key: "mx" },
  { text: "Spanisn ES", id: "es", value: "es", key: "es" }
];

export const TextAreaField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <TextArea autosize={{ minRows: 3, maxRows: 10 }} {...field} placeholder={placeHolder} />
    </FormItem>
  );
};
export const TextField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <Input size="large" type="text" {...field} placeholder={placeHolder} />
    </FormItem>
  );
};

const initialValues: FormValues = {
  _id: "",
  text: "",
  language: ""
};

type AllProps = FormikProps<FormValues> & ModalProps;

class GenericTranslationModal extends React.Component<AllProps> {
  constructor(props: AllProps) {
    super(props);
  }
  onSubmit = (values: FormValues) => {
    if (this.props.selectedItem) {
      if (this.props.selectedTranslation) {
        const newTranslations = this.props.selectedItem.translations.map((item) => {
          if (item._id === this.props.selectedTranslation!._id) {
            if (values.language) {
              item.language = values.language;
              item.text = values.text;
            }
          }
          return item;
        })
        const newQuestion = { ...this.props.selectedItem, ...{ translations: newTranslations } };
        this.props.onSubmit(newQuestion as any);
      } else {
        this.props.selectedItem.translations = this.props.selectedItem.translations || [];
        const newQuestion = {
          ...this.props.selectedItem, ...{
            translations: [...this.props.selectedItem.translations, {
              text: values.text,
              language: values.language
            }]
          }
        };
        this.props.onSubmit(newQuestion as any);
      }

    }
  }

  render() {
    const { visible, onCancel, selectedItem, selectedTranslation, loading } = this.props;
    return (
      <Modal
        width={1000}
        visible={visible}
        title={(selectedTranslation && selectedItem) ? `Edit ${selectedItem.title}` : "Add Translation"}
        okText="Save"
        onCancel={onCancel}
        footer={[
          <Button key="cancel" onClick={onCancel}>
            Cancel
          </Button>,
          <Button
            form={FORM_TITLE}
            key="submit"
            htmlType="submit"
            type="primary"
            loading={loading}
          >
            Submit
          </Button>
        ]}
      >
        <Formik
          initialValues={selectedTranslation || initialValues}
          onSubmit={this.onSubmit}
          enableReinitialize={true}
          validate={(items: FormValues) => {
            const errors: FormikErrors<FormValues> = {};
            if (!items.text) {
              errors.text = "Required";
            }
            if (!items.language) {
              errors.text = "Required";
            }
            return errors;
          }}
          render={({
            handleSubmit,
            setFieldValue,
            setFieldTouched,
            values
          }: FormikProps<FormValues>) => (
              <Form id={FORM_TITLE} onSubmit={handleSubmit}>
                {<h3>{selectedItem!.text}</h3>}
                <Field
                  render={({ field, form }: any) => {
                    return (
                      <Select
                        {...field}
                        form={form}
                        name="language"
                        label="Language"
                        placeHolder="Select a language"
                        value={values.language}
                        onChange={setFieldValue}
                        onBlur={setFieldTouched}
                        options={languages}
                      />
                    );
                  }}
                />
                <Field
                  name="text"
                  render={(innerProps: any) => (
                    <TextAreaField
                      {...innerProps}
                      label="Text"
                      placeHolder="Question text"
                    />
                  )}
                />
              </Form>
            )}
        />
      </Modal>
    );
  }
}

const formikEnhancer = withFormik<ModalProps, {}, {}>({
  mapPropsToValues: props => ({}),
  handleSubmit: (values: FormValues, { setSubmitting }) => {
    const payload = {
      ...values
    };
    setTimeout(() => {
      alert(JSON.stringify(payload, null, 2));
      setSubmitting(false);
    }, 1000);
  },
  displayName: FORM_TITLE
})(GenericTranslationModal);

export default formikEnhancer;
