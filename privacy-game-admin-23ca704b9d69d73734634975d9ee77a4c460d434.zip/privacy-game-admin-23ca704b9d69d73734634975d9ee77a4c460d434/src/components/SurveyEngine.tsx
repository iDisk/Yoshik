import * as React from "react";
import { connect } from "react-redux";
import { Button } from "antd";

import { Question, Category, Answer, Translation, SubQuestion } from "../redux/pre-survey/types";
import { QuestionsTable, QuestionModal, TranslationModal, EditAnswerModal, EditSubQuestionModal, SubQuestionTranslationModal } from ".";
import { ApplicationState } from "../redux/reducers";
import { bindActionCreators, Dispatch } from "redux";
import { getCategories } from "../redux/categories/actions";
import { createQuestion, deleteQuestion, deleteAnswer, deleteSubQuestionAnswer, deleteSubQuestion, saveQuestion, deleteQuestionTranslation, deleteAnswerTranslation, getQuestions, deleteSubQuestionTranslation } from "../redux/pre-survey/actions";

interface Props {
  title: string;
  loading?: boolean;
  questions: Question[];
  getCategories: any;
  categories: Category[];
  createQuestion: any;
  deleteQuestion: any
  deleteAnswer: any
  deleteSubQuestion: any
  saveQuestion: any
  deleteQuestionTranslation: any
  deleteAnswerTranslation: any;
  type: string;
  getQuestions: any;
  deleteSubQuestionTranslation: any;
  deleteSubQuestionAnswer: any;
}

interface State {
  showModal: boolean;
  loading: boolean;
  loadingTranslationModal: boolean;
  showTranslationModal: boolean;
  loadingEditAnswerModal: boolean;
  showEditAnswerModal: boolean;
  showEditSubQuestionModal: boolean;
  loadingEditSubQuestionModal: boolean;
  showSubQuestionTranslationModal: boolean;
  loadingSubQuestionTranslationModal: boolean;
  selectedQuestion?: Question;
  selectedAnswer?: Answer;
  currentQuestion?: Question;
  currentTranslation?: Translation
  selectedTranslation?: Translation
  selectedSubQuestion?: SubQuestion
  selectedSubQuestionTranslation?: Translation;
  currentSubQuestion?: SubQuestion
}

class SurveyEngine extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      showModal: false,
      loading: false,
      loadingTranslationModal: false,
      showTranslationModal: false,
      selectedQuestion: undefined,
      loadingEditAnswerModal: false,
      showEditAnswerModal: false,
      selectedAnswer: undefined,
      currentQuestion: undefined,
      currentTranslation: undefined,
      selectedTranslation: undefined,
      showEditSubQuestionModal: false,
      loadingEditSubQuestionModal: false,
      showSubQuestionTranslationModal: false,
      selectedSubQuestionTranslation: undefined,
      loadingSubQuestionTranslationModal: false,
      currentSubQuestion: undefined
    };
  }

  componentDidMount() {
    this.props.getQuestions(this.props.type);
    this.props.getCategories();
  }

  openQuestionModal = (question?: Question) => {
    this.setState({
      showModal: true,
      selectedQuestion: question
    });
  };

  openTranslationModal = (question: Question, translation?: Translation) => {
    this.setState({
      showTranslationModal: true,
      selectedQuestion: question,
      selectedTranslation: translation
    });
  };

  openSubQuestionTranslationModal = (question: Question, subQuestion: SubQuestion, translation?: Translation) => {
    this.setState({
      showSubQuestionTranslationModal: true,
      selectedQuestion: question,
      selectedSubQuestion: subQuestion,
      selectedSubQuestionTranslation: translation
    });
  };

  openEditAnswerModal = (question: Question, answer: Answer, translation?: Translation) => {
    this.setState({
      showEditAnswerModal: true,
      selectedAnswer: answer,
      currentQuestion: question,
      currentTranslation: translation
    });
  };

  openEditSubQuestionModal = (question: Question, subQuestion: SubQuestion, translation?: Translation) => {
    this.setState({
      showEditSubQuestionModal: true,
      selectedSubQuestion: subQuestion,
      currentQuestion: question,
      currentTranslation: translation
    });
  };
  updateQuestion = (values: any) => {
    values.source = this.props.type;
    this.props.saveQuestion(values);
    this.closeQuestionModal();
  };

  saveQuestion = (values: any) => {
    values.source = this.props.type;
    if (this.state.selectedQuestion) {
      this.props.saveQuestion(values);
    } else {
      this.props.createQuestion(values);
    }
    this.closeQuestionModal();
  };
  saveTranslation = (values: any) => {
    this.props.saveQuestion(values);
    this.closeTranslationModal();
  };

  saveSubQuestionTranslation = (values: any) => {
    values.source = this.props.type;
    this.props.saveQuestion(values);
    this.closeSubQuestionTranslationModal();
  };
  saveAnswerEdit = (values: any) => {
    values.source = this.props.type;
    this.props.saveQuestion(values);
    this.closeEditAnswerModal();
  }

  saveSubQuestionEdit = (values: any) => {
    values.source = this.props.type;
    this.props.saveQuestion(values);
    this.closeSubQuestionModal();
  }

  closeEditAnswerModal = () => {
    this.resetState(() => {
      this.setState({
        showEditAnswerModal: false
      });
    })
  };

  closeSubQuestionModal = () => {
    this.resetState(() => {
      this.setState({
        showEditSubQuestionModal: false,
        showSubQuestionTranslationModal: false
      });
    })
  };

  closeQuestionModal = () => {
    this.resetState(() => {
      this.setState({
        showModal: false
      });
    })
  };
  resetState = (callback: any) => {
    this.setState({
      selectedSubQuestion: undefined,
      selectedSubQuestionTranslation: undefined,
      currentQuestion: undefined,
      currentSubQuestion: undefined,
      currentTranslation: undefined,
      selectedAnswer: undefined,
      selectedTranslation: undefined,
      selectedQuestion: undefined
    }, callback());
  }
  closeSubQuestionTranslationModal = () => {
    this.resetState(() => {
      this.setState({
        showSubQuestionTranslationModal: false
      });
    })
  };
  closeTranslationModal = () => {
    this.resetState(() => {
      this.setState({
        showTranslationModal: false
      });
    })
  };

  openEditSubQuestionAnswerModal = (question: Question, subQuestion: SubQuestion, answer?: Answer, translation?: Translation) => {
    this.setState({
      showEditAnswerModal: true,
      selectedSubQuestion: subQuestion,
      currentQuestion: question,
      currentSubQuestion: subQuestion,
      currentTranslation: translation,
      selectedAnswer: answer
    });
  };

  render() {
    const { showModal, loading, loadingTranslationModal, showTranslationModal, selectedQuestion, selectedAnswer, loadingEditAnswerModal, showEditAnswerModal,
      currentQuestion, currentTranslation, selectedTranslation, showEditSubQuestionModal, loadingEditSubQuestionModal, selectedSubQuestion, showSubQuestionTranslationModal,
      loadingSubQuestionTranslationModal, selectedSubQuestionTranslation, currentSubQuestion } = this.state;
    return (
      <div>
        <h1>{this.props.title}</h1>
        <EditAnswerModal
          onSubmit={this.saveAnswerEdit}
          onCancel={this.closeEditAnswerModal}
          visible={showEditAnswerModal}
          loading={loadingEditAnswerModal}
          selectedAnswer={selectedAnswer}
          currentQuestion={currentQuestion}
          currentTranslation={currentTranslation}
          currentSubQuestion={currentSubQuestion}
        />
        <EditSubQuestionModal
          onSubmit={this.saveSubQuestionEdit}
          onCancel={this.closeSubQuestionModal}
          visible={showEditSubQuestionModal}
          loading={loadingEditSubQuestionModal}
          selectedSubQuestion={selectedSubQuestion}
          currentQuestion={currentQuestion}
        />
        <QuestionModal
          onSubmit={this.saveQuestion}
          onCancel={this.closeQuestionModal}
          visible={showModal}
          loading={loading}
          categories={this.props.categories}
          selectedQuestion={selectedQuestion}
        />
        <TranslationModal onSubmit={this.saveTranslation} onCancel={this.closeTranslationModal}
          visible={showTranslationModal}
          loading={loadingTranslationModal}
          selectedQuestion={selectedQuestion}
          selectedTranslation={selectedTranslation}
        />
        <SubQuestionTranslationModal onSubmit={this.saveSubQuestionTranslation} onCancel={this.closeSubQuestionModal}
          visible={showSubQuestionTranslationModal}
          loading={loadingSubQuestionTranslationModal}
          selectedQuestion={selectedQuestion}
          selectedSubQuestion={selectedSubQuestion}
          selectedTranslation={selectedSubQuestionTranslation}
        />
        <div style={{ marginBottom: 16 }}>
          <Button type="primary" onClick={() => this.openQuestionModal(undefined)}>
            Add Question
          </Button>
        </div>
        <QuestionsTable questions={this.props.questions}
          onDelete={this.props.deleteQuestion}
          onAnswerDelete={this.props.deleteAnswer}
          onQuestionTranslationDelete={this.props.deleteQuestionTranslation}
          onEditAnswer={(question: Question, answer: Answer, translation?: Translation) => this.openEditAnswerModal(question, answer, translation)}
          onEditTranslation={(question: Question, translation: Translation) => this.openTranslationModal(question, translation)}
          onSubquestionTranslationClick={(question: Question, subQuestion: SubQuestion) => this.openSubQuestionTranslationModal(question, subQuestion)}
          onEditSubQuestionTranslation={(question: Question, subQuestion: SubQuestion, translation: Translation) => this.openSubQuestionTranslationModal(question, subQuestion, translation)}
          onDeleteSubQuestionTranslation={this.props.deleteSubQuestionTranslation}
          onDeleteSubQuestionAnswer={this.props.deleteSubQuestionAnswer}
          onEditSubquestion={(question: Question, subQuestion: SubQuestion, translation?: Translation) => this.openEditSubQuestionModal(question, subQuestion, translation)}
          onEditSubquestionAnswer={(question: Question, subQuestion: SubQuestion, answer?: Answer, translation?: Translation) => this.openEditSubQuestionAnswerModal(question, subQuestion, answer, translation)}
          onSubQuestionDelete={this.props.deleteSubQuestion}
          onAnswerTranslationDelete={this.props.deleteAnswerTranslation}
          onOrderChange={this.updateQuestion}
          onEditQuestion={(question: Question) => this.openQuestionModal(question)}
          onTranslationClick={(question: Question) => this.openTranslationModal(question)} />
      </div>
    );
  }
}

const mapStateToProps = (state: ApplicationState) => {
  return {
    categories: state.categoryState.categories
  };
};

const mapDispatchToProps = (dispatch: Dispatch) => {
  return bindActionCreators(
    {
      getQuestions,
      getCategories,
      createQuestion,
      deleteQuestion,
      deleteAnswer,
      saveQuestion,
      deleteQuestionTranslation,
      deleteAnswerTranslation,
      deleteSubQuestion,
      deleteSubQuestionTranslation,
      deleteSubQuestionAnswer
    },
    dispatch
  );
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SurveyEngine);
