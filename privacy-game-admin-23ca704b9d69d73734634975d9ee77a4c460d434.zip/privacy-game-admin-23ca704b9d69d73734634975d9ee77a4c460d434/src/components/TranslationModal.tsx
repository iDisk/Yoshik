import * as React from "react";
import { Form, Input, Modal, Button } from "antd";
import {
  Formik,
  FormikErrors,
  Field,
  withFormik,
  FieldProps,
  FormikProps
} from "formik";

import {
  Translation, Question
} from "../redux/pre-survey/types";

import { Select } from "./Select";

const FormItem = Form.Item;

interface ModalProps {
  onSubmit: (values: FormValues) => void;
  onCancel: () => void;
  visible: boolean;
  loading: boolean;
  selectedQuestion?: Question
  selectedTranslation?: Translation
}

interface InputProps {
  label: string;
  placeHolder?: string;
}

const languages = [
  { text: "Spanish MX", id: "mx", value: "mx", key: "mx" },
  { text: "Spanisn ES", id: "es", value: "es", key: "es" }
];

type FormValues = Translation;

type InputOwnProps = FieldProps<FormValues> & InputProps;

export const TextField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <Input type="text" {...field} placeholder={placeHolder} />
    </FormItem>
  );
};

const initialValues: FormValues = {
  _id: "",
  text: "",
  language: "",
  answers: []
};

type AllProps = FormikProps<FormValues> & ModalProps;
const FORM = "TranslationForm";

class TranslationForm extends React.Component<AllProps> {
  constructor(props: AllProps) {
    super(props);
  }
  onSubmit = (values: FormValues) => {
    if (this.props.selectedQuestion) {
      if (this.props.selectedTranslation) {
        const newTranslations = this.props.selectedQuestion.translations.map((item) => {
          if (item._id === this.props.selectedTranslation!._id) {
            item.language = values.language;
            item.text = values.text;
          }
          return item;
        })
        const newQuestion = { ...this.props.selectedQuestion, ...{ translations: newTranslations } };
        this.props.onSubmit(newQuestion as any);
      } else {
        delete values._id;
        values.answers = this.props.selectedQuestion.answers;
        values.answers = values.answers.map(item => {
          delete item._id
          return item;
        });
        this.props.selectedQuestion.translations = this.props.selectedQuestion.translations || [];
        const newQuestion = { ...this.props.selectedQuestion, ...{ translations: [...this.props.selectedQuestion.translations, values] } };
        this.props.onSubmit(newQuestion as any);
      }

    }
  };

  render() {
    const { visible, onCancel, loading, selectedQuestion, selectedTranslation } = this.props;
    return (
      <Modal
        visible={visible}
        title={selectedTranslation ? "Edit translation" : "Add translation"}
        okText="Save Translation"
        onCancel={onCancel}
        footer={[
          <Button key="cancel" onClick={onCancel}>
            Cancel
          </Button>,
          <Button
            form={FORM}
            key="submit"
            htmlType="submit"
            type="primary"
            loading={loading}
          >
            Submit
          </Button>
        ]}
      >
        <Formik
          initialValues={selectedTranslation || initialValues}
          onSubmit={this.onSubmit}
          enableReinitialize={true}
          validate={(items: FormValues) => {
            const errors: FormikErrors<FormValues> = {};
            if (!items.text) {
              errors.text = "Required";
            }
            if (!items.language) {
              errors.language = "Required";
            }
            return errors;
          }}
          render={({
            handleSubmit,
            setFieldValue,
            setFieldTouched,
            values
          }: FormikProps<FormValues>) => (
              <Form id={FORM} onSubmit={handleSubmit}>
                {!selectedTranslation && <h3>{selectedQuestion!.text}</h3>}
                <Field
                  render={({ field, form }: any) => {
                    return (
                      <Select
                        {...field}
                        form={form}
                        name="language"
                        label="Language"
                        placeHolder="Select a language"
                        value={values.language}
                        onChange={setFieldValue}
                        onBlur={setFieldTouched}
                        options={languages}
                      />
                    );
                  }}
                />
                <Field
                  name="text"
                  render={(innerProps: any) => (
                    <TextField
                      {...innerProps}
                      label="Text"
                      placeHolder="Question text"
                    />
                  )}
                />
              </Form>
            )}
        />
      </Modal>
    );
  }
}

const formikEnhancer = withFormik<ModalProps, {}, {}>({
  mapPropsToValues: props => ({}),
  handleSubmit: (values: FormValues, { setSubmitting }) => {
    const payload = {
      ...values
    };
    setTimeout(() => {
      alert(JSON.stringify(payload, null, 2));
      setSubmitting(false);
    }, 1000);
  },
  displayName: FORM
})(TranslationForm);

export default formikEnhancer;
