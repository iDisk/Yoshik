import * as React from "react";
import { Form, Input, Modal, Button } from "antd";
import {
  Formik,
  FormikErrors,
  Field,
  withFormik,
  FieldProps,
  FormikProps
} from "formik";

import {
  Question, SubQuestion, Translation
} from "../redux/pre-survey/types";

const FormItem = Form.Item;

interface ModalProps {
  onSubmit: (values: FormValues) => void;
  onCancel: () => void;
  visible: boolean;
  loading: boolean;
  selectedSubQuestion?: SubQuestion
  currentQuestion?: Question
  currentTranslation?: Translation
}

interface InputProps {
  label: string;
  placeHolder?: string;
  value: string;
}

type FormValues = SubQuestion;

type InputOwnProps = FieldProps<FormValues> & InputProps;

export const TextField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder,
  value
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <Input type="text" {...field} placeholder={placeHolder} />
    </FormItem>
  );
};

type AllProps = FormikProps<FormValues> & ModalProps;
const FORM = "EditAnswerForm";

class EditSubQuestionModal extends React.Component<AllProps> {
  constructor(props: AllProps) {
    super(props);
  }

  onSubmit = (values: FormValues) => {
    if (this.props.selectedSubQuestion && this.props.currentQuestion) {
      if (this.props.currentTranslation) {
        const newAnswers = this.props.currentTranslation.answers!.map((item) => {
          if (item._id === this.props.selectedSubQuestion!._id) {
            item.text = values.text;
          }
          return item;
        })
        const newTranslations = this.props.currentQuestion.translations.map((item) => {
          if (item._id === this.props.currentTranslation!._id) {
            item.answers = newAnswers;
          }
          return item;
        })
        const newQuestion = { ...this.props.currentQuestion, ...{ translations: newTranslations } };
        this.props.onSubmit(newQuestion as any);
      } else {
        if (this.props.currentQuestion.subQuestions) {
          const newSubQuestions = this.props.currentQuestion.subQuestions.map((item) => {
            if (item._id === this.props.selectedSubQuestion!._id) {
              item.text = values.text;
            }
            return item;
          })

          const newQuestion = { ...this.props.currentQuestion, ...{ subQuestions: newSubQuestions } };
          this.props.onSubmit(newQuestion as any);
        }
      }
    }
  };

  render() {
    const { visible, onCancel, loading, selectedSubQuestion } = this.props;
    return (
      <Modal
        visible={visible}
        title="Edit SubQuestion"
        okText="Save SubQuestion"
        onCancel={onCancel}
        footer={[
          <Button key="cancel" onClick={onCancel}>
            Cancel
          </Button>,
          <Button
            form={FORM}
            key="submit"
            htmlType="submit"
            type="primary"
            loading={loading}
          >
            Submit
          </Button>
        ]}
      >
        <Formik
          initialValues={selectedSubQuestion}
          enableReinitialize={true}
          onSubmit={this.onSubmit}
          validate={(items: FormValues) => {
            const errors: FormikErrors<FormValues> = {};
            if (!items.text) {
              errors.text = "Required";
            }
            return errors;
          }}
          render={({
            handleSubmit
          }: FormikProps<FormValues>) => (

              <Form id={FORM} onSubmit={handleSubmit}>
                <Field
                  name="text"
                  render={(innerProps: any) => (
                    <TextField
                      {...innerProps}
                      label="Text"
                      placeHolder="Answer text"
                    />
                  )}
                />
              </Form>
            )}
        />
      </Modal>
    );
  }
}

const formikEnhancer = withFormik<ModalProps, {}, {}>({
  mapPropsToValues: props => ({}),
  handleSubmit: (values: FormValues, { setSubmitting }) => {
    const payload = {
      ...values
    };
    setTimeout(() => {
      alert(JSON.stringify(payload, null, 2));
      setSubmitting(false);
    }, 1000);
  },
  displayName: FORM
})(EditSubQuestionModal);

export default formikEnhancer;
