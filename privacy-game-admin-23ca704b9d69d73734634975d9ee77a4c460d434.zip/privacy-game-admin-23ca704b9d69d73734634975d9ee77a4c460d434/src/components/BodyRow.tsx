import * as React from "react";
import { Question } from "../redux/pre-survey/types";

interface Props {
  isOver: boolean;
  connectDragSource: any,
  connectDropTarget: any;
  moveRow: any;
  dragRow: any;
  clientOffset: any;
  sourceClientOffset: any;
  initialClientOffset: any;
  index: number;
  className: string;
  style: {},
  rowSource: Question
}

const dragDirection = (
  dragIndex: any,
  hoverIndex: any,
  initialClientOffset: any,
  clientOffset: any,
  sourceClientOffset: any
) => {
  const hoverMiddleY = (initialClientOffset.y - sourceClientOffset.y) / 2;
  const hoverClientY = clientOffset.y - sourceClientOffset.y;
  if (dragIndex < hoverIndex && hoverClientY > hoverMiddleY) {
    return 'downward';
  }
  if (dragIndex > hoverIndex && hoverClientY < hoverMiddleY) {
    return 'upward';
  }
  return "";
}

export class BodyRow extends React.Component<Props> {
  constructor(props: Props) {
    super(props);
  }
  render() {
    const {
      isOver,
      connectDragSource,
      connectDropTarget,
      moveRow,
      dragRow,
      rowSource,
      clientOffset,
      sourceClientOffset,
      initialClientOffset,
      ...restProps
    } = this.props;
    const style = { ...restProps.style, cursor: 'move' };

    let className = restProps.className;
    if (isOver && initialClientOffset) {
      const direction = dragDirection(
        dragRow.index,
        restProps.index,
        initialClientOffset,
        clientOffset,
        sourceClientOffset
      );
      if (direction === 'downward') {
        className += ' drop-over-downward';
      }
      if (direction === 'upward') {
        className += ' drop-over-upward';
      }
    }

    return connectDragSource(
      connectDropTarget(
        <tr
          {...restProps}
          className={className}
          style={style}
        />
      )
    );
  }
}