import * as React from "react";
import { Table, Menu, Dropdown, Button, Icon } from "antd";
import { Category } from "../redux/pre-survey/types";

const Column = Table.Column;

interface CategoryTableProps {
    categories: Category[];
    onDelete: (id: string) => any
}

const handleMenuClick = (record: any, func: any, e: any) => {
    if (e.key === "delete") {
        func(record._id);
    }
}

const menu = (record: any, func: any) => (
    <Menu onClick={(e) => handleMenuClick(record, func, e)}>
        <Menu.Item key="delete">Delete</Menu.Item>
        <Menu.Item disabled={true} key="translate">Add Translation</Menu.Item>
    </Menu>
);

class CategoryTable extends React.Component<CategoryTableProps> {
    render() {
        return (
            <Table dataSource={this.props.categories} rowKey="_id">
                <Column title="Category" dataIndex="text" key="_id" />

                <Column
                    title="Action"
                    key="action"
                    render={(text, record) => (
                        <Dropdown overlay={menu(record, this.props.onDelete)}>
                            <Button>
                                Actions <Icon type="down" />
                            </Button>
                        </Dropdown>
                    )}
                />
            </Table>
        )
    }
}

export default CategoryTable;
