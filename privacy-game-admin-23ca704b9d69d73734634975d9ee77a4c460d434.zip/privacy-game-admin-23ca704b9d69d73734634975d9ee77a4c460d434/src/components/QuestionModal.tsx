import * as React from "react";
import { Form, Input, Modal, Button, Checkbox, Divider, InputNumber } from "antd";
import {
  Formik,
  FormikErrors,
  Field,
  withFormik,
  FieldProps,
  FormikProps
} from "formik";

import {
  Category,
  QuestionType,
  Answer,
  Question,
  SubQuestion
} from "../redux/pre-survey/types";

import { Select } from "./Select";
import { Answers } from "./Answers";
import { SubQuestions } from "./SubQuestions";

const FormItem = Form.Item;

interface ModalProps {
  onSubmit: (values: FormValues) => void;
  onCancel: () => void;
  visible: boolean;
  loading: boolean;
  categories: Category[]
  selectedQuestion?: Question
}

const types: QuestionType[] = [
  { text: "Multiple options", id: "1", value: "multiple", key: "multiple" },
  { text: "True/False", id: "2", value: "boolean", key: "boolean" },
  { text: "Yes/No", id: "2", value: "yesno", key: "yesno" },
  { text: "Range", id: "3", value: "range", key: "range" },
  { text: "Open", id: "4", value: "open", key: "open" },
  { text: "Matrix", id: "5", value: "matrix", key: "matrix" }
];

const rangeOptions: Answer[] = [{
  text: "1",
  score: 1,
  key: "option1",
  isLastFixed: false
}, {
  text: "2",
  score: 2,
  key: "option2",
  isLastFixed: false
},
{
  text: "3",
  score: 3,
  key: "option3",
  isLastFixed: false
}, {
  text: "4",
  score: 4,
  key: "option4",
  isLastFixed: false
},
{
  text: "5",
  score: 5,
  key: "option5",
  isLastFixed: false
}
]
const trueFalseOptions: Answer[] = [
  {
    text: "True",
    score: 1,
    key: "true",
    isLastFixed: false
  },
  {
    text: "False",
    score: 0,
    key: "false",
    isLastFixed: false
  }
];

const openQuestionOption: Answer[] = [];

const multipleOptions: Answer[] = [
  {
    text: "",
    score: 0,
    key: "option1",
    isLastFixed: false
  }
];

const yesNoOptions: Answer[] = [
  {
    text: "Yes",
    score: 1,
    key: "yes",
    isLastFixed: false
  },
  {
    text: "No",
    score: 0,
    key: "no",
    isLastFixed: false
  }
];

interface InputProps {
  label: string;
  placeHolder?: string;
}

type FormValues = Question;

type InputOwnProps = FieldProps<FormValues> & InputProps;

export const TextField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <Input size="large" type="text" {...field} placeholder={placeHolder} />
    </FormItem>
  );
};

const initialValues: FormValues = {
  _id: "",
  text: "",
  category: "",
  type: "",
  answers: [],
  translations: [],
  order: 0,
  source: "Presurvey",
  allowMultipleSelection: false,
  randomise: false,
  subQuestions: []
};

type AllProps = FormikProps<FormValues> & ModalProps;

class QuestionForm extends React.Component<AllProps> {
  constructor(props: AllProps) {
    super(props);
  }
  onSubmit = (values: FormValues) => {
    if (!values.answers) {
      values.answers = [];
    }
    this.props.onSubmit(values);
  };

  onAllowMultipleSelectionChange = (e: any, func: any) => {
    func("allowMultipleSelection", e.target.checked)
  }

  onRandomiseChange = (e: any, func: any) => {
    func("randomise", e.target.checked)
  }

  onStartLabelChange = (e: any, func: any) => {
    func("startLabel", e.target.value)
  }

  onEndLabelChange = (e: any, func: any) => {
    func("endLabel", e.target.value)
  }

  onMinValueChange = (value: any, func: any, maxValue?: number, subquestions?: SubQuestion[]) => {
    if (value === undefined) {
      value = 1;
    }
    if (value >= 10) {
      value = 10;
    }
    if (maxValue && value > maxValue) {
      value = value;
    }
    if (subquestions && maxValue && maxValue > 0 && value > 0) {
      const newSubquestions = subquestions.map((item) => {
        const newAnswers: Answer[] = [];
        const oldAnswers = item.answers; // .slice(value, maxValue);
        if (oldAnswers.length > 0) {
          for (let i = Number(value); i <= Number(maxValue); i++) {
            newAnswers.push({
              isLastFixed: false,
              score: oldAnswers[i - 1] ? oldAnswers[i - 1].score : 0,
              text: oldAnswers[i - 1] ? oldAnswers[i - 1].text : ""
            })
          }
        }
        item.answers = newAnswers;
        return item;
      })
      func("subQuestions", newSubquestions)
    }

    func("minValue", value)
  }

  onMaxValueChange = (value: any, func: any, subquestions?: SubQuestion[]) => {
    if (value === undefined) {
      value = 1;
    }
    if (value >= 10) {
      value = 10;
    }
    if (subquestions && value > 0) {
      const newSubquestions = subquestions.map((item) => {
        const newAnswers: Answer[] = [];
        const oldAnswers = item.answers; // .slice(minValue, value);
        if (oldAnswers.length > 0) {
          for (let i = 1; i <= Number(value); i++) {
            newAnswers.push({
              isLastFixed: false,
              score: oldAnswers[i - 1] ? oldAnswers[i - 1].score : 0,
              text: oldAnswers[i - 1] ? oldAnswers[i - 1].text : ""
            })
          }
        }
        item.answers = newAnswers;
        return item;
      })
      func("subQuestions", newSubquestions)
    }

    func("numberOfAnswers", value)
  }

  onQuestionTypeChange = (name: string, value: string, func: any) => {
    let values: any;
    switch (value) {
      case "multiple":
        values = multipleOptions;
        break;
      case "yesno":
        values = yesNoOptions;
        break;
      case "boolean":
        values = trueFalseOptions;
        break;
      case "open":
        values = openQuestionOption;
        break;
      case "range":
        values = rangeOptions;
        break;
    }
    func(name, value)
    func("answers", values)
  }

  render() {
    const { visible, onCancel, loading, selectedQuestion } = this.props;
    return (
      <Modal
        width={1000}
        visible={visible}
        title={selectedQuestion ? "Edit question" : "Add a question"}
        okText="Save Question"
        onCancel={onCancel}
        footer={[
          <Button key="cancel" onClick={onCancel}>
            Cancel
          </Button>,
          <Button
            form="QuestionForm"
            key="submit"
            htmlType="submit"
            type="primary"
            loading={loading}
          >
            Submit
          </Button>
        ]}
      >
        <Formik
          initialValues={selectedQuestion || initialValues}
          onSubmit={this.onSubmit}
          enableReinitialize={true}
          validate={(items: FormValues) => {
            const errors: FormikErrors<FormValues> = {};
            if (!items.text) {
              errors.text = "Required";
            }
            if (!items.category) {
              errors.category = "Required";
            }
            if (!items.type) {
              errors.type = "Required";
            }
            return errors;
          }}
          render={({
            handleSubmit,
            setFieldValue,
            setFieldTouched,
            values
          }: FormikProps<FormValues>) => (
              <Form id="QuestionForm" onSubmit={handleSubmit}>
                <Field
                  name="text"
                  render={(innerProps: any) => (
                    <TextField
                      {...innerProps}
                      label="Text"
                      placeHolder="Question text"
                    />
                  )}
                />
                <Field
                  render={({ field, form }: any) => {
                    return (
                      <Select
                        {...field}
                        name="category"
                        label="Category"
                        form={form}
                        placeHolder="Select a category"
                        value={values.category}
                        onChange={setFieldValue}
                        onBlur={setFieldTouched}
                        options={this.props.categories}
                      />
                    );
                  }}
                />

                <Field
                  render={(innerProps: any) => {
                    return (
                      <Select
                        {...innerProps}
                        name="type"
                        form={innerProps.form}
                        label="Question Type"
                        placeHolder="Select a type"
                        value={values.type}
                        onChange={(name: string, value: string) => this.onQuestionTypeChange(name, value, setFieldValue)}
                        onBlur={setFieldTouched}
                        options={types}

                      />
                    );
                  }}
                />
                {values.type === "multiple" &&
                  <Field
                    render={({ field }: any) => {
                      return (
                        <Checkbox
                          {...field}
                          name="allowMultipleSelection"
                          checked={values.allowMultipleSelection}
                          onChange={(e: any) => this.onAllowMultipleSelectionChange(e, setFieldValue)}
                        >
                          Allow multiple selection
                        </Checkbox>
                      );
                    }}
                  />}
                {(values.type === "multiple" || values.type === "matrix") &&
                  <Field
                    render={({ field }: any) => {
                      return (
                        <Checkbox
                          {...field}
                          name="randomise"
                          checked={values.randomise}
                          onChange={(e: any) => this.onRandomiseChange(e, setFieldValue)}
                        >Randomise</Checkbox>
                      );
                    }}
                  />}

                <Divider />
                {values.type === "matrix" && <div id="horizontal-div">
                  <Field name="numberOfAnswers" render={() => {
                    return <FormItem label="Number of elements" className="testing" >
                      <InputNumber
                        size="small"
                        name="text"
                        type="text"
                        min={1}
                        max={10}
                        defaultValue={values.numberOfAnswers || 5}
                        onChange={(e: any) => this.onMaxValueChange(e, setFieldValue, values.subQuestions)}
                        value={values.numberOfAnswers}
                      />
                    </FormItem>
                  }} />
                </div>}
                {values.type === "matrix" &&
                  <Field
                    name="subQuestions"
                    render={({ field }: any) => {
                      return (
                        <SubQuestions
                          {...field}
                          name="subQuestions"
                          numberOfAnswers={values.numberOfAnswers}
                          value={values.subQuestions}
                          onChange={setFieldValue}
                          onBlur={setFieldTouched}
                          questionType={values.type}
                        />
                      );
                    }}
                  />}
                {values.type !== "open" &&
                  <Field
                    name="answers"
                    render={({ field }: any) => {
                      return (
                        <Answers
                          {...field}
                          name="answers"
                          value={values.answers}
                          onChange={setFieldValue}
                          onBlur={setFieldTouched}
                          questionType={values.type}
                        />
                      );
                    }}
                  />}
              </Form>
            )}
        />
      </Modal>
    );
  }
}

const formikEnhancer = withFormik<ModalProps, {}, {}>({
  mapPropsToValues: props => ({}),
  handleSubmit: (values: FormValues, { setSubmitting }) => {
    const payload = {
      ...values,
      category: values.category
    };
    setTimeout(() => {
      alert(JSON.stringify(payload, null, 2));
      setSubmitting(false);
    }, 1000);
  },
  displayName: "QuestionForm"
})(QuestionForm);

export default formikEnhancer;
