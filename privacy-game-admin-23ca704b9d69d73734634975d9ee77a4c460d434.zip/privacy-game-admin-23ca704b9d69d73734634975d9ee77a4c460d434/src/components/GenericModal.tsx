import * as React from "react";
import { Form, Input, Modal, Button } from "antd";
import {
  Formik,
  FormikErrors,
  Field,
  withFormik,
  FieldProps,
  FormikProps
} from "formik";

import {
  LearningComponent,
  Scenario,
  Term
} from "../redux/pre-survey/types";

const FormItem = Form.Item;
const FORM_TITLE = "ItemForm";
const { TextArea } = Input;

interface ModalProps {
  onSubmit: (values: FormValues) => void;
  onCancel: () => void;
  visible: boolean;
  loading: boolean;
  selectedItem?: LearningComponent | Scenario | Term
}

interface InputProps {
  label: string;
  placeHolder?: string;
}

type FormValues = LearningComponent | Scenario;

type InputOwnProps = FieldProps<FormValues> & InputProps;

export const TextAreaField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <TextArea autosize={{ minRows: 3, maxRows: 10 }} {...field} placeholder={placeHolder} />
    </FormItem>
  );
};

export const TextField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <Input size="large" type="text" {...field} placeholder={placeHolder} />
    </FormItem>
  );
};

const initialValues: FormValues = {
  _id: "",
  text: "",
  title: "",
  translations: [],
  order: 0,
};

type AllProps = FormikProps<FormValues> & ModalProps;

class GenericModal extends React.Component<AllProps> {
  constructor(props: AllProps) {
    super(props);
  }

  onSubmit = (values: FormValues) => {
    this.props.onSubmit(values);
  }

  render() {
    const { visible, onCancel, selectedItem, loading } = this.props;
    return (
      <Modal
        width={1000}
        visible={visible}
        title={selectedItem ? `Edit` : "Add"}
        okText="Save"
        onCancel={onCancel}
        footer={[
          <Button key="cancel" onClick={onCancel}>
            Cancel
          </Button>,
          <Button
            form={FORM_TITLE}
            key="submit"
            htmlType="submit"
            type="primary"
            loading={loading}
          >
            Submit
          </Button>
        ]}
      >
        <Formik
          initialValues={selectedItem || initialValues}
          onSubmit={this.onSubmit}
          enableReinitialize={true}
          validate={(items: FormValues) => {
            const errors: FormikErrors<FormValues> = {};
            if (!items.text) {
              errors.text = "Required";
            }
            if (!items.title) {
              errors.title = "Required";
            }
            return errors;
          }}
          render={({
            handleSubmit
          }: FormikProps<FormValues>) => (
              <Form id={FORM_TITLE} onSubmit={handleSubmit}>
                <Field
                  name="title"
                  render={(innerProps: any) => (
                    <TextField
                      {...innerProps}
                      label="Title"
                      placeHolder="Title text"
                    />
                  )}
                />
                <Field
                  name="text"
                  render={(innerProps: any) => (
                    <TextAreaField
                      {...innerProps}
                      label="Text"
                      placeHolder="Question text"
                    />
                  )}
                />
              </Form>
            )}
        />
      </Modal>
    );
  }
}

const formikEnhancer = withFormik<ModalProps, {}, {}>({
  mapPropsToValues: props => ({}),
  handleSubmit: (values: FormValues, { setSubmitting }) => {
    const payload = {
      ...values
    };
    setTimeout(() => {
      alert(JSON.stringify(payload, null, 2));
      setSubmitting(false);
    }, 1000);
  },
  displayName: FORM_TITLE
})(GenericModal);

export default formikEnhancer;
