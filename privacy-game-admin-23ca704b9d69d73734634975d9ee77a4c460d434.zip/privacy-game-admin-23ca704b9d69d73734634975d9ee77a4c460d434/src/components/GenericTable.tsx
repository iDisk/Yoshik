import * as React from "react";
import { Table, Menu, Dropdown, Button, Icon } from "antd";
import { Translation, LearningComponent, Scenario, Term } from "../redux/pre-survey/types";
import { DragDropContext, DragSource, DropTarget } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';

import { BodyRow } from "./BodyRow";
const Column = Table.Column;

interface GenericTableType {
    _id: string;
    title: string;
    order: number;
    translations: Translation[]
}

interface QuestionsTableProps<T> {
    items: T[];
    onDeleteRow: (id: string) => void;
    // onUpdateRow: (item: T) => void;
    onEditRow: (item: T) => void;
    // onCreateRow: (item: T) => void;
    onTranslationClick: (item: T) => void;
    onOrderChange: (item: LearningComponent | Scenario | Term) => void;
    onEditTranslation: (item: T, translation: Translation) => void;
    onDeleteTranslation: (itemId: string, translationId: string) => void;
    showOrder: boolean;
}

const rowSource = {
    beginDrag(props: any) {
        return {
            index: props.index,
            record: props.record
        };
    },
};

const rowTarget = {
    drop(props: any, monitor: any) {
        const dragIndex = monitor.getItem().index;
        const record = monitor.getItem().record;
        const hoverIndex = props.index;

        // Don't replace items with themselves
        if (dragIndex === hoverIndex) {
            return;
        }

        // Time to actually perform the action
        props.moveRow(record, dragIndex, hoverIndex);

        // Note: we're mutating the monitor item here!
        // Generally it's better to avoid mutations,
        // but it's good here for the sake of performance
        // to avoid expensive index searches.
        monitor.getItem().index = hoverIndex;
    },
};


const DragableBodyRow = DropTarget('row', rowTarget, (connect, monitor) => ({
    connectDropTarget: connect.dropTarget(),
    isOver: monitor.isOver(),
    sourceClientOffset: monitor.getSourceClientOffset(),
}))(
    DragSource('row', rowSource, (connect, monitor) => ({
        connectDragSource: connect.dragSource(),
        dragRow: monitor.getItem(),
        clientOffset: monitor.getClientOffset(),
        rowSource,
        initialClientOffset: monitor.getInitialClientOffset(),
    }))(BodyRow)
);

class GenericTable<T extends GenericTableType> extends React.Component<QuestionsTableProps<T>> {
    components = {
        body: {
            row: DragableBodyRow,
        },
    }

    constructor(props: QuestionsTableProps<T>) {
        super(props);
    }

    expandedRowRender = (recordItem: T, onDelete: any, onEdit: any) => {
        return <div>
            {recordItem.translations && recordItem.translations.length > 0 &&
                <Table size="middle" style={{ paddingTop: 16 }}
                    rowKey="_id" title={() => <h3>Translations</h3>} dataSource={recordItem.translations} pagination={false}>
                    <Column title="Text" dataIndex="text" key="text" />
                    <Column title="Language" dataIndex="language" key="language" />
                    <Column
                        title="Action"
                        key="action"
                        render={(text, record: Translation) => {
                            return <Dropdown overlay={this.translationMenu(recordItem, record, onDelete, onEdit)}>
                                <Button>
                                    Actions <Icon type="down" />
                                </Button>
                            </Dropdown>
                        }
                        }
                    />
                </Table>}
        </div>
    };

    moveRow = (item: LearningComponent | Scenario | Term, dragIndex: number, hoverIndex: number) => {
        const newItem = { ...item, ...{ order: hoverIndex + 1 } };
        this.props.onOrderChange(newItem);
    }

    handleActionsMenuClick = (item: T, onDelete: any, onTranslationClick: any, onEdit: any, e: any) => {
        if (e.key === "delete") {
            onDelete(item._id)
        } else if (e.key === "translate") {
            onTranslationClick(item);
        } else if (e.key === "edit") {
            onEdit(item)
        }
    }


    handleTranslationsActionMenuClick = (item: T, translation: Translation, onDelete: any, onEdit: any, e: any) => {
        if (e.key === "delete") {
            onDelete(item._id, translation._id);
        } else if (e.key === "edit") {
            onEdit(item, translation)
        }
    }

    translationMenu = (record: T, translation: Translation, onDelete: any, onEdit: any) => {
        return <Menu onClick={(e) => this.handleTranslationsActionMenuClick(record, translation, onDelete, onEdit, e)}>
            <Menu.Item key="edit">Edit</Menu.Item>
            <Menu.Item key="delete">Delete</Menu.Item>
        </Menu>
    }

    rowMenu = (record: T, onDelete: any, onTranslationClick: any, onEdit: any) => {
        return <Menu onClick={(e) => this.handleActionsMenuClick(record, onDelete, onTranslationClick, onEdit, e)}>
            {record.translations &&
                <Menu.Item disabled={record.translations && record.translations.length === 2} key="translate">Add translation</Menu.Item>
            }
            <Menu.Item key="edit">Edit</Menu.Item>
            <Menu.Item key="delete">Delete</Menu.Item>
        </Menu>
    }

    render() {
        return (
            <Table rowKey="_id"
                className="presurvey-table"
                pagination={false}
                dataSource={this.props.items} indentSize={50}
                components={this.components}
                expandedRowRender={(record) => this.expandedRowRender(record, this.props.onDeleteTranslation, this.props.onEditTranslation)}
                onRow={(record, index) => ({
                    index,
                    moveRow: this.moveRow,
                    record
                })}>
                {this.props.showOrder &&
                    <Column width={100} align="center" title="Order" dataIndex="order" key="order" />}
                <Column width={800} align="left" title="Title" dataIndex="title" key="title" />
                <Column width={800} align="left" title="Text" dataIndex="text" key="text" />
                <Column
                    width={200}
                    title="Action"
                    align="center"
                    key="action"
                    render={(text, record: T) => {
                        return <Dropdown overlay={this.rowMenu(record, this.props.onDeleteRow, this.props.onTranslationClick, this.props.onEditRow)}>
                            <Button>
                                Actions <Icon type="down" />
                            </Button>
                        </Dropdown>
                    }
                    }
                />
            </Table>
        )
    }
}

const GenericTableTableContext = DragDropContext(HTML5Backend)(GenericTable);

export default GenericTableTableContext;