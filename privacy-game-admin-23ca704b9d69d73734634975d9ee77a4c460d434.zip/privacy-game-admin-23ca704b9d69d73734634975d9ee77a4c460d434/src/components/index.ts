import QuestionsTable from "./QuestionsTable";
import QuestionModal from "./QuestionModal";
import CategoryModal from "./CategoryModal";
import CategoryTable from "./CategoryTable";
import TranslationModal from "./TranslationModal";
import EditAnswerModal from "./EditAnswerModal";
import EditSubQuestionModal from "./EditSubQuestionModal";
import SubQuestionTranslationModal from "./SubQuestionTranslationModal";

export { QuestionsTable, QuestionModal, CategoryModal, CategoryTable, TranslationModal, EditSubQuestionModal, EditAnswerModal, SubQuestionTranslationModal };
