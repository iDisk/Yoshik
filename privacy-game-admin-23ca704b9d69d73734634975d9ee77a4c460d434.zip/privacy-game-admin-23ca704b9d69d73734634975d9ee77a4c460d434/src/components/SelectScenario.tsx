import * as React from "react";
import { Form, Select as AntSelect } from "antd";
import { Scenario } from "../redux/pre-survey/types";

const Option = AntSelect.Option;
const FormItem = Form.Item;

interface SelectProps {
  value: string;
  onChange: any;
  onBlur: any;
  name: string;
  label: string;
  placeHolder: string;
  options: Scenario[];
  form: any;
}

export class SelectScenario extends React.Component<SelectProps, any> {
  handleChange = (value: string) => {
    // this is going to call setFieldValue and manually update values.topcis
    this.props.onChange(this.props.name, value);
  };

  handleBlur = () => {
    // this is going to call setFieldTouched and manually update touched.topcis
    this.props.onBlur(this.props.name, true);
  };

  render() {
    const { label, value, placeHolder, form } = this.props;
    return (
      <FormItem label={label} hasFeedback={form && !!form.errors[this.props.name]} validateStatus={form && form.errors[this.props.name] && "error"} help={form && form.errors[this.props.name]}>
        <AntSelect
          showSearch
          filterOption={(input: any, option: any) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
          onChange={this.handleChange}
          onBlur={this.handleBlur}
          value={value}
          placeholder={placeHolder}
        >
          {this.props.options &&
            this.props.options.map(item => {
              return (
                <Option key={item._id} value={item._id}>
                  {item.title}
                </Option>
              );
            })}
        </AntSelect>
      </FormItem>
    );
  }
}
