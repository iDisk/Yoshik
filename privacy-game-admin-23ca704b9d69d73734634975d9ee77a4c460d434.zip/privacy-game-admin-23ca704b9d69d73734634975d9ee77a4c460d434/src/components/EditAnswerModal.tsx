import * as React from "react";
import { Form, Input, Modal, Button } from "antd";
import {
  Formik,
  FormikErrors,
  Field,
  withFormik,
  FieldProps,
  FormikProps
} from "formik";

import {
  Answer, Question, Translation, SubQuestion
} from "../redux/pre-survey/types";

const FormItem = Form.Item;

interface ModalProps {
  onSubmit: (values: FormValues) => void;
  onCancel: () => void;
  visible: boolean;
  loading: boolean;
  selectedAnswer?: Answer
  currentQuestion?: Question
  currentTranslation?: Translation
  currentSubQuestion?: SubQuestion
}

interface InputProps {
  label: string;
  placeHolder?: string;
  value: string;
}

type FormValues = Answer;

type InputOwnProps = FieldProps<FormValues> & InputProps;

export const TextField: React.SFC<InputOwnProps> = ({
  label,
  field,
  form,
  placeHolder,
  value
}) => {
  return (
    <FormItem
      label={label}
      hasFeedback={!!form.errors[name]}
      validateStatus={form.errors[field.name] && "error"}
      help={form.errors[field.name]}
    >
      <Input type="text" {...field} placeholder={placeHolder} />
    </FormItem>
  );
};

type AllProps = FormikProps<FormValues> & ModalProps;
const FORM = "EditAnswerForm";

class EditAnswerModal extends React.Component<AllProps> {
  constructor(props: AllProps) {
    super(props);
  }

  onSubmit = (values: FormValues) => {
    if (this.props.selectedAnswer && this.props.currentQuestion) {
      if (this.props.currentTranslation && this.props.currentSubQuestion) {
        console.log("Translation de una subquestion")
        const newAnswers = this.props.currentTranslation.answers!.map((item) => {
          if (item._id === this.props.selectedAnswer!._id) {
            item.score = values.score;
            item.text = values.text;
          }
          return item;
        })
        const newTranslations = this.props.currentSubQuestion.translations.map((item) => {
          if (item._id === this.props.currentTranslation!._id) {
            item.answers = newAnswers;
          }
          return item;
        })
        const newSubQuestions = this.props.currentQuestion.subQuestions!.map((item) => {
          if (item._id === this.props.currentSubQuestion!._id) {
            item.translations = newTranslations;
          }
          return item;
        })
        const newQuestion = { ...this.props.currentQuestion, ...{ subQuestions: newSubQuestions } };
        this.props.onSubmit(newQuestion as any);
      }
      else if (this.props.currentTranslation && !this.props.currentSubQuestion) {
        console.log("Translation normal")
        const newAnswers = this.props.currentTranslation.answers!.map((item) => {
          if (item._id === this.props.selectedAnswer!._id) {
            item.score = values.score;
            item.text = values.text;
          }
          return item;
        })
        const newTranslations = this.props.currentQuestion.translations.map((item) => {
          if (item._id === this.props.currentTranslation!._id) {
            item.answers = newAnswers;
          }
          return item;
        })
        const newQuestion = { ...this.props.currentQuestion, ...{ translations: newTranslations } };
        this.props.onSubmit(newQuestion as any);
      } else if (!this.props.currentTranslation && !this.props.currentSubQuestion) {
        console.log("Answer normal")
        const newAnswers = this.props.currentQuestion.answers.map((item) => {
          if (item._id === this.props.selectedAnswer!._id) {
            item.score = values.score;
            item.text = values.text;
          }
          return item;
        })

        const newQuestion = { ...this.props.currentQuestion, ...{ answers: newAnswers } };
        this.props.onSubmit(newQuestion as any);
      } else if (!this.props.currentTranslation && this.props.currentSubQuestion) {
        console.log("Answer de una subquestion")
        const newAnswers = this.props.currentSubQuestion.answers!.map((item) => {
          if (item._id === this.props.selectedAnswer!._id) {
            item.score = values.score;
            item.text = values.text;
          }
          return item;
        })
        const newSubQuestions = this.props.currentQuestion.subQuestions!.map((item) => {
          if (item._id === this.props.currentSubQuestion!._id) {
            item.answers = newAnswers;
          }
          return item;
        })
        const newQuestion = { ...this.props.currentQuestion, ...{ subQuestions: newSubQuestions } };
        this.props.onSubmit(newQuestion as any);
      }
    }
  };

  render() {
    const { visible, onCancel, loading, selectedAnswer } = this.props;
    return (
      <Modal
        visible={visible}
        title="Edit Answer"
        okText="Save Answer"
        onCancel={onCancel}
        footer={[
          <Button key="cancel" onClick={onCancel}>
            Cancel
          </Button>,
          <Button
            form={FORM}
            key="submit"
            htmlType="submit"
            type="primary"
            loading={loading}
          >
            Submit
          </Button>
        ]}
      >
        <Formik
          initialValues={selectedAnswer}
          enableReinitialize={true}
          isInitialValid={true}
          onSubmit={this.onSubmit}
          validate={(items: FormValues) => {
            const errors: FormikErrors<FormValues> = {};
            if (!items.text) {
              errors.text = "Required";
            }

            return errors;
          }}
          render={({
            handleSubmit
          }: FormikProps<FormValues>) => (
              <Form id={FORM} onSubmit={handleSubmit}>
                <Field
                  name="text"
                  render={(innerProps: any) => (
                    <TextField
                      {...innerProps}
                      label="Text"
                      placeHolder="Answer text"
                    />
                  )}
                />
                <Field
                  name="score"
                  render={(innerProps: any) => (
                    <TextField
                      {...innerProps}
                      label="Score"
                      placeHolder="Score"
                    />
                  )}
                />
              </Form>
            )}
        />
      </Modal>
    );
  }
}

const formikEnhancer = withFormik<ModalProps, {}, {}>({
  mapPropsToValues: props => ({}),
  handleSubmit: (values: FormValues, { setSubmitting }) => {
    const payload = {
      ...values
    };
    setTimeout(() => {
      alert(JSON.stringify(payload, null, 2));
      setSubmitting(false);
    }, 1000);
  },
  displayName: FORM
})(EditAnswerModal);

export default formikEnhancer;
