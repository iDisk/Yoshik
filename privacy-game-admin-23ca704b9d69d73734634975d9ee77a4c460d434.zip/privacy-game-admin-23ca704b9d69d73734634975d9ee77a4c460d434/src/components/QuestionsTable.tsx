import * as React from "react";
import { Table, Menu, Dropdown, Button, Icon } from "antd";
import { Question, Answer, Translation, SubQuestion } from "../redux/pre-survey/types";
import { DragDropContext, DragSource, DropTarget } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';
// import update from 'immutability-helper';
import { BodyRow } from "./BodyRow";

const Column = Table.Column;

interface State {
  current: number;
}

interface QuestionsTableProps {
  questions: Question[];
  onDelete: (id: string) => any
  onAnswerDelete: (questionId: string, id: string) => any
  onTranslationClick: (selectecQuestion: Question) => void
  onQuestionTranslationDelete: (questionId: string, translationId: string) => any
  onEditAnswer: (question: Question, selectedAnswer: Answer) => void
  onAnswerTranslationDelete: (questionId: string, translationId: string, answerId: string) => void
  onEditTranslation: (question: Question, translation: Translation) => void
  onEditSubquestion: (question: Question, selectedSubquestion: SubQuestion) => void
  onSubQuestionDelete: (questionId: string, id: string) => any
  onEditQuestion: (question: Question) => void
  onOrderChange: (question: Question) => void
  onSubquestionTranslationClick: (question: Question, subQuestion: SubQuestion, translation?: Translation) => void
  onEditSubQuestionTranslation: (question: Question, subQuestion: SubQuestion, translation?: Translation) => void
  onDeleteSubQuestionTranslation: (questionId: string, subQuestionId: string, translationId: string) => any
  onDeleteSubQuestionAnswer: any;
  onEditSubquestionAnswer: any
}

const rowSource = {
  beginDrag(props: any) {
    return {
      index: props.index,
      record: props.record
    };
  },
};

const rowTarget = {
  drop(props: any, monitor: any) {
    const dragIndex = monitor.getItem().index;
    const record = monitor.getItem().record;
    const hoverIndex = props.index;

    // Don't replace items with themselves
    if (dragIndex === hoverIndex) {
      return;
    }

    // Time to actually perform the action
    props.moveRow(record, dragIndex, hoverIndex);

    // Note: we're mutating the monitor item here!
    // Generally it's better to avoid mutations,
    // but it's good here for the sake of performance
    // to avoid expensive index searches.
    monitor.getItem().index = hoverIndex;
  },
};

const DragableBodyRow = DropTarget('row', rowTarget, (connect, monitor) => ({
  connectDropTarget: connect.dropTarget(),
  isOver: monitor.isOver(),
  sourceClientOffset: monitor.getSourceClientOffset(),
}))(
  DragSource('row', rowSource, (connect, monitor) => ({
    connectDragSource: connect.dragSource(),
    dragRow: monitor.getItem(),
    clientOffset: monitor.getClientOffset(),
    rowSource,
    initialClientOffset: monitor.getInitialClientOffset(),
  }))(BodyRow)
);

const handleTranslationQuestionMenuClick = (question: Question, translation: Translation, onDelete: any, onEditTranslation: any, e: any) => {
  if (e.key === "delete") {
    onDelete(question._id, translation._id)
  } else if (e.key === "edit") {
    onEditTranslation(question, translation)
  }

}

const handleQuestionMenuClick = (question: Question, onDelete: any, onTranslationClick: any, onEditQuestion: any, e: any) => {
  if (e.key === "delete") {
    onDelete(question._id)
  } else if (e.key === "translate") {
    onTranslationClick(question);
  } else if (e.key === "edit") {
    onEditQuestion(question)
  }
}
const handleTranslationAnswerMenuClick = (question: Question, translation: Translation, record: Answer, onDelete: any, onEditAnswer: any, e: any) => {
  if (e.key === "delete") {
    onDelete(question._id, translation._id, record._id);
  } else if (e.key === "translate") {
    console.log("Clicked translate")
  } else if (e.key === "edit") {
    onEditAnswer(question, record, translation)
  }
}

const handleSubQuestionTranslationMenuClick = (question: Question, subQuestion: SubQuestion, translation: Translation, onDeleteSubQuestionTranslation: any, onEditSubQuestionTranslation: any, e: any) => {
  if (e.key === "delete") {
    onDeleteSubQuestionTranslation(question._id, subQuestion._id, translation._id);
  } else if (e.key === "translate") {
    console.log("Clicked translate")
  } else if (e.key === "edit") {
    onEditSubQuestionTranslation(question, subQuestion, translation)
  }
}

const handleAnswerMenuClick = (question: Question, record: Answer, onDelete: any, onEditAnswer: any, e: any) => {
  if (e.key === "delete") {
    onDelete(question._id, record._id);
  } else if (e.key === "translate") {
    console.log("Clicked translate")
  } else if (e.key === "edit") {
    onEditAnswer(question, record, undefined)
  }
}

const handleSubQuestionAnswerMenuClick = (question: Question, subQuestion: SubQuestion, record: Answer, onDelete: any, onEditAnswer: any, e: any) => {
  if (e.key === "delete") {
    onDelete(question._id, subQuestion._id, record._id);
  } else if (e.key === "translate") {
    console.log("Clicked translate")
  } else if (e.key === "edit") {
    onEditAnswer(question, subQuestion, record, undefined)
  }
}

const questionMenu = (record: Question, onDelete: any, onTranslationClick: any, onEditQuestion: any) => {
  return <Menu onClick={(e) => handleQuestionMenuClick(record, onDelete, onTranslationClick, onEditQuestion, e)}>
    {record.translations &&
      <Menu.Item disabled={record.translations && record.translations.length === 2} key="translate">Add translation</Menu.Item>
    }
    <Menu.Item key="edit">Edit</Menu.Item>
    <Menu.Item key="delete">Delete</Menu.Item>
  </Menu>
}

const subQuestionAnswerMenu = (question: Question, record: SubQuestion, answer: Answer, onDelete: any, onEdit: any) => {
  return <Menu onClick={(e) => handleSubQuestionAnswerMenuClick(question, record, answer, onDelete, onEdit, e)}>
    <Menu.Item key="edit">Edit</Menu.Item>
    {/* <Menu.Item key="delete">Delete</Menu.Item> */}
  </Menu>
}

const answerMenu = (question: Question, record: Answer, onDelete: any, onEditAnswer: any) => {
  return <Menu onClick={(e) => handleAnswerMenuClick(question, record, onDelete, onEditAnswer, e)}>
    <Menu.Item key="edit">Edit</Menu.Item>
    <Menu.Item key="delete">Delete</Menu.Item>
  </Menu>
}

const answerTranslationMenu = (question: Question, translation: Translation, record: Answer, onDelete: any, onEditAnswer: any, ) => {
  return <Menu onClick={(e) => handleTranslationAnswerMenuClick(question, translation, record, onDelete, onEditAnswer, e)}>
    <Menu.Item key="edit">Edit</Menu.Item>
    <Menu.Item key="delete">Delete</Menu.Item>
  </Menu>
}

const translationQuestionMenu = (question: Question, record: Translation, onDelete: any, onEditTranslation: any) => {
  return <Menu onClick={(e) => handleTranslationQuestionMenuClick(question, record, onDelete, onEditTranslation, e)}>
    <Menu.Item key="edit">Edit</Menu.Item>
    <Menu.Item key="delete">Delete</Menu.Item>
  </Menu>
}

const subQuestionTranslationMenu = (question: Question, record: SubQuestion, translation: Translation, onDelete: any, onEditTranslation: any) => {
  return <Menu onClick={(e) => handleSubQuestionTranslationMenuClick(question, record, translation, onDelete, onEditTranslation, e)}>
    <Menu.Item key="edit">Edit</Menu.Item>
    <Menu.Item key="delete">Delete</Menu.Item>
  </Menu>
}

const handleSubQuestionTranslationAnswerMenuClick = (question: Question, subQuestion: SubQuestion, record: Translation, answer: Answer, onEditAnswer: any, e: any) => {
  if (e.key === "delete") {
    // onDelete(question._id, subQuestion._id, record._id, answer._id);
  } else if (e.key === "translate") {
    console.log("Clicked translate")
  } else if (e.key === "edit") {
    onEditAnswer(question, subQuestion, answer, record)
  }
}
const subQuestionAnswerTranslationMenu = (question: Question, subQuestion: SubQuestion, translation: Translation, record: Answer, onEditAnswer: any, ) => {
  return <Menu onClick={(e) => handleSubQuestionTranslationAnswerMenuClick(question, subQuestion, translation, record, onEditAnswer, e)}>
    <Menu.Item key="edit">Edit</Menu.Item>
    {/* <Menu.Item key="delete">Delete</Menu.Item> */}
  </Menu>
}
const subQuestionMenu = (question: Question, record: SubQuestion, onDelete: any, onEditSubquestion: any, onSubquestionTranslationClick: any) => {
  return <Menu onClick={(e) => handleSubQuestionMenuClick(question, record, onDelete, onEditSubquestion, onSubquestionTranslationClick, e)}>
    {record.translations &&
      <Menu.Item disabled={record.translations && record.translations.length === 2} key="translate">Add translation</Menu.Item>
    }
    <Menu.Item key="edit">Edit</Menu.Item>
    <Menu.Item key="delete">Delete</Menu.Item>
  </Menu>
}

const handleSubQuestionMenuClick = (question: Question, record: SubQuestion, onDelete: any, onEditSubquestion: any, onSubquestionTranslationClick: any, e: any) => {
  if (e.key === "delete") {
    onDelete(question._id, record._id);
  } else if (e.key === "translate") {
    onSubquestionTranslationClick(question, record);
  } else if (e.key === "edit") {
    onEditSubquestion(question, record, undefined)
  }
}

const translationSubQuestionAnswerRenderer = (question: Question, subQuestion: SubQuestion, translation: Translation, onEditAnswer: any) => {
  return <div><Table size="middle" rowKey="_id" title={() => <h3>Answers</h3>} dataSource={translation.answers} pagination={false}>
    <Column title="Text" dataIndex="text" key="text" />
    <Column title="Score" dataIndex="score" key="score" />
    <Column
      title="Action"
      key="action"
      render={(text, record: Answer) => {
        return <Dropdown overlay={subQuestionAnswerTranslationMenu(question, subQuestion, translation, record, onEditAnswer)}>
          <Button>
            Actions <Icon type="down" />
          </Button>
        </Dropdown>
      }
      }
    />
  </Table></div>
}
const anotherRowRender = (question: Question, translation: Translation, onDelete: any, onEditAnswer: any) => {
  return <div>{question.type !== "matrix" && translation.answers && translation.answers.length > 0 && <Table size="middle" rowKey="_id" title={() => <h3>Answers</h3>} dataSource={translation.answers} pagination={false}>
    <Column title="Text" dataIndex="text" key="text" />
    <Column title="Score" dataIndex="score" key="score" />
    <Column
      title="Action"
      key="action"
      render={(text, record: Answer) => {
        return <Dropdown overlay={answerTranslationMenu(question, translation, record, onDelete, onEditAnswer)}>
          <Button>
            Actions <Icon type="down" />
          </Button>
        </Dropdown>
      }
      }
    />
  </Table>}</div>
}

const subQuestionRowRender = (question: Question, subQuestion: SubQuestion, onDelete: any, onEdit: any, ondeleteSubQuestionAnswer: any, onEditSubquestionAnswer: any) => {
  return <div> {subQuestion.answers && subQuestion.answers.length > 0 &&
    <Table size="middle" rowKey="_id" title={() => <h3>Answers</h3>} dataSource={subQuestion.answers} pagination={false}>
      <Column title="Text" dataIndex="text" key="text" />
      <Column title="Score" dataIndex="score" key="score" />
      <Column title="Is Last Fixed" dataIndex="isLastFixed" key="isLastFixed" render={(text, record, index) => {
        if (text) {
          return "True";
        }
        return "False"

      }} />
      <Column
        title="Action"
        key="action"
        render={(text, record: Answer) => {
          return <Dropdown overlay={subQuestionAnswerMenu(question, subQuestion, record, ondeleteSubQuestionAnswer, onEditSubquestionAnswer)}>
            <Button>
              Actions <Icon type="down" />
            </Button>
          </Dropdown>
        }
        }
      />
    </Table>}
    {subQuestion.translations && subQuestion.translations.length > 0 && <Table size="middle" rowKey="_id" title={() => <h3>Translations</h3>} dataSource={subQuestion.translations} pagination={false}
      expandedRowRender={(record) => translationSubQuestionAnswerRenderer(question, subQuestion, record, onEditSubquestionAnswer)} style={{ paddingTop: 16 }}>
      <Column title="Text" dataIndex="text" key="text" />
      <Column title="Language" dataIndex="language" key="language" />
      <Column
        title="Action"
        key="action"
        render={(text, record: Translation) => {
          return <Dropdown overlay={subQuestionTranslationMenu(question, subQuestion, record, onDelete, onEdit)}>
            <Button>
              Actions <Icon type="down" />
            </Button>
          </Dropdown>
        }
        }
      />
    </Table>}</div>
}


const expandedRowRender = (recordItem: Question, onDelete: any, onQuestionTranslationDelete: any, onEditAnswer: any, onAnswerTranslationDelete: any, onEditTranslation: any,
  onEditSubquestion: any, onDeleteSubquestion: any, onSubquestionTranslationClick: any, onSubQuestionTranslationDelete: any, onSubQuestionTranslationEdit: any, ondeleteSubQuestionAnswer: any, onEditSubquestionAnswer: any) => {
  return <div>
    {recordItem.answers && recordItem.answers.length > 0 &&
      <Table size="middle" rowKey="_id" title={() => <h3>Answers</h3>} dataSource={recordItem.answers} pagination={false}>
        <Column title="Text" dataIndex="text" key="text" />
        <Column title="Score" dataIndex="score" key="score" />
        <Column title="Is Last Fixed" dataIndex="isLastFixed" key="isLastFixed" render={(text, record, index) => {
          if (text) {
            return "True";
          }
          return "False"

        }} />
        <Column
          title="Action"
          key="action"
          render={(text, record: Answer) => {
            return <Dropdown overlay={answerMenu(recordItem, record, onDelete, onEditAnswer)}>
              <Button>
                Actions <Icon type="down" />
              </Button>
            </Dropdown>
          }
          }
        />
      </Table>}
    {recordItem.translations && recordItem.translations.length > 0 &&
      <Table size="middle" expandedRowRender={(record) => anotherRowRender(recordItem, record, onAnswerTranslationDelete, onEditAnswer)} style={{ paddingTop: 16 }}
        rowKey="_id" title={() => <h3>Translations</h3>} dataSource={recordItem.translations} pagination={false}>
        <Column title="Text" dataIndex="text" key="text" />
        <Column title="Language" dataIndex="language" key="language" />
        <Column
          title="Action"
          key="action"
          render={(text, record: Translation) => {
            return <Dropdown overlay={translationQuestionMenu(recordItem, record, onQuestionTranslationDelete, onEditTranslation)}>
              <Button>
                Actions <Icon type="down" />
              </Button>
            </Dropdown>
          }
          }
        />
      </Table>}
    {recordItem.subQuestions && recordItem.subQuestions.length > 0 &&
      <Table size="middle" expandedRowRender={(record) => subQuestionRowRender(recordItem, record, onSubQuestionTranslationDelete, onSubQuestionTranslationEdit, ondeleteSubQuestionAnswer, onEditSubquestionAnswer)} style={{ paddingTop: 16 }}
        rowKey="_id" title={() => <h3>Sub Questions</h3>} dataSource={recordItem.subQuestions} pagination={false}>
        <Column title="Text" dataIndex="text" key="text" />
        <Column
          title="Action"
          key="action"
          render={(text, record: SubQuestion) => {
            return <Dropdown overlay={subQuestionMenu(recordItem, record, onDeleteSubquestion, onEditSubquestion, onSubquestionTranslationClick)}>
              <Button>
                Actions <Icon type="down" />
              </Button>
            </Dropdown>
          }
          }
        />
      </Table>}
  </div>
};


class QuestionsTable extends React.Component<QuestionsTableProps, State> {



  components = {
    body: {
      row: DragableBodyRow,
    },
  }

  constructor(props: QuestionsTableProps) {
    super(props); this.state = {
      current: 1,
    }
  }

  onChange = (page: any) => {
    this.setState({
      current: page,
    });
  }
  moveRow = (question: Question, dragIndex: number, hoverIndex: number) => {
    const newQuestion = { ...question, ...{ order: hoverIndex + 1 } };
    this.props.onOrderChange(newQuestion);
  }

  render() {
    return (
      <Table rowKey="_id"
        className="presurvey-table"
        pagination={false}
        dataSource={this.props.questions} indentSize={50}
        components={this.components}
        onRow={(record, index) => ({
          index,
          moveRow: this.moveRow,
          record
        })}
        expandedRowRender={(record) => expandedRowRender(record, this.props.onAnswerDelete,
          this.props.onQuestionTranslationDelete,
          this.props.onEditAnswer,
          this.props.onAnswerTranslationDelete,
          this.props.onEditTranslation,
          this.props.onEditSubquestion,
          this.props.onSubQuestionDelete,
          this.props.onSubquestionTranslationClick,
          this.props.onDeleteSubQuestionTranslation,
          this.props.onEditSubQuestionTranslation,
          this.props.onDeleteSubQuestionAnswer,
          this.props.onEditSubquestionAnswer)}>

        <Column width={100} align="center" title="Order" dataIndex="order" key="order" />
        <Column width={800} align="left" title="Text" dataIndex="text" key="text" />
        <Column width={200} align="center" title="Type" dataIndex="type" key="type" />
        <Column width={200} align="center" title="Category" dataIndex="category" key="category" />
        <Column width={250} align="center" title="Allow multiple selection" dataIndex="allowMultipleSelection" key="allowMultipleSelection"
          render={(text, record, index) => {
            if (text) {
              return "True";
            }
            return "False"

          }} />
        <Column width={200} align="center" title="Randomise" dataIndex="randomise" key="randomise"
          render={(text, record, index) => {
            if (text) {
              return "True";
            }
            return "False"

          }} />
        <Column
          width={200}
          title="Action"
          align="center"
          key="action"
          render={(text, record: Question) => {
            return <Dropdown overlay={questionMenu(record, this.props.onDelete, this.props.onTranslationClick, this.props.onEditQuestion)}>
              <Button>
                Actions <Icon type="down" />
              </Button>
            </Dropdown>
          }
          }
        />
      </Table>
    )
  }
}

const QuestionsTableContext = DragDropContext(HTML5Backend)(QuestionsTable);

export default QuestionsTableContext;

// add on EditSubquestionAnswer, deleteSubQuestionAnswer
// render answers of translations