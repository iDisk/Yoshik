import * as React from "react";
import { Route, Switch, RouteProps } from "react-router-dom";
import DefaultLayout from "./Default";
import NotFound from "./NotFound";
import Auth from './Auth';
import Callback from './Callback';

import {
  Home,
  PreSurvey,
  Categories,
  PostSurvey,
  Scenarios,
  LearningComponents,
  GameSetup,
  Results
} from "./features";

import Terms from "./features/Terms";

interface Props extends RouteProps {
  component: new (props: any) => React.Component;
}

const auth = new Auth();

const DashboardRoute = ({ component: Component, ...rest }: Props) => {
  return (
    <Route
      {...rest}
      render={matchProps => (
        <DefaultLayout>
          <Component {...matchProps} />
        </DefaultLayout>
      )}
    />
  );
};

const handleAuthentication = (nextState: any) => {
  if (/access_token|id_token|error/.test(nextState.location.hash)) {
    auth.handleAuthentication();
  }
}

export const MainRoutes = () => (
  <Switch>
    <DashboardRoute exact path="/" component={Home} />
    <DashboardRoute path="/presurvey" component={PreSurvey} />
    <DashboardRoute path="/postsurvey" component={PostSurvey} />
    <DashboardRoute path="/gamesetup" component={GameSetup} />
    <DashboardRoute
      path="/learning-components"
      component={LearningComponents}
    />
    <DashboardRoute path="/scenarios" component={Scenarios} />

    <DashboardRoute path="/results" component={Results} />
    <DashboardRoute path="/categories" component={Categories} />
    <DashboardRoute path="/terms" component={Terms} />
    <Route path="/callback" render={(props) => {
      handleAuthentication(props);
      return <Callback {...props} />
    }} />
    <Route component={NotFound} />
  </Switch>
);

export default MainRoutes;
