import * as React from "react";
import GenericTable from "../components/GenericTable";
import { ApplicationState } from "../redux/reducers";
import { connect } from "react-redux";
import { bindActionCreators, Dispatch } from "redux";
import { deleteLearningComponent, createLearningComponent, deleteLearningComponentTranslation, getLearningComponents, saveLearningComponent } from "../redux/pre-survey/learning-components-actions";
import { LearningComponent, Translation } from "../redux/pre-survey/types";
import GenericModal from "../components/GenericModal";
import GenericTranslationModal from "../components/GenericTranslationModal";
import { Button } from "antd";

interface Props {
  loading: boolean;
  learningComponents: LearningComponent[];
  deleteLearningComponent: any;
  createLearningComponent: any;
  saveLearningComponent: any;
  getLearningComponents: any
  onTranslationClick: any
  onOrderChange: any;
  deleteLearningComponentTranslation: any
}

interface State {
  showModal: boolean;
  selectedItem?: LearningComponent;
  showTranslationModal: boolean;
  selectedTranslation?: Translation
}

class LearningComponents extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      showModal: false,
      showTranslationModal: false,
      selectedItem: undefined
    }
  }

  componentDidMount() {
    this.props.getLearningComponents();
  }

  openModal = (item?: LearningComponent) => {
    this.setState({
      showModal: true,
      selectedItem: item
    });
  }

  openTranslationModal = (selectedItem: LearningComponent, translation?: Translation) => {
    this.setState({
      showTranslationModal: true,
      selectedItem,
      selectedTranslation: translation
    });
  }
  saveTranslation = (item: LearningComponent) => {
    this.props.saveLearningComponent(item);

    this.closeModal();
  }
  saveLearningComponent = (item: LearningComponent) => {
    if (this.state.selectedItem) {
      this.props.saveLearningComponent(item);
    } else {
      this.props.createLearningComponent(item);
    }
    this.closeModal();
  }

  closeModal = () => {
    this.setState({
      showModal: false,
      showTranslationModal: false
    });
  }
  onEdit = (item: LearningComponent) => {
    this.setState({
      selectedItem: item,
      showModal: true
    })
  }
  onAddTranslationClick = (item: LearningComponent) => {
    this.setState({
      selectedItem: item,
      showTranslationModal: true,
      selectedTranslation: undefined
    })
  }
  render() {
    const { selectedItem, showModal, showTranslationModal, selectedTranslation } = this.state;
    return (
      <div>
        <h1>Learning Components</h1>
        <div style={{ marginBottom: 16 }}>
          <Button type="primary" onClick={() => this.openModal(undefined)}>
            Add Learning Component
          </Button>
        </div>
        <GenericModal onSubmit={this.saveLearningComponent}
          onCancel={this.closeModal}
          visible={showModal}
          selectedItem={selectedItem}
          loading={false}
        />
        <GenericTranslationModal onSubmit={this.saveTranslation}
          onCancel={this.closeModal}
          visible={showTranslationModal}
          selectedItem={selectedItem}
          selectedTranslation={selectedTranslation}
          loading={false}
        />
        <GenericTable items={this.props.learningComponents}
          onDeleteRow={this.props.deleteLearningComponent}
          onEditRow={this.onEdit}
          showOrder={true}
          onDeleteTranslation={this.props.deleteLearningComponentTranslation}
          onEditTranslation={(item: LearningComponent, translation: Translation) => this.openTranslationModal(item, translation)}
          onTranslationClick={this.onAddTranslationClick}
          onOrderChange={this.props.saveLearningComponent} />
      </div>
    )
  }
}

const mapStateToProps = (state: ApplicationState) => {
  return {
    learningComponents: state.preSurveyState.learningComponents
  };
};

const mapDispatchToProps = (dispatch: Dispatch) => {
  return bindActionCreators(
    {
      deleteLearningComponent,
      createLearningComponent,
      saveLearningComponent,
      getLearningComponents,
      deleteLearningComponentTranslation
    },
    dispatch
  );
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LearningComponents);