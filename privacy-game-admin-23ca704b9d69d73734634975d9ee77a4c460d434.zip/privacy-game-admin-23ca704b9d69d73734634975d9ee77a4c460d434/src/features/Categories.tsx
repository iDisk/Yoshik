import * as React from "react";
import { connect } from "react-redux";
import { Button } from "antd";

import { Category } from "src/redux/pre-survey/types";
import { getCategories, saveCategory, deleteCategory } from "../redux/categories/actions";

import { CategoryModal, CategoryTable } from "../components";

import { ApplicationState } from "../redux/reducers";
import { bindActionCreators, Dispatch } from "redux";

interface Props {
  loading: boolean;
  categories: Category[];
  getCategories: any;
  saveCategory: any
  deleteCategory: any;
}


interface State {
  showModal: boolean;
  loading: boolean;
}

class Categories extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      showModal: false,
      loading: false
    };
  }
  componentDidMount() {
    this.props.getCategories();
  }

  openModal = () => {
    this.setState({
      showModal: true
    });
  };

  handleCancel = () => {
    this.setState({
      showModal: false
    });
  };

  handleOk = (values: any) => {
    this.setState({
      loading: true
    });
    this.setState({
      loading: false
    }, () => {
      this.handleCancel();
      this.props.saveCategory(values);
    });
  };
  render() {
    const { showModal, loading } = this.state;
    return (
      <div>
        <h1>Categories page</h1>
        <CategoryModal
          onSubmit={this.handleOk}
          onCancel={this.handleCancel}
          visible={showModal}
          loading={loading}
        />
        <div style={{ marginBottom: 16 }}>
          <Button type="primary" onClick={this.openModal}>
            Add Category
          </Button>
        </div>
        <CategoryTable onDelete={this.props.deleteCategory} categories={this.props.categories} />
      </div>
    );
  }
}

const mapStateToProps = (state: ApplicationState) => {
  return { categories: state.categoryState.categories };
};

const mapDispatchToProps = (dispatch: Dispatch) => {
  return bindActionCreators(
    {
      getCategories,
      saveCategory,
      deleteCategory
    },
    dispatch
  );
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Categories);
