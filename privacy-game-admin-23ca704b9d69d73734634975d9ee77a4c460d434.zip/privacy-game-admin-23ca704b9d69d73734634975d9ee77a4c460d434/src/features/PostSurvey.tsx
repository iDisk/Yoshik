import * as React from "react";
import SurveyEngine from "../components/SurveyEngine";
import { connect } from "react-redux";
import { ApplicationState } from "../redux/reducers";
import { Question } from "../redux/pre-survey/types";

const TYPE = "Postsurvey";

interface Props {
  questions: Question[];
}

class PostSurvey extends React.Component<Props> {
  constructor(props: Props) {
    super(props);
  }

  render() {
    return (
      <SurveyEngine title="Postsurvey Page"
        questions={this.props.questions} type={TYPE} />
    );
  }
}


const mapStateToProps = (state: ApplicationState) => {
  return {
    questions: state.preSurveyState.questions.filter(item => item.source === TYPE)
  };
};

export default connect(
  mapStateToProps,
  null
)(PostSurvey);
