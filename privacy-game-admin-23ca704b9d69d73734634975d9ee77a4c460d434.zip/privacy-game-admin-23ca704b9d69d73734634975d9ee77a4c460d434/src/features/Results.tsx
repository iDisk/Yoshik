import * as React from "react";
import { Button } from "antd";

interface Props {
  loading: boolean;
  exporting: boolean;
}

export class Results extends React.Component<Props> {
  getDownloadURL = () => {
    const url = process.env.NODE_ENV === "development" ? "http://localhost:3001/download" : "http://104.40.242.127/download";
    return url;
  }

  render() {
    return (
      <div>
        <h1>Results page</h1>
        <div style={{ marginBottom: 16 }}>
          <Button href={this.getDownloadURL()} type="primary">Download data</Button>
        </div>
      </div>
    );
  }
}

