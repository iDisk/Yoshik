import * as React from "react";
import SurveyEngine from "../components/SurveyEngine";
import { connect } from "react-redux";
import { ApplicationState } from "../redux/reducers";
import { Question } from "../redux/pre-survey/types";

const TYPE = "Presurvey";

interface Props {
  questions: Question[];
}

class PreSurvey extends React.Component<Props> {
  constructor(props: Props) {
    super(props);
  }

  render() {
    return (
      <SurveyEngine
        title="Presurvey Page"
        questions={this.props.questions} type={TYPE} />
    );
  }
}


const mapStateToProps = (state: ApplicationState) => {
  return {
    questions: state.preSurveyState.questions.filter(item => item.source === TYPE)
  };
};

export default connect(
  mapStateToProps,
  null
)(PreSurvey);
