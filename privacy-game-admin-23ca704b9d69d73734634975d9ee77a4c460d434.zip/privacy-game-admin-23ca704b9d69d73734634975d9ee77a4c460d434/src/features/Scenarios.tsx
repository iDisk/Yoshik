import * as React from "react";
import GenericTable from "../components/GenericTable";
import { ApplicationState } from "../redux/reducers";
import { connect } from "react-redux";
import { bindActionCreators, Dispatch } from "redux";
import { deleteScenario, createScenario, deleteScenarioTranslation, getScenarios, saveScenario } from "../redux/pre-survey/scenarios-actions";
import { Translation, Scenario } from "../redux/pre-survey/types";
import GenericModal from "../components/GenericModal";
import GenericTranslationModal from "../components/GenericTranslationModal";
import { Button } from "antd";

interface Props {
  loading: boolean;
  scenarios: Scenario[];
  deleteScenario: any;
  createScenario: any;
  saveScenario: any;
  getScenarios: any
  onTranslationClick: any
  onOrderChange: any;
  deleteScenarioTranslation: any;
}

interface State {
  showModal: boolean;
  selectedItem?: Scenario;
  showTranslationModal: boolean;
  selectedTranslation?: Translation
}

class Scenarios extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      showModal: false,
      showTranslationModal: false,
      selectedItem: undefined
    }
  }

  componentDidMount() {
    this.props.getScenarios();
  }

  openModal = (item?: Scenario) => {
    this.setState({
      showModal: true,
      selectedItem: item
    });
  }

  openTranslationModal = (selectedItem: Scenario, translation?: Translation) => {
    this.setState({
      showTranslationModal: true,
      selectedItem,
      selectedTranslation: translation
    });
  }
  saveTranslation = (item: Scenario) => {
    this.props.saveScenario(item);

    this.closeModal();
  }
  saveLearningComponent = (item: Scenario) => {
    if (this.state.selectedItem) {
      this.props.saveScenario(item);
    } else {
      this.props.createScenario(item);
    }
    this.closeModal();
  }

  closeModal = () => {
    this.setState({
      showModal: false,
      showTranslationModal: false
    });
  }
  onEdit = (item: Scenario) => {
    this.setState({
      selectedItem: item,
      showModal: true
    })
  }
  onAddTranslationClick = (item: Scenario) => {
    this.setState({
      selectedItem: item,
      showTranslationModal: true,
      selectedTranslation: undefined
    })
  }
  render() {
    const { selectedItem, showModal, showTranslationModal, selectedTranslation } = this.state;
    return (
      <div>
        <h1>Scenarios</h1>
        <div style={{ marginBottom: 16 }}>
          <Button type="primary" onClick={() => this.openModal(undefined)}>
            Add Scenario
          </Button>
        </div>
        <GenericModal onSubmit={this.saveLearningComponent}
          onCancel={this.closeModal}
          visible={showModal}
          selectedItem={selectedItem}
          loading={false}
        />
        <GenericTranslationModal onSubmit={this.saveTranslation}
          onCancel={this.closeModal}
          visible={showTranslationModal}
          selectedItem={selectedItem}
          selectedTranslation={selectedTranslation}
          loading={false}
        />
        <GenericTable items={this.props.scenarios}
          onDeleteRow={this.props.deleteScenario}
          showOrder={true}
          onEditRow={this.onEdit}
          onDeleteTranslation={this.props.deleteScenarioTranslation}
          onEditTranslation={(item: Scenario, translation: Translation) => this.openTranslationModal(item, translation)}
          onTranslationClick={this.onAddTranslationClick}
          onOrderChange={this.props.saveScenario} />
      </div>
    )
  }
}

const mapStateToProps = (state: ApplicationState) => {
  return {
    scenarios: state.preSurveyState.scenarios
  };
};

const mapDispatchToProps = (dispatch: Dispatch) => {
  return bindActionCreators(
    {
      deleteScenario,
      createScenario,
      saveScenario,
      getScenarios,
      deleteScenarioTranslation
    },
    dispatch
  );
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Scenarios);