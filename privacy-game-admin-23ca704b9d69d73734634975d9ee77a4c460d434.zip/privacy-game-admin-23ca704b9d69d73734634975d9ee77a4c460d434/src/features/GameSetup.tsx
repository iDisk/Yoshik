import * as React from "react";
import { connect } from "react-redux";
// import { Button, Table } from "antd";
import { ApplicationState } from "../redux/reducers";
import { bindActionCreators, Dispatch } from "redux";
import { Button } from "antd";
import { Scene, Scenario, LearningComponent } from "../redux/pre-survey/types";
import { getScenes, createScene, deleteScene, saveScene } from "../redux/pre-survey/scenes-actions";
import SceneTable from "../components/SceneTable";
import SceneModal from "../components/SceneModal";
import { getScenarios } from "../redux/pre-survey/scenarios-actions";
import { getLearningComponents } from "../redux/pre-survey/learning-components-actions";

interface Props {
    loading: boolean;
    getScenes: any
    scenes: Scene[]
    deleteScene: any
    saveScene: any
    createScene: any
    scenarios: Scenario[]
    learningComponents: LearningComponent[]
    getScenarios: any
    getLearningComponents: any
}

interface State {
    showModal: boolean;
    selectedItem?: Scene
}
export class GameSetup extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props);
        this.state = {
            showModal: false,
            selectedItem: undefined
        }
    }
    onEdit = (item: Scene) => {
        this.setState({
            selectedItem: item,
            showModal: true
        })
    }
    openModal = (item?: Scene) => {
        this.setState({
            showModal: true,
            selectedItem: item
        });
    }
    closeModal = () => {
        this.setState({
            showModal: false,
            selectedItem: undefined
        });
    }
    componentDidMount() {
        this.props.getScenes();
        this.props.getScenarios();
        this.props.getLearningComponents();
    }

    saveGameScene = (item: Scene) => {
        if (this.state.selectedItem) {
            this.props.saveScene(item);
        } else {
            this.props.createScene(item);
        }
        this.closeModal();
    }
    render() {
        const { showModal, selectedItem } = this.state;
        return (
            <div>
                <h1>Scenes Setup page</h1>
                <div style={{ marginBottom: 16 }}>
                    <Button type="primary" onClick={() => this.openModal(undefined)}>
                        Add Scene
                    </Button>
                </div>
                <SceneModal
                    loading={false}
                    learningComponents={this.props.learningComponents}
                    scenarios={this.props.scenarios}
                    onSubmit={this.saveGameScene}
                    onCancel={this.closeModal}
                    visible={showModal}
                    selectedItem={selectedItem} />
                <SceneTable items={this.props.scenes}
                    onDeleteRow={this.props.deleteScene}
                    onEditRow={this.onEdit}
                    onOrderChange={this.props.saveScene} />
            </div>
        );
    }
}

const mapStateToProps = (state: ApplicationState) => {
    return {
        learningComponents: state.preSurveyState.learningComponents,
        scenes: state.preSurveyState.scenes,
        scenarios: state.preSurveyState.scenarios
    };
};

const mapDispatchToProps = (dispatch: Dispatch) => {
    return bindActionCreators(
        {
            getScenes,
            deleteScene,
            saveScene,
            getScenarios,
            getLearningComponents,
            createScene
        },
        dispatch
    );
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(GameSetup);
