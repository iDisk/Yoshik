import * as React from "react";
import GenericTable from "../components/GenericTable";
import { ApplicationState } from "../redux/reducers";
import { connect } from "react-redux";
import { bindActionCreators, Dispatch } from "redux";
import { deleteTerm, deleteTermTranslation, getTerms, saveTerm, createTerm } from "../redux/pre-survey/terms-actions";
import { Term, Translation } from "../redux/pre-survey/types";
import GenericModal from "../components/GenericModal";
import GenericTranslationModal from "../components/GenericTranslationModal";
import { Button } from "antd";

interface Props {
  loading: boolean;
  terms: Term[];
  deleteTerm: any;
  createTerm: any;
  saveTerm: any;
  getTerms: any
  onTranslationClick: any
  deleteTermTranslation: any
}

interface State {
  showModal: boolean;
  selectedItem?: Term;
  showTranslationModal: boolean;
  selectedTranslation?: Translation
}

class Terms extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      showModal: false,
      showTranslationModal: false,
      selectedItem: undefined
    }
  }

  componentDidMount() {
    this.props.getTerms();
  }

  openModal = (item?: Term) => {
    this.setState({
      showModal: true,
      selectedItem: item
    });
  }

  openTranslationModal = (selectedItem: Term, translation?: Translation) => {
    this.setState({
      showTranslationModal: true,
      selectedItem,
      selectedTranslation: translation
    });
  }
  saveTranslation = (item: Term) => {
    item.order = 1;
    this.props.saveTerm(item);
    this.closeModal();
  }
  saveTerm = (item: Term) => {
    item.order = 1;
    if (this.state.selectedItem) {
      this.props.saveTerm(item);
    } else {
      this.props.createTerm(item);
    }
    this.closeModal();
  }

  closeModal = () => {
    this.setState({
      showModal: false,
      showTranslationModal: false
    });
  }
  onEdit = (item: Term) => {
    this.setState({
      selectedItem: item,
      showModal: true
    })
  }
  onAddTranslationClick = (item: Term) => {
    this.setState({
      selectedItem: item,
      showTranslationModal: true,
      selectedTranslation: undefined
    })
  }
  render() {
    const { selectedItem, showModal, showTranslationModal, selectedTranslation } = this.state;
    return (
      <div>
        <h1>Terms</h1>
        <div style={{ marginBottom: 16 }}>
          <Button type="primary" disabled={this.props.saveTerm && this.props.terms.length >= 1} onClick={() => this.openModal(undefined)}>
            Add Terms
          </Button>
        </div>
        <GenericModal onSubmit={this.saveTerm}
          onCancel={this.closeModal}
          visible={showModal}
          selectedItem={selectedItem}
          loading={false}
        />
        <GenericTranslationModal onSubmit={this.saveTranslation}
          onCancel={this.closeModal}
          visible={showTranslationModal}
          selectedItem={selectedItem}
          selectedTranslation={selectedTranslation}
          loading={false}
        />
        <GenericTable items={this.props.terms}
          onDeleteRow={this.props.deleteTerm}
          showOrder={false}
          onEditRow={this.onEdit}
          onDeleteTranslation={this.props.deleteTermTranslation}
          onEditTranslation={(item: Term, translation: Translation) => this.openTranslationModal(item, translation)}
          onTranslationClick={this.onAddTranslationClick}
          onOrderChange={this.props.saveTerm} />
      </div>
    )
  }
}

const mapStateToProps = (state: ApplicationState) => {
  return {
    terms: state.preSurveyState.terms
  };
};

const mapDispatchToProps = (dispatch: Dispatch) => {
  return bindActionCreators(
    {
      deleteTerm, deleteTermTranslation, getTerms, saveTerm, createTerm
    },
    dispatch
  );
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Terms);