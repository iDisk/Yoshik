import * as React from "react";

interface Props {
  loading: boolean;
}

export class Home extends React.Component<Props> {
  render() {
    return (
      <div>
        <h1>Home page</h1>
      </div>
    );
  }
}

export default Home;
