import { ActionCreator, Action } from "redux";
import { ThunkAction } from "redux-thunk";
import { ApplicationState } from "../reducers";
import { HttpRequest, ApiAction } from "../../utils/http";
import { ActionType } from "./action-types";

export type ActionThunk = ThunkAction<
  Action,
  ApplicationState,
  HttpRequest,
  ApiAction
  >;

export const getResults: ActionCreator<ActionThunk> = () => (
  dispatch,
  _,
  api
): Action =>
  dispatch(
    api.get(`results`, {
      onSuccess: ActionType.RESULTS_RECEIVED,
      onError: ActionType.ERROR_WHEN_GETTING_RESULTS
    })
  );
