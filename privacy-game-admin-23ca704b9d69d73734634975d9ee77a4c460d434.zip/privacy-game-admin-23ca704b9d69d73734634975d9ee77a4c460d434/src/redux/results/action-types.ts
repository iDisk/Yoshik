import { Action } from "redux";

import { Results } from "./types";

export enum ActionType {
  GET_RESULTS = "@@analytics/GET_RESULTS",
  RESULTS_RECEIVED = "@@analytics/RESULTS_RECEIVED",
  ERROR_WHEN_GETTING_RESULTS = "@@analytics/ERROR_WHEN_GETTING_RESULTS"
}

export interface GetResultsAction extends Action {
  type: ActionType.GET_RESULTS;
}

export interface ResultsReceivedAction extends Action {
  type: ActionType.RESULTS_RECEIVED;
  payload: Results;
}

export type Actions = GetResultsAction | ResultsReceivedAction;
