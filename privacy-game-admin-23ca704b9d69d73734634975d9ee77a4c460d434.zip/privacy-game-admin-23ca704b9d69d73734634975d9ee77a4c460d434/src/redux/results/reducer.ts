import { Reducer } from "redux";

import { Results } from "./types";
import { ActionType, Actions } from "./action-types";

export interface AnalyticsState {
  results: Results;
}

const initialResults: Results = {
  headers: [],
  data: []
};

const initialState: AnalyticsState = {
  results: initialResults
};

const postSurveyReducer: Reducer<AnalyticsState> = (
  state: AnalyticsState = initialState,
  action: Actions
): AnalyticsState => {
  switch (action.type) {
    case ActionType.RESULTS_RECEIVED:
      return { ...state, results: action.payload };
    default:
      return state;
  }
};

export default postSurveyReducer;
