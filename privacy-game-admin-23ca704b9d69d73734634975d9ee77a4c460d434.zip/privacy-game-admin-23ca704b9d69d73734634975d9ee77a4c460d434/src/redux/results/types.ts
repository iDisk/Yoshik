export interface Result {
  questionText: string;
  questionId: string;
  selectedOptionText: string;
  score: number;
}

export interface Results {
  headers: [];
  data: Result[];
}
