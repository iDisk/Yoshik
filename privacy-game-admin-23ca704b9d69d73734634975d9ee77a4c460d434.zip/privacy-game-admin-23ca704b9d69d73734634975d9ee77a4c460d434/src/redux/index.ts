import createHistory from "history/createBrowserHistory";

import initialiseStore from "./initialiseStore";

export const history = createHistory();

export const store = initialiseStore(history);
