import { combineReducers } from "redux";
import PreSurveyReducer, { PreSurveyState } from "./pre-survey/reducer";
import ResultsReducer, { AnalyticsState } from "./results/reducer";
import CategoriesReducer, { CategoryState } from "./categories/reducer";

export interface ApplicationState {
  preSurveyState: PreSurveyState;
  analyticsState: AnalyticsState;
  categoryState: CategoryState
}

const rootReducer = combineReducers<ApplicationState>({
  preSurveyState: PreSurveyReducer,
  analyticsState: ResultsReducer,
  categoryState: CategoriesReducer
});

export default rootReducer;
