import { ActionCreator, Action } from "redux";
import { ThunkAction } from "redux-thunk";
import { ApplicationState } from "../reducers";
import { HttpRequest, ApiAction } from "../../utils/http";

import { Question } from "./types";
import { ActionType } from "./action-types";

export type ActionThunk = ThunkAction<
  Action,
  ApplicationState,
  HttpRequest,
  ApiAction
  >;

export const saveQuestion: ActionCreator<ActionThunk> = (
  newQuestion: Question
) => {
  return (dispatch, _, api): Action => {
    return dispatch(
      api.put(`question`, {
        params: newQuestion,
        onError: ActionType.ERROR_WHEN_CREATING_QUESTION,
        onSuccess: questionsReceivedProxy
      })
    );
  };
};

export const createQuestion: ActionCreator<ActionThunk> = (
  newQuestion: Question
) => {
  return (dispatch, _, api): Action => {
    delete newQuestion._id;
    return dispatch(
      api.post(`question`, {
        params: newQuestion,
        onError: ActionType.ERROR_WHEN_CREATING_QUESTION,
        onSuccess: questionsReceivedProxy
      })
    );
  };
};

export const getQuestions: ActionCreator<ActionThunk> = (source: string) => (
  dispatch,
  _,
  api
): Action => {
  return dispatch(
    api.get(`question?source=${source}`, {
      onSuccess: ActionType.QUESTIONS_RECEIVED,
      onError: ActionType.ERROR_WHEN_CREATING_QUESTION
    })
  );
}

export const deleteQuestion: ActionCreator<ActionThunk> = (questionId: string) => (
  dispatch,
  _,
  api
): Action => {
  return dispatch(
    api.delete(`question/${questionId}`, {
      onSuccess: questionsReceivedProxy,
      onError: ActionType.ERROR_WHEN_GETTING_QUESTIONS
    })
  );
}

export const deleteQuestionTranslation: ActionCreator<ActionThunk> = (questionId: string, translationId: string) => (
  dispatch,
  _,
  api
): Action => {
  return dispatch(
    api.delete(`question/${questionId}/translation/${translationId}`, {
      onSuccess: questionsReceivedProxy,
      onError: ActionType.ERROR_WHEN_GETTING_QUESTIONS
    })
  );
}

export const deleteAnswerTranslation: ActionCreator<ActionThunk> = (questionId: string, translationId: string, answerId: string) => (
  dispatch,
  _,
  api
): Action => {
  return dispatch(
    api.delete(`question/${questionId}/translation/${translationId}/answer/${answerId}`, {
      onSuccess: questionsReceivedProxy,
      onError: ActionType.ERROR_WHEN_GETTING_QUESTIONS
    })
  );
}

export const deleteAnswer: ActionCreator<ActionThunk> = (questionId: string, answerId: string) => (
  dispatch,
  _,
  api
): Action => {
  return dispatch(
    api.delete(`question/${questionId}/answer/${answerId}`, {
      onSuccess: questionsReceivedProxy,
      onError: ActionType.ERROR_WHEN_GETTING_QUESTIONS
    })
  );
}

export const deleteSubQuestion: ActionCreator<ActionThunk> = (questionId: string, subQuestionId: string) => (
  dispatch,
  _,
  api
): Action => {
  return dispatch(
    api.delete(`question/${questionId}/subquestion/${subQuestionId}`, {
      onSuccess: questionsReceivedProxy,
      onError: ActionType.ERROR_WHEN_GETTING_QUESTIONS
    })
  );
}

export const deleteSubQuestionTranslation: ActionCreator<ActionThunk> = (questionId: string, subQuestionId: string, translationId: string) => (
  dispatch,
  _,
  api
): Action => {
  return dispatch(
    api.delete(`question/${questionId}/translation/${translationId}/subquestion/${subQuestionId}`, {
      onSuccess: questionsReceivedProxy,
      onError: ActionType.ERROR_WHEN_GETTING_QUESTIONS
    })
  );
}

export const deleteSubQuestionAnswer: ActionCreator<ActionThunk> = (questionId: string, subQuestionId: string, answerId: string) => (
  dispatch,
  _,
  api
): Action => {
  return dispatch(
    api.delete(`question/${questionId}/subquestion/${subQuestionId}/answer/${answerId}`, {
      onSuccess: questionsReceivedProxy,
      onError: ActionType.ERROR_WHEN_GETTING_QUESTIONS
    })
  );
}

export const questionsReceivedProxy: ActionCreator<any> = () => {
  return (dispatch: any): any => {
    return dispatch(getQuestions())
  }
}
