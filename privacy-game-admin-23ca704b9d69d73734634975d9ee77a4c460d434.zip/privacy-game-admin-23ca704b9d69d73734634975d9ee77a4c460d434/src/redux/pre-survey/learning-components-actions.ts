import { ActionCreator, Action } from "redux";
import { ThunkAction } from "redux-thunk";
import { ApplicationState } from "../reducers";
import { HttpRequest, ApiAction } from "../../utils/http";

import { LearningComponent } from "./types";
import { ActionType } from "./action-types";

export type ActionThunk = ThunkAction<
    Action,
    ApplicationState,
    HttpRequest,
    ApiAction
    >;

export const saveLearningComponent: ActionCreator<ActionThunk> = (
    newItem: LearningComponent
) => {
    return (dispatch, _, api): Action => {
        return dispatch(
            api.put(`learningcomponent`, {
                params: newItem,
                onError: ActionType.ERROR_WHEN_CREATING_RESOURCE,
                onSuccess: learningComponentsReceivedProxy
            })
        );
    };
};

export const createLearningComponent: ActionCreator<ActionThunk> = (
    newItem: LearningComponent
) => {
    return (dispatch, _, api): Action => {
        delete newItem._id;
        return dispatch(
            api.post(`learningcomponent`, {
                params: newItem,
                onError: ActionType.ERROR_WHEN_CREATING_RESOURCE,
                onSuccess: learningComponentsReceivedProxy
            })
        );
    };
};

export const getLearningComponents: ActionCreator<ActionThunk> = () => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.get(`learningcomponent`, {
            onSuccess: ActionType.LEARNING_COMPONENTS_RECEIVED,
            onError: ActionType.ERROR_WHEN_CREATING_RESOURCE
        })
    );
}

export const deleteLearningComponent: ActionCreator<ActionThunk> = (id: string) => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.delete(`learningcomponent/${id}`, {
            onSuccess: learningComponentsReceivedProxy,
            onError: ActionType.ERROR_WHEN_CREATING_RESOURCE
        })
    );
}

export const deleteLearningComponentTranslation: ActionCreator<ActionThunk> = (id: string, translationId: string) => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.delete(`learningcomponent/${id}/translation/${translationId}`, {
            onSuccess: learningComponentsReceivedProxy,
            onError: ActionType.ERROR_WHEN_GETTING_RESOURCE
        })
    );
}


export const learningComponentsReceivedProxy: ActionCreator<any> = () => {
    return (dispatch: any): any => {
        return dispatch(getLearningComponents())
    }
}
