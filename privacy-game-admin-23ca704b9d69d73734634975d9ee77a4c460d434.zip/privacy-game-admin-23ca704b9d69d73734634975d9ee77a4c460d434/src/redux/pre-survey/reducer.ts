import { Reducer } from "redux";

import { Question, LearningComponent, Scenario, Scene, Term } from "./types";
import { ActionType, Actions } from "./action-types";

export interface PreSurveyState {
  questions: Question[];
  learningComponents: LearningComponent[];
  scenarios: Scenario[];
  scenes: Scene[];
  terms: Term[];
}

const initialQuestions: Question[] = [];
const initialLearningComponents: LearningComponent[] = [];
const initialScenarios: Scenario[] = [];
const initialScenes: Scene[] = [];
const initialTerms: Term[] = [];

const initialState: PreSurveyState = {
  questions: initialQuestions,
  learningComponents: initialLearningComponents,
  scenarios: initialScenarios,
  scenes: initialScenes,
  terms: initialTerms
};

const questionsReducer: Reducer<PreSurveyState> = (
  state: PreSurveyState = initialState,
  action: Actions
): PreSurveyState => {
  switch (action.type) {
    case ActionType.QUESTIONS_RECEIVED:
      return { ...state, questions: action.payload };
    case ActionType.LEARNING_COMPONENTS_RECEIVED:
      return { ...state, learningComponents: action.payload };
    case ActionType.SCENARIOS_RECEIVED:
      return { ...state, scenarios: action.payload };
    case ActionType.SCENES_RECEIVED:
      return { ...state, scenes: action.payload };
    case ActionType.TERMS_RECEIVED:
      return { ...state, terms: action.payload };
    default:
      return state;
  }
};

export default questionsReducer;
