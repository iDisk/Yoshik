import { Action } from "redux";
import { ApiAction } from "../../utils/http";

import { Question, LearningComponent, Scenario, Scene, Term } from "./types";

export enum ActionType {
  GET_QUESTIONS = "@@presurvey/GET_QUESTIONS",
  GET_SCENARIOS = "GET_SCENARIOS",
  GET_SCENES = "GET_SCENES",
  GET_LEARNING_COMPONENTS = "GET_LEARNING_COMPONENTS",
  QUESTIONS_RECEIVED = "@@presurvey/QUESTIONS_RECEIVED",
  CREATE_QUESTION = "@@presurvey/CREATE_QUESTION",
  UPDATE_QUESTION = "@@presurvey/UPDATE_QUESTION",
  QUESTION_CREATED_SUCCESSFULLY = "@@presurvey/QUESTION_CREATED_SUCCESSFULLY",
  ERROR_WHEN_CREATING_QUESTION = "@@presurvey/ERROR_WHEN_CREATING_QUESTION",
  ERROR_WHEN_GETTING_QUESTIONS = "@@presurvey/ERROR_WHEN_GETTING_QUESTIONS",
  LEARNING_COMPONENTS_RECEIVED = "LEARNING_COMPONENTS_RECEIVED",
  SCENARIOS_RECEIVED = "SCENARIOS_RECEIVED",
  SCENES_RECEIVED = "SCENES_RECEIVED",
  RESOURCE_CREATED_SUCCESSFULLY = "RESOURCE_CREATED_SUCCESSFULLY",
  ERROR_WHEN_CREATING_RESOURCE = "ERROR_WHEN_CREATING_QUESTION",
  ERROR_WHEN_GETTING_RESOURCE = "ERROR_WHEN_GETTING_RESOURCE",
  TERMS_RECEIVED = "TERMS_RECEIVED",
  GET_TERMS = "GET_TERMS"
}

export interface GetLearningComponentsAction extends Action {
  type: ActionType.GET_LEARNING_COMPONENTS;
}

export interface GetScenariosAction extends Action {
  type: ActionType.GET_SCENARIOS;
}

export interface GetScenesAction extends Action {
  type: ActionType.GET_SCENES;
}

export interface GetTermsAction extends Action {
  type: ActionType.GET_TERMS;
}

export interface GetQuestionsAction extends Action {
  type: ActionType.GET_QUESTIONS;
}

export interface ScenariosReceivedAction extends Action {
  type: ActionType.SCENARIOS_RECEIVED;
  payload: Scenario[];
}

export interface ScenesReceivedAction extends Action {
  type: ActionType.SCENES_RECEIVED;
  payload: Scene[];
}

export interface TermsReceivedAction extends Action {
  type: ActionType.TERMS_RECEIVED;
  payload: Term[];
}

export interface LearningComponentsReceivedAction extends Action {
  type: ActionType.LEARNING_COMPONENTS_RECEIVED;
  payload: LearningComponent[];
}

export interface QuestionsReceivedAction extends Action {
  type: ActionType.QUESTIONS_RECEIVED;
  payload: Question[];
}

export interface CreateLearningComponentSuccess extends Action {
  type: ActionType.RESOURCE_CREATED_SUCCESSFULLY;
  payload: LearningComponent;
}

export interface CreateScenarioSuccess extends Action {
  type: ActionType.RESOURCE_CREATED_SUCCESSFULLY;
  payload: Scenario;
}

export interface CreateQuestionSuccess extends Action {
  type: ActionType.QUESTION_CREATED_SUCCESSFULLY;
  payload: Question;
}

export interface CreateQuestionError extends Action {
  error: Error;
  type: ActionType.ERROR_WHEN_CREATING_QUESTION;
}

export interface CreateScenarioError extends Action {
  error: Error;
  type: ActionType.ERROR_WHEN_CREATING_RESOURCE;
}

export interface CreateLearningComponentError extends Action {
  error: Error;
  type: ActionType.ERROR_WHEN_CREATING_RESOURCE;
}

export type Actions =
  | GetQuestionsAction
  | QuestionsReceivedAction
  | CreateQuestionSuccess
  | CreateQuestionError
  | GetScenariosAction
  | GetLearningComponentsAction
  | LearningComponentsReceivedAction
  | ScenariosReceivedAction
  | ScenesReceivedAction
  | TermsReceivedAction
  | GetTermsAction;

export type CreateQuestionAsync = (newQuestion: Question) => ApiAction;
