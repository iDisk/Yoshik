import { ActionCreator, Action } from "redux";
import { ThunkAction } from "redux-thunk";
import { ApplicationState } from "../reducers";
import { HttpRequest, ApiAction } from "../../utils/http";

import { Scenario } from "./types";
import { ActionType } from "./action-types";

export type ActionThunk = ThunkAction<
    Action,
    ApplicationState,
    HttpRequest,
    ApiAction
    >;

const RESOURCE = "scenario";

export const saveScenario: ActionCreator<ActionThunk> = (
    newItem: Scenario
) => {
    return (dispatch, _, api): Action => {
        return dispatch(
            api.put(`${RESOURCE}`, {
                params: newItem,
                onError: ActionType.ERROR_WHEN_CREATING_RESOURCE,
                onSuccess: scenariosReceivedProxy
            })
        );
    };
};

export const createScenario: ActionCreator<ActionThunk> = (
    newItem: Scenario
) => {
    return (dispatch, _, api): Action => {
        delete newItem._id;
        return dispatch(
            api.post(`${RESOURCE}`, {
                params: newItem,
                onError: ActionType.ERROR_WHEN_CREATING_RESOURCE,
                onSuccess: scenariosReceivedProxy
            })
        );
    };
};

export const getScenarios: ActionCreator<ActionThunk> = () => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.get(`${RESOURCE}`, {
            onSuccess: ActionType.SCENARIOS_RECEIVED,
            onError: ActionType.ERROR_WHEN_CREATING_RESOURCE
        })
    );
}

export const deleteScenario: ActionCreator<ActionThunk> = (id: string) => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.delete(`${RESOURCE}/${id}`, {
            onSuccess: scenariosReceivedProxy,
            onError: ActionType.ERROR_WHEN_CREATING_RESOURCE
        })
    );
}

export const deleteScenarioTranslation: ActionCreator<ActionThunk> = (id: string, translationId: string) => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.delete(`${RESOURCE}/${id}/translation/${translationId}`, {
            onSuccess: scenariosReceivedProxy,
            onError: ActionType.ERROR_WHEN_GETTING_RESOURCE
        })
    );
}


export const scenariosReceivedProxy: ActionCreator<any> = () => {
    return (dispatch: any): any => {
        return dispatch(getScenarios())
    }
}
