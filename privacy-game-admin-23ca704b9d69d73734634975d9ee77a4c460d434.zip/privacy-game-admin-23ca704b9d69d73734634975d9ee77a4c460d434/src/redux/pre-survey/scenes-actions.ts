import { ActionCreator, Action } from "redux";
import { ThunkAction } from "redux-thunk";
import { ApplicationState } from "../reducers";
import { HttpRequest, ApiAction } from "../../utils/http";

import { Scene } from "./types";
import { ActionType } from "./action-types";

export type ActionThunk = ThunkAction<
    Action,
    ApplicationState,
    HttpRequest,
    ApiAction
    >;

const RESOURCE = "scene";

export const saveScene: ActionCreator<ActionThunk> = (
    newItem: Scene
) => {
    return (dispatch, _, api): Action => {
        return dispatch(
            api.put(`${RESOURCE}`, {
                params: newItem,
                onError: ActionType.ERROR_WHEN_CREATING_RESOURCE,
                onSuccess: scenesReceivedProxy
            })
        );
    };
};

export const createScene: ActionCreator<ActionThunk> = (
    newItem: Scene
) => {
    return (dispatch, _, api): Action => {
        delete newItem._id;
        return dispatch(
            api.post(`${RESOURCE}`, {
                params: newItem,
                onError: ActionType.ERROR_WHEN_CREATING_RESOURCE,
                onSuccess: scenesReceivedProxy
            })
        );
    };
};

export const getScenes: ActionCreator<ActionThunk> = () => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.get(`${RESOURCE}`, {
            onSuccess: ActionType.SCENES_RECEIVED,
            onError: ActionType.ERROR_WHEN_CREATING_RESOURCE
        })
    );
}

export const deleteScene: ActionCreator<ActionThunk> = (id: string) => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.delete(`${RESOURCE}/${id}`, {
            onSuccess: scenesReceivedProxy,
            onError: ActionType.ERROR_WHEN_CREATING_RESOURCE
        })
    );
}


export const scenesReceivedProxy: ActionCreator<any> = () => {
    return (dispatch: any): any => {
        return dispatch(getScenes())
    }
}
