import { ActionCreator, Action } from "redux";
import { ThunkAction } from "redux-thunk";
import { ApplicationState } from "../reducers";
import { HttpRequest, ApiAction } from "../../utils/http";

import { Term } from "./types";
import { ActionType } from "./action-types";

export type ActionThunk = ThunkAction<
    Action,
    ApplicationState,
    HttpRequest,
    ApiAction
    >;

const RESOURCE = "term";

export const saveTerm: ActionCreator<ActionThunk> = (
    newItem: Term
) => {
    return (dispatch, _, api): Action => {
        return dispatch(
            api.put(`${RESOURCE}`, {
                params: newItem,
                onError: ActionType.ERROR_WHEN_CREATING_RESOURCE,
                onSuccess: termsReceivedProxy
            })
        );
    };
};

export const createTerm: ActionCreator<ActionThunk> = (
    newItem: Term
) => {
    return (dispatch, _, api): Action => {
        delete newItem._id;
        return dispatch(
            api.post(`${RESOURCE}`, {
                params: newItem,
                onError: ActionType.ERROR_WHEN_CREATING_RESOURCE,
                onSuccess: termsReceivedProxy
            })
        );
    };
};

export const getTerms: ActionCreator<ActionThunk> = () => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.get(`${RESOURCE}`, {
            onSuccess: ActionType.TERMS_RECEIVED,
            onError: ActionType.ERROR_WHEN_CREATING_RESOURCE
        })
    );
}

export const deleteTerm: ActionCreator<ActionThunk> = (id: string) => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.delete(`${RESOURCE}/${id}`, {
            onSuccess: termsReceivedProxy,
            onError: ActionType.ERROR_WHEN_CREATING_RESOURCE
        })
    );
}

export const deleteTermTranslation: ActionCreator<ActionThunk> = (id: string, translationId: string) => (
    dispatch,
    _,
    api
): Action => {
    return dispatch(
        api.delete(`${RESOURCE}/${id}/translation/${translationId}`, {
            onSuccess: termsReceivedProxy,
            onError: ActionType.ERROR_WHEN_GETTING_RESOURCE
        })
    );
}


export const termsReceivedProxy: ActionCreator<any> = () => {
    return (dispatch: any): any => {
        return dispatch(getTerms())
    }
}
