export interface Question {
  _id: string;
  text: string;
  category: string;
  type: string;
  answers: Answer[];
  translations: Translation[]
  isParent?: boolean;
  order: number;
  source: string;
  allowMultipleSelection: boolean;
  randomise: boolean;
  // startLabel?: string;
  // endLabel?: string;
  // minValue?: number;
  numberOfAnswers?: number;
  subQuestions?: SubQuestion[];
}

export interface SubQuestion {
  _id?: string;
  text: string;
  translations: Translation[];
  answers: Answer[];
}

export interface Category {
  text: string;
  _id: string;
  value: string;
  key: string;
}

export interface QuestionType {
  id: string;
  text: string;
  value: string;
  key: string;
}

export interface Answer {
  _id?: string;
  text: string;
  score: number;
  label?: string;
  name?: string;
  key?: string;
  isLastFixed: boolean;
  // disabled?: boolean;
}

export interface Translation {
  _id: string;
  text: string;
  language: "es" | "mx" | "";
  children?: any;
  answers?: Answer[];
}

export interface LearningComponent {
  _id: string;
  title: string;
  text: string;
  translations: Translation[]
  order: number;
  selectedTranslation?: Translation;
  language?: "es" | "mx" | "";
}

export interface Scenario {
  _id: string;
  title: string;
  text: string;
  translations: Translation[]
  order: number;
  selectedTranslation?: Translation;
  language?: "es" | "mx" | "";
}

export interface Scene {
  _id: string;
  title: string;
  learningComponentId: string;
  scenarioId: string;
  nextScenarioIfYesId: string;
  nextScenarioIfNoId: string;
  order: number;
  learningComponentTitle?: string;
  scenarioTitle?: string;
  nextScenarioIfYesText?: string;
  nextScenarioIfNoText?: string;
}

export interface Term {
  _id: string;
  title: string;
  text: string;
  translations: Translation[]
  order: number;
  selectedTranslation?: Translation;
  language?: "es" | "mx" | "";
}