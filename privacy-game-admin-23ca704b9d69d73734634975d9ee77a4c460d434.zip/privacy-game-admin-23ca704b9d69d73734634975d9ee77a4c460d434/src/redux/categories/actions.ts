import { ActionCreator, Action } from "redux";
import { ThunkAction } from "redux-thunk";
import { ApplicationState } from "../reducers";
import { HttpRequest, ApiAction } from "../../utils/http";
import { ActionType } from "./action-types";

export type ActionThunk = ThunkAction<
  Action,
  ApplicationState,
  HttpRequest,
  ApiAction
  >;

export const getCategories: ActionCreator<ActionThunk> = () => (
  dispatch,
  _,
  api
): Action =>
  dispatch(
    api.get(`category`, {
      onSuccess: ActionType.CATEGORIES_RECEIVED,
      onError: ActionType.ERROR_WHEN_GETTING_CATEGORIES
    })
  );

export const saveCategory: ActionCreator<ActionThunk> = ({ text }) => (
  dispatch,
  _,
  api
): Action => (
    dispatch(
      api.post(`category`, {
        params: { text },
        onSuccess: categoriesRecievedProxy,
        onError: ActionType.ERROR_WHEN_GETTING_CATEGORIES
      })
    )
  )

export const categoriesRecievedProxy: ActionCreator<any> = () => {
  return (dispatch: any): any => {
    return dispatch(getCategories())
  }
}

export const deleteCategory: ActionCreator<ActionThunk> = (categoryId: string) => (
  dispatch,
  _,
  api
): Action => {
  return dispatch(
    api.delete(`category/${categoryId}`, {
      onSuccess: categoriesRecievedProxy,
      onError: ActionType.ERROR_WHEN_GETTING_CATEGORIES
    })
  );
}

