import { Action } from "redux";

import { Category } from "../pre-survey/types";

export enum ActionType {
  GET_CATEGORIES = "@@categories/GET_CATEGORIES",
  CATEGORIES_RECEIVED = "@@categories/CATEGORIES_RECEIVED",
  ERROR_WHEN_GETTING_CATEGORIES = "@@categories/ERROR_WHEN_GETTING_CATEGORIES",
  CATEGORY_SAVED = "@@categories/CATEGORY_SAVED"
}

export interface GetCategoriesAction extends Action {
  type: ActionType.GET_CATEGORIES;
}

export interface CategoriesReceivedAction extends Action {
  type: ActionType.CATEGORIES_RECEIVED;
  payload: Category[];
}

export type Actions = GetCategoriesAction | CategoriesReceivedAction;
