import { Reducer } from "redux";

import { Category } from "../pre-survey/types";
import { ActionType, Actions } from "./action-types";

export interface CategoryState {
  categories: Category[];
}

const initialCategories: Category[] = [];

const initialState: CategoryState = {
  categories: initialCategories
};

const categoriesReducer: Reducer<CategoryState> = (
  state: CategoryState = initialState,
  action: Actions
): CategoryState => {
  switch (action.type) {
    case ActionType.CATEGORIES_RECEIVED:
      const newPayload = action.payload.map((item) => {
        item.value = item.text;
        item.key = item._id;
        return item;
      })
      return { ...state, categories: newPayload };
    default:
      return state;
  }
};

export default categoriesReducer;
