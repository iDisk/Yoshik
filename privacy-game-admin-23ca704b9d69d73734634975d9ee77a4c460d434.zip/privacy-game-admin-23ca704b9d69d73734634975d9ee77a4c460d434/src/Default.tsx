import * as React from "react";
import { NavLink } from "react-router-dom";
import Auth from './Auth';

import { Layout, Menu, Icon } from "antd";

const { Sider, Content, Footer } = Layout;

interface DefaultProps {
  children: React.ReactNode;
}

interface State {
  activeItem: string;
  collapsed: boolean;
}

export class DefaultLayout extends React.Component<DefaultProps, State> {
  constructor(props: DefaultProps) {
    super(props);
    this.state = {
      collapsed: false,
      activeItem: "1"
    };
  }
  componentDidMount() {
    const auth = new Auth();
    if (!auth.isAuthenticated()) {
      auth.login();
    }
  }
  handleItemClick = (e: React.SyntheticEvent, { name }: any) =>
    this.setState({ activeItem: name, collapsed: false });

  onCollapse = (collapsed: boolean) => {
    this.setState({ collapsed });
  };
  logout = () => {
    const auth = new Auth();
    auth.logout();
  }
  onMenuClick = ({ key }: any) => {
    if (key === "logout") {
      this.logout();
    }
  }
  render() {
    return (
      <Layout style={{ minHeight: "100vh" }}>
        <Sider
          collapsible={false}
          collapsed={this.state.collapsed}
          onCollapse={this.onCollapse}
        >
          <div className="logo" />
          <Menu
            theme="dark"
            mode="inline"
            onClick={this.onMenuClick}
            defaultSelectedKeys={["1"]}
            defaultOpenKeys={["sub1"]}
            style={{ height: "100%", borderRight: 0 }}
          >
            <Menu.Item key="1">
              <NavLink to="/" activeClassName="active-link" exact>
                <Icon type="pie-chart" />
                Home
              </NavLink>
            </Menu.Item>
            <Menu.Item key="2">
              <NavLink to="/presurvey" activeClassName="active-link" exact>
                <Icon type="desktop" />
                Pre Survey
              </NavLink>
            </Menu.Item>
            <Menu.Item key="3">
              <NavLink to="/postsurvey" activeClassName="active-link" exact>
                <Icon type="desktop" />
                Post Survey
              </NavLink>
            </Menu.Item>
            <Menu.Item key="4">
              <NavLink to="/categories" activeClassName="active-link" exact>
                <Icon type="desktop" />
                Categories
              </NavLink>
            </Menu.Item>
            <Menu.Item key="5">
              <NavLink to="/scenarios" activeClassName="active-link" exact>
                <Icon type="desktop" />
                Scenarios
              </NavLink>
            </Menu.Item>
            <Menu.Item key="6">
              <NavLink
                to="/learning-components"
                activeClassName="active-link"
                exact
              >
                <Icon type="desktop" />
                Learning Components
              </NavLink>
            </Menu.Item>
            <Menu.Item key="7">
              <NavLink
                to="/gamesetup"
                activeClassName="active-link"
                exact
              >
                <Icon type="desktop" />
                Game Setup
              </NavLink>
            </Menu.Item>
            {/* <Menu.Item key="8">
              <NavLink to="/terms" activeClassName="active-link" exact>
                <Icon type="desktop" />
                Terms
              </NavLink>
            </Menu.Item> */}
            <Menu.Item key="9">
              <NavLink to="/results" activeClassName="active-link" exact>
                <Icon type="desktop" />
                Results
              </NavLink>
            </Menu.Item>
            <Menu.Item key="logout" style={{ textAlign: "center", position: "absolute", bottom: "0", width: "100%" }}>
              <Icon type="logout" />
              Logout
            </Menu.Item>
          </Menu>

        </Sider>
        <Layout style={{ padding: "0 24px 24px" }}>
          <Content
            style={{
              background: "#fff",
              padding: 24,
              margin: 0,
              minHeight: 280
            }}
          >
            {this.props.children}
          </Content>
          <Footer>Footer</Footer>
        </Layout>
      </Layout>
    );
  }
}

export default DefaultLayout;
