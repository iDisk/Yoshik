import { WebAuth } from 'auth0-js';
import { history } from "./redux"

console.log("process.env", process.env)
const REDIRECT_URI = process.env.NODE_ENV === "development" ? "http://localhost:8080/callback" : "http://ec2-18-130-183-54.eu-west-2.compute.amazonaws.com:4000/callback";

export default class Auth {

  auth0 = new WebAuth({
    domain: 'auroralabs.auth0.com',
    clientID: 'y73Lu0xYMnwpl12ZjW97Wgab0ZQ8sAwZ',
    redirectUri: REDIRECT_URI,
    responseType: 'token id_token',
    scope: 'openid'
  });

  handleAuthentication() {
    this.auth0.parseHash((err, authResult) => {
      if (authResult && authResult.accessToken && authResult.idToken) {
        this.setSession(authResult);
      } else if (err) {
        history.push('/notfound');
      }
    });
  }

  login() {
    this.auth0.authorize();
  }

  setSession(authResult: any) {
    // Set the time that the Access Token will expire at
    const expiresAt = JSON.stringify((authResult.expiresIn * 1000) + new Date().getTime());
    localStorage.setItem('access_token', authResult.accessToken);
    localStorage.setItem('id_token', authResult.idToken);
    localStorage.setItem('expires_at', expiresAt);
    // navigate to the home route
    history.push('/');
  }

  logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('id_token');
    localStorage.removeItem('expires_at');
    // navigate to the home route
    history.push('/');
    window.location.reload();
  }

  isAuthenticated() {
    // Check whether the current time is past the 
    // Access Token's expiry time
    if (localStorage.getItem('expires_at')) {
      const expiresAt = JSON.parse(localStorage.getItem('expires_at') as string);
      return new Date().getTime() < expiresAt;
    }
    return false;
  }
}