import * as React from "react";
import { Spin } from 'antd';

class Callback extends React.Component {
  render() {
    return (
      <div style={{ justifyContent: "center", alignItems: "center", display: "flex", height: "100%", width: "100%" }}>

        <Spin size="large" />
      </div>
    );
  }
}

export default Callback;
