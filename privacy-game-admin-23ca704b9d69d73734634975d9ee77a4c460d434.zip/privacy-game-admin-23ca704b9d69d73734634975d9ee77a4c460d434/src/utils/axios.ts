import axios from "axios";

const PORT = process.env.API_PORT || 3002;
const BASE_URL = "http://ec2-18-130-183-54.eu-west-2.compute.amazonaws.com";

const instance = axios.create({
  baseURL: `${BASE_URL}:${PORT}/api`
});

export default instance;
