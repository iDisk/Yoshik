import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'
import { Action } from 'redux'

import api, { ApiActionType, ApiAction, Method } from './http'

describe('Http', () => {
  const movieSample = {
    name: 'Terminator',
    description: 'Best movie ever'
  }

  const setupMock = () => {
    const mock = new MockAdapter(axios)
    mock.onGet('/testEndpoint').reply(200, movieSample)
  }

  beforeAll(() => {
    setupMock()
  })

  describe('get()', () => {
    it('it should return API Request action type', () => {
      // Arrange
      const expectedAction: ApiAction = {
        type: ApiActionType.API_REQUEST,
        meta: {
          method: Method.GET,
          url: '/testEndpoint',
          onSuccess: 'success',
          onError: 'error'
        },
        payload: ''
      }

      // Act
      const result = api.get('/testEndpoint', {
        onError: 'error',
        onSuccess: 'success'
      })

      // Assert
      expect(result).toEqual(expectedAction)
    })

    it('it should return API Request action type with an Action parameter', () => {
      // Arrange
      const testAction: Action = {
        type: 'Testing'
      }

      const expectedAction: ApiAction = {
        type: ApiActionType.API_REQUEST,
        meta: {
          method: Method.GET,
          url: '/testEndpoint',
          onSuccess: testAction,
          onError: testAction
        },
        payload: ''
      }

      // Act
      const result = api.get('/testEndpoint', {
        onError: testAction,
        onSuccess: testAction
      })

      // Assert
      expect(result).toEqual(expectedAction)
    })
  })

  describe('post()', () => {
    it('it should return API Request action type', () => {
      // Arrange
      const payload = {}

      const expectedAction: ApiAction = {
        type: ApiActionType.API_REQUEST,
        meta: {
          method: Method.POST,
          url: '/testEndpoint',
          onSuccess: 'success',
          onError: 'error'
        },
        payload
      }

      // Act
      const result = api.post('/testEndpoint', {
        params: payload,
        onSuccess: 'success',
        onError: 'error'
      })

      // Assert
      expect(result).toEqual(expectedAction)
    })

    it('it should return API Request action type with an Action parameter', () => {
      // Arrange
      const payload = {}

      const testAction: Action = {
        type: 'Testing'
      }

      const expectedAction: ApiAction = {
        type: ApiActionType.API_REQUEST,
        meta: {
          method: Method.POST,
          url: '/testEndpoint',
          onSuccess: testAction,
          onError: testAction
        },
        payload
      }

      // Act
      const result = api.post('/testEndpoint', {
        params: payload,
        onSuccess: testAction,
        onError: testAction
      })

      // Assert
      expect(result).toEqual(expectedAction)
    })
  })

  describe('delete()', () => {
    const testAction: Action = {
      type: 'Testing'
    }

    const testActionFail: Action = {
      type: 'Testing'
    }
    it('should exist', () => {
      expect(api.delete).toBeDefined()
    })
    it('should return API Request action type', () => {
      // Arrange

      // Act
      const result = api.delete('/testEndpoint', {
        onSuccess: testAction,
        onError: testActionFail
      })

      // Assert
      expect(result.type).toBe(ApiActionType.API_REQUEST)
    })
    it('should not include any object', () => {
      // Arrange

      // Act
      const result = api.delete('/testEndpoint', {
        params: {},
        onSuccess: testAction,
        onError: testActionFail
      })

      // Assert
      expect(result.payload).toBeUndefined()
    })
    it('should set method to DELETE', () => {
      // Arrange

      // Act
      const result = api.delete('/testEndpoint', {
        onSuccess: testAction,
        onError: testActionFail
      })

      // Assert
      expect(result.meta!.method).toEqual(Method.DELETE)
    })
    it('should call the correct URL', () => {
      // Arrange

      // Act
      const result = api.delete('/testEndpoint', {
        onSuccess: testAction,
        onError: testActionFail
      })

      // Assert
      expect(result.meta!.url).toEqual('/testEndpoint')
    })
  })
})
