import "reflect-metadata";
import koaServer from "./koa";

const PORT = process.env.BASE_PORT || 3002;

const server = koaServer.listen(PORT, () => {
  console.log("Server running on", PORT);
});

module.exports = server;
