/* tslint:disable */
import { Controller, ValidateParam, FieldErrors, ValidateError, TsoaRoute } from 'tsoa';
import { GameDataController } from './controllers/GameDataController';
import { ResultsController } from './controllers/ResultsController';
import { LearningComponentController } from './controllers/LearningComponentController';
import { ScenariosController } from './controllers/ScenariosController';
import { QuestionController } from './controllers/QuestionController';
import { CategoryController } from './controllers/CategoryController';
import { ScenesController } from './controllers/ScenesController';
import { TermsController } from './controllers/TermsController';

const models: TsoaRoute.Models = {
    "Boolean": {
    },
    "AnswerData": {
        "properties": {
            "answerId": { "dataType": "string", "required": true },
            "answerText": { "dataType": "string", "required": true },
            "score": { "dataType": "double", "required": true },
            "isLastFixed": { "ref": "Boolean", "required": true },
        },
    },
    "SurveyData": {
        "properties": {
            "questionOrder": { "dataType": "double", "required": true },
            "questionId": { "dataType": "string", "required": true },
            "questionType": { "dataType": "string", "required": true },
            "questionText": { "dataType": "string", "required": true },
            "allowMultipleSelection": { "ref": "Boolean", "required": true },
            "randomiseAnswers": { "ref": "Boolean", "required": true },
            "answers": { "dataType": "array", "array": { "ref": "AnswerData" }, "required": true },
            "subQuestionText": { "dataType": "string", "required": true },
        },
    },
    "SceneData": {
        "properties": {
            "scenarioId": { "dataType": "string", "required": true },
            "scenarioTitle": { "dataType": "string", "required": true },
            "scenarioText": { "dataType": "string", "required": true },
            "order": { "dataType": "double", "required": true },
            "learningComponentId": { "dataType": "string", "required": true },
            "learningComponentTitle": { "dataType": "string", "required": true },
            "learningComponentText": { "dataType": "string", "required": true },
            "nextScenarioIfYesId": { "dataType": "string", "required": true },
            "nextScenarioIfNoId": { "dataType": "string", "required": true },
        },
    },
    "GameData": {
        "properties": {
            "language": { "dataType": "string", "required": true },
            "preSurvey": { "dataType": "array", "array": { "ref": "SurveyData" }, "required": true },
            "postSurvey": { "dataType": "array", "array": { "ref": "SurveyData" }, "required": true },
            "scenes": { "dataType": "array", "array": { "ref": "SceneData" }, "required": true },
        },
    },
    "ScenarioResult": {
        "properties": {
            "scenarioId": { "dataType": "string", "required": true },
            "answer": { "dataType": "string", "required": true },
            "timeOnScreenInSeconds": { "dataType": "double", "required": true },
            "openedWindowDuringGame": { "ref": "Boolean", "required": true },
        },
    },
    "PreSurveyResult": {
        "properties": {
            "questionId": { "dataType": "string", "required": true },
            "answerId": { "dataType": "string", "required": true },
            "timeOnScreenInSeconds": { "dataType": "double", "required": true },
            "openedWindowDuringGame": { "ref": "Boolean", "required": true },
        },
    },
    "PostSurveyResult": {
        "properties": {
            "questionId": { "dataType": "string", "required": true },
            "answerId": { "dataType": "string", "required": true },
            "timeOnScreenInSeconds": { "dataType": "double", "required": true },
            "openedWindowDuringGame": { "ref": "Boolean", "required": true },
        },
    },
    "Result": {
        "properties": {
            "playerUUID": { "dataType": "string", "required": true },
            "languageSelected": { "dataType": "string", "required": true },
            "scenarios": { "dataType": "array", "array": { "ref": "ScenarioResult" }, "required": true },
            "preSurvey": { "dataType": "array", "array": { "ref": "PreSurveyResult" }, "required": true },
            "postSurvey": { "dataType": "array", "array": { "ref": "PostSurveyResult" }, "required": true },
            "_id": { "dataType": "string" },
        },
    },
    "Answer": {
        "properties": {
            "text": { "dataType": "string" },
            "score": { "dataType": "double", "required": true },
            "isLastFixed": { "dataType": "boolean" },
        },
    },
    "Translation": {
        "properties": {
            "_id": { "dataType": "string" },
            "text": { "dataType": "string", "required": true },
            "language": { "dataType": "string", "required": true },
            "answers": { "dataType": "array", "array": { "ref": "Answer" } },
        },
    },
    "LearningComponent": {
        "properties": {
            "_id": { "dataType": "string" },
            "text": { "dataType": "string", "required": true },
            "title": { "dataType": "string", "required": true },
            "order": { "dataType": "double", "required": true },
            "translations": { "dataType": "array", "array": { "ref": "Translation" }, "required": true },
        },
    },
    "Scenario": {
        "properties": {
            "_id": { "dataType": "string" },
            "text": { "dataType": "string", "required": true },
            "title": { "dataType": "string", "required": true },
            "order": { "dataType": "double", "required": true },
            "translations": { "dataType": "array", "array": { "ref": "Translation" }, "required": true },
        },
    },
    "SubQuestion": {
        "properties": {
            "_id": { "dataType": "string" },
            "text": { "dataType": "string", "required": true },
            "answers": { "dataType": "array", "array": { "ref": "Answer" } },
            "translations": { "dataType": "array", "array": { "ref": "Translation" } },
        },
    },
    "Question": {
        "properties": {
            "_id": { "dataType": "string" },
            "text": { "dataType": "string", "required": true },
            "type": { "dataType": "string", "required": true },
            "source": { "dataType": "string", "required": true },
            "order": { "dataType": "double", "required": true },
            "category": { "dataType": "string", "required": true },
            "answers": { "dataType": "array", "array": { "ref": "Answer" } },
            "allowMultipleSelection": { "dataType": "boolean", "required": true },
            "randomise": { "dataType": "boolean", "required": true },
            "subQuestions": { "dataType": "array", "array": { "ref": "SubQuestion" } },
            "numberOfAnswers": { "dataType": "double" },
            "translations": { "dataType": "array", "array": { "ref": "Translation" }, "required": true },
        },
    },
    "Category": {
        "properties": {
            "text": { "dataType": "string", "required": true },
        },
    },
    "Scene": {
        "properties": {
            "_id": { "dataType": "string" },
            "title": { "dataType": "string", "required": true },
            "learningComponentId": { "dataType": "string", "required": true },
            "scenarioId": { "dataType": "string", "required": true },
            "nextScenarioIfYesId": { "dataType": "string", "required": true },
            "nextScenarioIfNoId": { "dataType": "string", "required": true },
            "order": { "dataType": "double", "required": true },
            "learningComponentText": { "dataType": "string" },
            "learningComponentTitle": { "dataType": "string" },
            "scenarioText": { "dataType": "string" },
            "scenarioTitle": { "dataType": "string" },
            "nextScenarioIfYesText": { "dataType": "string" },
            "nextScenarioIfNoText": { "dataType": "string" },
        },
    },
    "Term": {
        "properties": {
            "_id": { "dataType": "string" },
            "text": { "dataType": "string", "required": true },
            "title": { "dataType": "string", "required": true },
            "order": { "dataType": "double", "required": true },
            "translations": { "dataType": "array", "array": { "ref": "Translation" } },
        },
    },
};

export function RegisterRoutes(router: any) {
    router.get('/api/gamedata',
        async (context, next) => {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new GameDataController();

            const promise = controller.getGameData.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.post('/api/gamedata',
        async (context, next) => {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new GameDataController();

            const promise = controller.generateGameData.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.post('/api/result',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Result" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ResultsController();

            const promise = controller.saveResults.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/learningcomponent',
        async (context, next) => {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new LearningComponentController();

            const promise = controller.getAll.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/learningcomponent/:id',
        async (context, next) => {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new LearningComponentController();

            const promise = controller.getBy.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.post('/api/learningcomponent',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "LearningComponent" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new LearningComponentController();

            const promise = controller.create.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.put('/api/learningcomponent',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "LearningComponent" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new LearningComponentController();

            const promise = controller.updateItem.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/learningcomponent/:id',
        async (context, next) => {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new LearningComponentController();

            const promise = controller.DeleteItem.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/learningcomponent/:modelId/translation/:translationId',
        async (context, next) => {
            const args = {
                modelId: { "in": "path", "name": "modelId", "required": true, "dataType": "string" },
                translationId: { "in": "path", "name": "translationId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new LearningComponentController();

            const promise = controller.DeleteTranslation.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/scenario',
        async (context, next) => {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenariosController();

            const promise = controller.getAll.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/scenario/:id',
        async (context, next) => {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenariosController();

            const promise = controller.getBy.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.post('/api/scenario',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Scenario" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenariosController();

            const promise = controller.create.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.put('/api/scenario',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Scenario" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenariosController();

            const promise = controller.updateItem.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/scenario/:id',
        async (context, next) => {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenariosController();

            const promise = controller.DeleteItem.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/scenario/:modelId/translation/:translationId',
        async (context, next) => {
            const args = {
                modelId: { "in": "path", "name": "modelId", "required": true, "dataType": "string" },
                translationId: { "in": "path", "name": "translationId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenariosController();

            const promise = controller.DeleteTranslation.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/question',
        async (context, next) => {
            const args = {
                source: { "in": "query", "name": "source", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.getAllQuestions.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/question/:id',
        async (context, next) => {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.getQuestionBy.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.post('/api/question',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Question" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.createQuestion.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.put('/api/question',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Question" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.updateQuestion.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/question/:questionId',
        async (context, next) => {
            const args = {
                questionId: { "in": "path", "name": "questionId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.DeleteQuestion.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/question/:modelId/answer/:answerId',
        async (context, next) => {
            const args = {
                modelId: { "in": "path", "name": "modelId", "required": true, "dataType": "string" },
                answerId: { "in": "path", "name": "answerId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.DeleteAnswer.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/question/:modelId/translation/:translationId',
        async (context, next) => {
            const args = {
                modelId: { "in": "path", "name": "modelId", "required": true, "dataType": "string" },
                translationId: { "in": "path", "name": "translationId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.DeleteTranslation.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/question/:modelId/translation/:translationId/answer/:answerId',
        async (context, next) => {
            const args = {
                modelId: { "in": "path", "name": "modelId", "required": true, "dataType": "string" },
                translationId: { "in": "path", "name": "translationId", "required": true, "dataType": "string" },
                answerId: { "in": "path", "name": "answerId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.DeleteAnswerTranslation.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/question/:modelId/translation/:translationId/subquestion/:subQuestionId',
        async (context, next) => {
            const args = {
                modelId: { "in": "path", "name": "modelId", "required": true, "dataType": "string" },
                translationId: { "in": "path", "name": "translationId", "required": true, "dataType": "string" },
                subQuestionId: { "in": "path", "name": "subQuestionId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.DeleteSubQuestionTranslation.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/question/:modelId/subquestion/:subQuestionId/answer/:answerId',
        async (context, next) => {
            const args = {
                modelId: { "in": "path", "name": "modelId", "required": true, "dataType": "string" },
                subQuestionId: { "in": "path", "name": "subQuestionId", "required": true, "dataType": "string" },
                answerId: { "in": "path", "name": "answerId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.DeleteSubQuestionAmswer.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/question/:modelId/subquestion/:subQuestionId',
        async (context, next) => {
            const args = {
                modelId: { "in": "path", "name": "modelId", "required": true, "dataType": "string" },
                subQuestionId: { "in": "path", "name": "subQuestionId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new QuestionController();

            const promise = controller.DeleteSubQuestion.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/category',
        async (context, next) => {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new CategoryController();

            const promise = controller.getAllCategories.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.post('/api/category',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Category" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new CategoryController();

            const promise = controller.createCategory.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/category/:categoryId',
        async (context, next) => {
            const args = {
                categoryId: { "in": "path", "name": "categoryId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new CategoryController();

            const promise = controller.DeleteCategory.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/scene',
        async (context, next) => {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenesController();

            const promise = controller.getAll.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.post('/api/scene',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Scene" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenesController();

            const promise = controller.create.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.put('/api/scene',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Scene" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenesController();

            const promise = controller.updateItem.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/scene/:id',
        async (context, next) => {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new ScenesController();

            const promise = controller.DeleteItem.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/term',
        async (context, next) => {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new TermsController();

            const promise = controller.getAll.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.get('/api/term/:id',
        async (context, next) => {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new TermsController();

            const promise = controller.getBy.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.post('/api/term',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Term" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new TermsController();

            const promise = controller.create.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.put('/api/term',
        async (context, next) => {
            const args = {
                requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "Term" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new TermsController();

            const promise = controller.updateItem.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/term/:id',
        async (context, next) => {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new TermsController();

            const promise = controller.DeleteItem.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });
    router.delete('/api/term/:modelId/translation/:translationId',
        async (context, next) => {
            const args = {
                modelId: { "in": "path", "name": "modelId", "required": true, "dataType": "string" },
                translationId: { "in": "path", "name": "translationId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, context);
            } catch (error) {
                context.status = error.status || 500;
                context.body = error;
                return next();
            }

            const controller = new TermsController();

            const promise = controller.DeleteTranslation.apply(controller, validatedArgs);
            return promiseHandler(controller, promise, context, next);
        });


    function isController(object: any): object is Controller {
        return 'getHeaders' in object && 'getStatus' in object && 'setStatus' in object;
    }

    function promiseHandler(controllerObj: any, promise: Promise<any>, context: any, next: () => Promise<any>) {
        return Promise.resolve(promise)
            .then((data: any) => {
                if (data || data === false) {
                    context.body = data;
                    context.status = 200;
                } else {
                    context.status = 204;
                }

                if (isController(controllerObj)) {
                    const headers = controllerObj.getHeaders();
                    Object.keys(headers).forEach((name: string) => {
                        context.set(name, headers[name]);
                    });

                    const statusCode = controllerObj.getStatus();
                    if (statusCode) {
                        context.status = statusCode;
                    }
                }
                next();
            })
            .catch((error: any) => {
                context.status = error.status || 500;
                context.body = error;
                next();
            });
    }

    function getValidatedArgs(args: any, context: any): any[] {
        const errorFields: FieldErrors = {};
        const values = Object.keys(args).map(key => {
            const name = args[key].name;
            switch (args[key].in) {
                case 'request':
                    return context.request;
                case 'query':
                    return ValidateParam(args[key], context.request.query[name], models, name, errorFields)
                case 'path':
                    return ValidateParam(args[key], context.params[name], models, name, errorFields)
                case 'header':
                    return ValidateParam(args[key], context.request.headers[name], models, name, errorFields);
                case 'body':
                    return ValidateParam(args[key], context.request.body, models, name, errorFields, name + '.');
                case 'body-prop':
                    return ValidateParam(args[key], context.request.body[name], models, name, errorFields, 'body.');
            }
        });
        if (Object.keys(errorFields).length > 0) {
            throw new ValidateError(errorFields, '');
        }
        return values;
    }
}
