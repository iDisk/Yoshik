import {
  Get,
  Route,
  Controller,
  SuccessResponse,
  Body,
  Post,
  Delete,
  Put,
  Query
} from "tsoa";

import { Question } from "../data-services/question/Question";
import QuestionRepository from "../data-services/question/QuestionRepository";
import { QuestionModel } from "../data-services/question/QuestionModel";

@Route("question")
export class QuestionController extends Controller {
  private _repository: QuestionRepository;

  constructor() {
    super();
    this._repository = new QuestionRepository();
  }

  @Get()
  public async getAllQuestions(@Query() source: string): Promise<Question[]> {
    const result = await this._repository.retrieve();
    return result;
  }

  @Get("{id}")
  public async getQuestionBy(id: string): Promise<Question | undefined> {
    const result = await this._repository.findById(id);
    if (result) {
      const question: Question = {
        text: result.text,
        type: result.type,
        category: result.category,
        source: result.source,
        order: result.order,
        allowMultipleSelection: result.allowMultipleSelection,
        randomise: result.randomise,
        answers: result.answers,
        translations: result.translations
      };
      return question;
    }
  }

  @SuccessResponse("201", "Created")
  @Post()
  public async createQuestion(@Body() requestBody: Question): Promise<void> {
    try {
      const nextOrderValue = await QuestionModel.count({ source: requestBody.source }).exec();
      requestBody.order = nextOrderValue + 1;
      const newQuestionModel = new QuestionModel(requestBody);
      await this._repository.create(newQuestionModel);
    } catch (error) {
      console.log("ERROR", error);
    }

  }

  @Put()
  public async updateQuestion(@Body() requestBody: Question): Promise<void> {
    try {
      console.log("Source", requestBody.source)
      console.log("Source body", requestBody)
      const newQuestionModel = new QuestionModel(requestBody);
      if (requestBody._id) {
        const existingQuestion = await this._repository.findById(requestBody._id);
        if (existingQuestion) {
          const newOrderValue = requestBody.order;
          const currentOrderValue = existingQuestion.order;
          if (currentOrderValue !== newOrderValue) {
            console.log("Order has changed", currentOrderValue, newOrderValue)
            if (newOrderValue > currentOrderValue) {  // if I moved down
              console.log(`Source: ${requestBody.source} ID: ${requestBody._id}`)
              await QuestionModel.updateMany({ source: requestBody.source, _id: { $ne: requestBody._id }, order: { $gt: currentOrderValue, $lte: newOrderValue } }, { $inc: { order: -1 } }).exec();
            } else {
              console.log(`Source: ${requestBody.source} ID: ${requestBody._id}`)
              await QuestionModel.updateMany({ source: requestBody.source, _id: { $ne: requestBody._id }, order: { $lt: currentOrderValue, $gte: newOrderValue } }, { $inc: { order: 1 } }).exec();
            }
          }
        }
        await this._repository.update(requestBody._id, newQuestionModel);
      }
    } catch (error) {
      console.log("ERROR", error);
    }

  }

  @Delete('{questionId}')
  public async DeleteQuestion(questionId: string): Promise<void> {
    const existingQuestion = await this._repository.findById(questionId);
    if (existingQuestion) {
      await QuestionModel.updateMany({ source: existingQuestion.source, _id: { $ne: existingQuestion._id }, order: { $gt: existingQuestion.order } }, { $inc: { order: -1 } }).exec();
    }
    await this._repository.delete(questionId)
  }

  @Delete('{modelId}/answer/{answerId}')
  public async DeleteAnswer(modelId: string, answerId: string): Promise<void> {
    return this._repository.deleteAnswer(modelId, answerId)
  }

  @Delete('{modelId}/translation/{translationId}')
  public async DeleteTranslation(modelId: string, translationId: string): Promise<void> {
    return this._repository.deleteTranslation(modelId, translationId)
  }

  @Delete('{modelId}/translation/{translationId}/answer/{answerId}')
  public async DeleteAnswerTranslation(modelId: string, translationId: string, answerId: string): Promise<void> {
    return this._repository.deleteAnswerTranslation(modelId, translationId, answerId)
  }

  @Delete('{modelId}/translation/{translationId}/subquestion/{subQuestionId}')
  public async DeleteSubQuestionTranslation(modelId: string, translationId: string, subQuestionId: string): Promise<void> {
    return this._repository.deleteSubQuestionTranslation(modelId, translationId, subQuestionId)
  }

  @Delete('{modelId}/subquestion/{subQuestionId}/answer/{answerId}')
  public async DeleteSubQuestionAmswer(modelId: string, subQuestionId: string, answerId: string): Promise<void> {
    return this._repository.deleteSubQuestionAnswer(modelId, subQuestionId, answerId)
  }
  @Delete('{modelId}/subquestion/{subQuestionId}')
  public async DeleteSubQuestion(modelId: string, subQuestionId: string): Promise<void> {
    return this._repository.deleteSubQuestion(modelId, subQuestionId)
  }
}
