import { Get, Route, Controller, Post, SuccessResponse } from "tsoa";
import { GameData, SurveyData, AnswerData, SceneData } from "../data-services/game-data/GameData";
import GameDataRepository from "../data-services/game-data/GameDataRepository";
import QuestionRepository from "../data-services/question/QuestionRepository";
import { GameDataModel } from "../data-services/game-data/GameDataModel";
import LearningComponentRepository from "../data-services/learning-component/LearningComponentRepository";
import ScenarioRepository from "../data-services/scenario/ScenarioRepository";
import SceneRepository from "../data-services/scene/SceneRepository";
import { IQuestionDocument } from "../data-services/question/IQuestionDocument";

@Route("gamedata")
export class GameDataController extends Controller {
  private _repository: GameDataRepository;
  private _QuestionRepository: QuestionRepository;
  private _learningRepository: LearningComponentRepository;
  private _scenariosRepository: ScenarioRepository;
  private _scenesRepository: SceneRepository;

  constructor() {
    super();
    this._repository = new GameDataRepository();
    this._QuestionRepository = new QuestionRepository();
    this._scenariosRepository = new ScenarioRepository();
    this._learningRepository = new LearningComponentRepository();
    this._scenesRepository = new SceneRepository();
  }

  @Get()
  public async getGameData(): Promise<GameData[]> {
    // console.log("received");
    const result = await this._repository.retrieve({});
    return result;
  }

  @SuccessResponse("201", "Created")
  @Post()
  public async generateGameData(): Promise<void> {
    try {
      // if data in database is valid
      // if all items have 2 translations,
      // one with es and one with mx
      const gameDataInEnglish: GameData = {
        language: "en",
        preSurvey: await this.getSurveyDataInEnglish("Presurvey"),
        postSurvey: await this.getSurveyDataInEnglish("Postsurvey"),
        scenes: await this.getScenariosDataInEnglish()
      }
      const dataInSpanish: GameData = {
        language: "es",
        preSurvey: await this.getSurveyDataSpanish("Presurvey", "es") as any,
        postSurvey: await this.getSurveyDataSpanish("Postsurvey", "es") as any,
        scenes: await this.getScenariosDataInSpanish("es")
      }
      const dataInSpanishMx: GameData = {
        language: "mx",
        preSurvey: await this.getSurveyDataSpanish("Presurvey", "mx") as any,
        postSurvey: await this.getSurveyDataSpanish("Postsurvey", "mx") as any,
        scenes: await this.getScenariosDataInSpanish("mx")
      }
      const model = new GameDataModel(gameDataInEnglish);
      await this._repository.create(model);
      const model2 = new GameDataModel(dataInSpanish);
      await this._repository.create(model2);
      const model3 = new GameDataModel(dataInSpanishMx);
      await this._repository.create(model3);
    } catch (error) {
      console.log("ERROR");
    }
  }

  public async getSurveyDataInEnglish(source) {
    const questions = await this._QuestionRepository.retrieve({
      source: source
    });
    let result: SurveyData[] = [];
    result = this.getResultValuesFromQuestions(questions);
    return result;
  }

  private async getScenariosDataInSpanish(language: string) {
    const scenes = await this._scenesRepository.retrieve({});
    const scenesResult = scenes.map(async (item) => {
      const scenario = await this._scenariosRepository.findById(item.scenarioId);
      const learningComponent = await this._learningRepository.findById(item.learningComponentId);
      if (scenario && learningComponent) {
        const scenarioTranslation = scenario.translations.filter(s => s.language == language);
        const learningTranslation = learningComponent.translations.filter(s => s.language == language);
        if (scenarioTranslation[0] && learningTranslation[0]) {
          return {
            title: item.title || "",
            scenarioId: item.scenarioId,
            order: item.order,
            learningComponentId: item.learningComponentId,
            scenarioTitle: item.scenarioTitle || "",
            scenarioText: scenarioTranslation[0].text,
            learningComponentTitle: item.learningComponentTitle || "",
            learningComponentText: learningTranslation[0].text,
            nextScenarioIfYesId: item.nextScenarioIfYesId,
            nextScenarioIfNoId: item.nextScenarioIfNoId
          }
        }
      }
    })
    const results: SceneData[] = await Promise.all(scenesResult) as any;
    return results;

  }

  // "learningComponentText" : "If it is not stipulated that this not have a marketing objective it is subject to data protection in the case of loss or misuse your employee would be liable for it, you can formally complain. ",
  //   "learningComponentTitle" : "DISCOUNT CARD",
  //   "scenarioText" : "Your employer in a large company offers you a discount card for online purchases that you buy. If you accept the card your employer would have access to your pseudoanomized purchase history. This information would be stored in order to determine future discount programs. Would you accept this card, yes or no?",
  //   "scenarioTitle" : "DISCOUNT CARD",

  private async getScenariosDataInEnglish() {
    const scenes = await this._scenesRepository.retrieve({});
    const scenesResult = scenes.map(async (item) => {
      const scenario = await this._scenariosRepository.findById(item.scenarioId);
      const learningComponent = await this._learningRepository.findById(item.learningComponentId);
      if (scenario && learningComponent) {
        return {
          title: item.title,
          scenarioId: item.scenarioId,
          scenarioTitle: item.scenarioTitle || "",
          // scenarioText: item.scenarioText,
          order: item.order,
          learningComponentId: item.learningComponentId,
          learningComponentTitle: item.learningComponentTitle || "",
          // learningComponentText: item.learningComponentText,
          nextScenarioIfYesId: item.nextScenarioIfYesId,
          nextScenarioIfNoId: item.nextScenarioIfNoId,
          scenarioText: scenario.text,
          learningComponentText: learningComponent.text
        }
      }
    })
    const results: SceneData[] = await Promise.all(scenesResult) as any;
    return results;
  }

  private getResultValuesFromQuestions(questions: IQuestionDocument[]) {
    let result: SurveyData[] = [];
    let currentOrderValue = 1;
    questions.forEach((item) => {
      if (item.subQuestions && item.subQuestions.length > 0) {
        item.subQuestions.forEach((subQuestion, index) => {
          if (subQuestion.answers) {
            const newAnswers: AnswerData[] = subQuestion.answers.map((element, index) => {
              return {
                answerId: element._id,
                answerText: (element.text !== '' && element.text !== undefined) ? element.text : "",
                score: element.score,
                isLastFixed: element.isLastFixed !== undefined ? element.isLastFixed : false
              }
            });

            const newQuestionItem = {
              questionOrder: currentOrderValue,
              questionId: item._id,
              questionType: item.type,
              questionText: item.text,
              allowMultipleSelection: item.allowMultipleSelection !== undefined ? item.allowMultipleSelection : false,
              randomiseAnswers: item.randomise !== undefined ? item.randomise : false,
              answers: newAnswers,
              subQuestionText: subQuestion.text
            }
            currentOrderValue++;
            result.push(newQuestionItem);
          }
        })
      } else if (item.answers) {
        const newAnswers: AnswerData[] = item.answers.map((element, index) => {
          return {
            answerId: element._id,
            answerText: (element.text !== '' && element.text !== undefined) ? element.text : "",
            score: element.score,
            isLastFixed: element.isLastFixed !== undefined ? element.isLastFixed : false
          }
        });

        const newQuestionItem = {
          questionOrder: currentOrderValue,
          questionId: item._id,
          questionType: item.type,
          questionText: item.text,
          allowMultipleSelection: item.allowMultipleSelection !== undefined ? item.allowMultipleSelection : false,
          randomiseAnswers: item.randomise !== undefined ? item.randomise : false,
          answers: newAnswers,
          subQuestionText: ""
        };
        currentOrderValue++;
        result.push(newQuestionItem);
      }
    })
    return result;
  }

  private async getSurveyDataSpanish(source, language) {
    const questions = await this._QuestionRepository.retrieve({
      source: source
    });
    let result: SurveyData[] = [];
    let currentOrderValue = 1;
    questions.forEach((item) => {
      const translationItems = item.translations.filter(s => s.language == language);
      const itemsToFind = translationItems.length > 0 ? translationItems[0] : undefined;

      if (itemsToFind && item.subQuestions && item.subQuestions.length > 0) {
        item.subQuestions.forEach((subQuestion, index) => {
          if (subQuestion.translations) {
            const subQuestionTranslations = subQuestion.translations.filter(s => s.language == language);
            const subQuestionItemsToFind = subQuestionTranslations.length > 0 ? subQuestionTranslations[0] : undefined;

            if (subQuestionItemsToFind && subQuestionItemsToFind.answers) {
              const newAnswers: AnswerData[] = subQuestionItemsToFind.answers.map((element, index) => {
                return {
                  answerId: element._id,
                  answerText: (element.text !== '' && element.text !== undefined) ? element.text : "",
                  score: element.score,
                  isLastFixed: element.isLastFixed !== undefined ? element.isLastFixed : false
                }
              });
              const newQuestionItem = {
                questionOrder: currentOrderValue,
                questionId: item._id,
                questionType: item.type,
                questionText: itemsToFind.text,
                allowMultipleSelection: item.allowMultipleSelection !== undefined ? item.allowMultipleSelection : false,
                randomiseAnswers: item.randomise !== undefined ? item.randomise : false,
                answers: newAnswers,
                subQuestionText: subQuestionItemsToFind.text
              }
              currentOrderValue++;
              result.push(newQuestionItem);
            }
          }
        })
      } else if (itemsToFind && itemsToFind.answers) {

        const newAnswers: AnswerData[] = itemsToFind.answers.map((element) => {
          return {
            answerId: element._id,
            answerText: element.text || "",
            score: element.score,
            isLastFixed: element.isLastFixed !== undefined ? element.isLastFixed : false
          }
        });

        const newQuestion = {
          questionOrder: currentOrderValue,
          questionId: item._id,
          questionType: item.type,
          questionText: itemsToFind.text,
          allowMultipleSelection: item.allowMultipleSelection !== undefined ? item.allowMultipleSelection : false,
          randomiseAnswers: item.randomise !== undefined ? item.randomise : false,
          answers: newAnswers,
          subQuestionText: ""
        }
        currentOrderValue++;
        result.push(newQuestion);
      }

    })
    return result;
  }
}
