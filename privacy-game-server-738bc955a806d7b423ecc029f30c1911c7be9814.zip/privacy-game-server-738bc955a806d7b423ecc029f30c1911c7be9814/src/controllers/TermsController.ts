import {
    Get,
    Route,
    Controller,
    SuccessResponse,
    Body,
    Post,
    Delete,
    Put
} from "tsoa";

import TermRepository from "../data-services/term/TermsRepository";
import { TermModel } from "../data-services/term/TermModel";
import { Term } from "../data-services/term/Term";

@Route("term")
export class TermsController extends Controller {
    private _repository: TermRepository;

    constructor() {
        super();
        this._repository = new TermRepository();
    }

    @Get()
    public async getAll(): Promise<Term[]> {
        return await this._repository.retrieve();
    }

    @Get("{id}")
    public async getBy(id: string): Promise<Term | null> {
        return await this._repository.findById(id);
    }


    @SuccessResponse("201", "Created")
    @Post()
    public async create(@Body() requestBody: Term): Promise<void> {
        try {
            console.log("Request received");
            const nextOrderValue = await TermModel.count({}).exec();
            requestBody.order = nextOrderValue + 1;
            const newItem = new TermModel(requestBody);
            await this._repository.create(newItem);
        } catch (error) {
            console.log("ERROR", error);
        }
    }

    @Put()
    public async updateItem(@Body() requestBody: Term): Promise<void> {
        try {
            const newItem = new TermModel(requestBody);
            if (requestBody._id) {
                const existingItem = await this._repository.findById(requestBody._id);
                if (existingItem) {
                    const newOrderValue = requestBody.order;
                    const currentOrderValue = existingItem.order;
                    if (currentOrderValue !== newOrderValue) {
                        console.log("Order has changed", currentOrderValue, newOrderValue)
                        if (newOrderValue > currentOrderValue) {  // if I moved down
                            await TermModel.updateMany({ _id: { $ne: requestBody._id }, order: { $gt: currentOrderValue, $lte: newOrderValue } }, { $inc: { order: -1 } }).exec();
                        } else {
                            await TermModel.updateMany({ _id: { $ne: requestBody._id }, order: { $lt: currentOrderValue, $gte: newOrderValue } }, { $inc: { order: 1 } }).exec();
                        }
                    }
                }
                await this._repository.update(requestBody._id, newItem);
            }
        }
        catch (error) {
            console.log("ERROR", error);
        }
    }

    @Delete('{id}')
    public async DeleteItem(id: string): Promise<void> {
        const existingItem = await this._repository.findById(id);
        if (existingItem) {
            await TermModel.updateMany({ _id: { $ne: existingItem._id }, order: { $gt: existingItem.order } }, { $inc: { order: -1 } }).exec();
        }
        await this._repository.delete(id)
    }

    @Delete('{modelId}/translation/{translationId}')
    public async DeleteTranslation(modelId: string, translationId: string): Promise<void> {
        return this._repository.deleteTranslation(modelId, translationId)
    }
}
