import { Get, Route, Controller, SuccessResponse, Post, Body } from "tsoa";
import { Result } from "../data-services/result/Result";
import ResultRepository from "../data-services/result/ResultRepository";
import { ResultModel } from "../data-services/result/ResultModel";

@Route("result")
export class ResultsController extends Controller {
    private _repository: ResultRepository;

    constructor() {
        super();
        this._repository = new ResultRepository();
    }


    @SuccessResponse("201", "Created")
    @Post()
    public async saveResults(@Body() requestBody: Result): Promise<void> {
        try {
            const model = new ResultModel(requestBody);
            await this._repository.create(model);
            this.setStatus(201);
            return Promise.resolve();
        } catch (error) {
            console.log("ERROR", error);
        }

    }
}
