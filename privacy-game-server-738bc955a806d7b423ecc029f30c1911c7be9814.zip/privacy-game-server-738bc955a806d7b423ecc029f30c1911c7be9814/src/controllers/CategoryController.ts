import { Get, Route, Controller, SuccessResponse, Post, Body, Delete } from "tsoa";
import { Category } from "../data-services/category/Category";
import CategoryRepository from "../data-services/category/CategoryRepository";
import { CategoryModel } from "../data-services/category/CategoryModel";

@Route("category")
export class CategoryController extends Controller {
  private _repository: CategoryRepository;

  constructor() {
    super();
    this._repository = new CategoryRepository();
  }

  @Get()
  public async getAllCategories(): Promise<Category[]> {
    const result = await this._repository.retrieve();
    return result;
  }

  @SuccessResponse("201", "Created")
  @Post()
  public async createCategory(@Body() requestBody: Category): Promise<void> {
    try {
      const categoryModel = new CategoryModel(requestBody);
      await this._repository.create(categoryModel);
      this.setStatus(201);
      return Promise.resolve();
    } catch (error) {
      console.log("ERROR", error);
    }

  }

  @Delete('{categoryId}')
  public async DeleteCategory(categoryId: string): Promise<void> {
    return this._repository.delete(categoryId)
  }
}
