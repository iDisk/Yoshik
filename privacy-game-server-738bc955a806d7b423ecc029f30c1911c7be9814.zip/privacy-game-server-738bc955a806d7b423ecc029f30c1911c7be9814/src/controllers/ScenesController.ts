import {
  Get,
  Route,
  Controller,
  SuccessResponse,
  Body,
  Post,
  Delete,
  Put
} from "tsoa";

import { SceneModel } from "../data-services/scene/SceneModel";
import { Scene } from "../data-services/scene/Scene";
import SceneRepository from "../data-services/scene/SceneRepository";
// import LearningComponentRepository from "../data-services/learning-component/LearningComponentRepository";
// import ScenarioRepository from "../data-services/scenario/ScenarioRepository";
import { ScenarioModel } from "../data-services/scenario/ScenarioModel";
import { LearningComponentModel } from "../data-services/learning-component/LearningComponentModel";

@Route("scene")
export class ScenesController extends Controller {
  private _repository: SceneRepository;
  private _learningModel: any;
  private _scenarioModel: any;

  constructor() {
    super();
    this._repository = new SceneRepository();
    this._learningModel = LearningComponentModel;
    this._scenarioModel = ScenarioModel;
  }

  @Get()
  public async getAll(): Promise<Scene[]> {
    return await this._repository.retrieve();
  }

  @SuccessResponse("201", "Created")
  @Post()
  public async create(@Body() requestBody: Scene): Promise<void> {
    try {
      console.log("Request received");
      const nextOrderValue = await SceneModel.count({}).exec();
      requestBody.order = nextOrderValue + 1;
      const scenario = await this._scenarioModel.findById(requestBody.scenarioId);
      const learningComponent = await this._learningModel.findById(requestBody.learningComponentId);
      requestBody.learningComponentText = learningComponent.text;
      requestBody.learningComponentTitle = learningComponent.title;
      requestBody.scenarioText = scenario.text;
      requestBody.scenarioTitle = scenario.title;
      requestBody.nextScenarioIfNoText = (await this._scenarioModel.findById(requestBody.nextScenarioIfNoId)).title;
      requestBody.nextScenarioIfYesText = (await this._scenarioModel.findById(requestBody.nextScenarioIfYesId)).title;
      const newItem = new SceneModel(requestBody);
      await this._repository.create(newItem);
    } catch (error) {
      console.log("ERROR", error);
    }
  }

  @Put()
  public async updateItem(@Body() requestBody: Scene): Promise<void> {
    try {
      const newItem = new SceneModel(requestBody);
      if (requestBody._id) {
        const existingItem = await this._repository.findById(requestBody._id);
        if (existingItem) {
          const newOrderValue = requestBody.order;
          const currentOrderValue = existingItem.order;
          if (currentOrderValue !== newOrderValue) {
            console.log("Order has changed", currentOrderValue, newOrderValue)
            if (newOrderValue > currentOrderValue) {  // if I moved down
              await SceneModel.updateMany({ _id: { $ne: requestBody._id }, order: { $gt: currentOrderValue, $lte: newOrderValue } }, { $inc: { order: -1 } }).exec();
            } else {
              await SceneModel.updateMany({ _id: { $ne: requestBody._id }, order: { $lt: currentOrderValue, $gte: newOrderValue } }, { $inc: { order: 1 } }).exec();
            }
          }
        }
        await this._repository.update(requestBody._id, newItem);
      }
    }
    catch (error) {
      console.log("ERROR", error);
    }
  }

  @Delete('{id}')
  public async DeleteItem(id: string): Promise<void> {
    const existingItem = await this._repository.findById(id);
    if (existingItem) {
      await SceneModel.updateMany({ _id: { $ne: existingItem._id }, order: { $gt: existingItem.order } }, { $inc: { order: -1 } }).exec();
    }
    await this._repository.delete(id)
  }
}
