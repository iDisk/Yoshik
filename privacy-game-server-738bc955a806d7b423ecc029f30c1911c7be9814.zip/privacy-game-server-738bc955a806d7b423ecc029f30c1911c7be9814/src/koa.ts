import Koa from "koa";
import bodyParser from "koa-bodyparser";
import koaRouter from "koa-router";
import cors from "@koa/cors";

import { RegisterRoutes } from "./routes";

// controllers
import "./controllers/GameDataController";
import "./controllers/ScenesController";
import "./controllers/ResultsController";
import "./controllers/LearningComponentController";
import "./controllers/ScenariosController";
import "./controllers/QuestionController";
import "./controllers/CategoryController";
import "./controllers/TermsController";

import ResultRepository from "./data-services/result/ResultRepository";

const app = new Koa();
const router = new koaRouter();
router.get("/", async (ctx) => {
  ctx.body = "hello world";
})

router.get("/download", async (ctx, next) => {
  const repository = new ResultRepository();
  const result = await repository.retrieve();
  const data = JSON.stringify(result);
  console.log("DATA", data)
  ctx.res.setHeader('Content-disposition', 'attachment; filename= myFile.json');
  ctx.res.setHeader('Content-type', 'application/json');
  ctx.body = result;
})
app.use(bodyParser());
app.use(router.routes());
app.use(cors());

RegisterRoutes(router);

app.on("error", err => {
  console.error("Server error", err);
});

export default app;
