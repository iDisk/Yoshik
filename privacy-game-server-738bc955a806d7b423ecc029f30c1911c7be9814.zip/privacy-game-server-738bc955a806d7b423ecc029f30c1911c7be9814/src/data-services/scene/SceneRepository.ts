import { SceneModel } from "./SceneModel";
import { ISceneDocument } from './ISceneDocument';
import RepositoryBase from "../BaseRepository";

class SceneRepository extends RepositoryBase<ISceneDocument> {
  constructor() {
    super(SceneModel);
  }
}

Object.seal(SceneRepository);

export default SceneRepository;
