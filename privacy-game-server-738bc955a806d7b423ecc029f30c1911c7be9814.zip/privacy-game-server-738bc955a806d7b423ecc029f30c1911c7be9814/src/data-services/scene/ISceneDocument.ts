import { Document } from "mongoose";

export interface ISceneDocument extends Document {
    title: string;
    learningComponentId: string;
    scenarioId: string;
    nextScenarioIfYesId: string;
    nextScenarioIfNoId: string;
    order: number;
    learningComponentText: string;
    scenarioText: string;
    nextScenarioIfYesText: string;
    nextScenarioIfNoText: string;
    scenarioTitle?: string;
    learningComponentTitle?: string
}
