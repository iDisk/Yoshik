export interface Scene {
  _id?: string;
  title: string;
  learningComponentId: string;
  scenarioId: string;
  nextScenarioIfYesId: string;
  nextScenarioIfNoId: string;
  order: number;
  learningComponentText?: string;
  learningComponentTitle?: string;
  scenarioText?: string;
  scenarioTitle?: string;
  nextScenarioIfYesText?: string;
  nextScenarioIfNoText?: string;
}