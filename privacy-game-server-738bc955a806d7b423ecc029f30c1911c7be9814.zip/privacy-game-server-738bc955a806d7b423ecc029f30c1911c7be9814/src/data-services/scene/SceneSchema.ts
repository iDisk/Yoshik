import { Schema } from "mongoose";

export const SceneSchema: Schema = new Schema({
  title: {
    type: String,
    required: true
  },
  learningComponentId: {
    type: String,
    required: true
  },
  scenarioId: {
    type: String,
    required: true
  },
  nextScenarioIfYesId: {
    type: String,
    required: true
  },
  nextScenarioIfNoId: {
    type: String,
    required: true
  },
  order: {
    type: Number,
    required: true
  },
  learningComponentText: {
    type: String,
    required: true
  },
  learningComponentTitle: {
    type: String,
    required: true
  },
  scenarioText: {
    type: String,
    required: true
  },
  scenarioTitle: {
    type: String,
    required: true
  },
  nextScenarioIfYesText: {
    type: String,
    required: true
  },
  nextScenarioIfNoText: {
    type: String,
    required: true
  }
});

export default SceneSchema;



