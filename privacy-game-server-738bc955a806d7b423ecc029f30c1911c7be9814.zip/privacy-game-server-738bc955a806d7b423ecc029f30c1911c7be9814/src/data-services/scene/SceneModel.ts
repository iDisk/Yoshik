import { Model } from "mongoose";
import { ISceneDocument } from "./ISceneDocument";
import { SceneSchema } from "./SceneSchema";

import Database from "../Connection";

export type SceneSchemaModelType = Model<ISceneDocument>;

export const SceneModel: SceneSchemaModelType = Database.mongooseConnection.model<ISceneDocument>("scene", SceneSchema);
