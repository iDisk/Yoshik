import { Model, Document } from "mongoose";
import { ILearningComponentDocument } from "./ILearningComponentDocument";
import { LearningComponentSchema } from "./LearningComponentSchema";

import Database from "../Connection";

export type LearningComponentModelType = Model<ILearningComponentDocument>;

export const LearningComponentModel: LearningComponentModelType = Database.mongooseConnection.model<ILearningComponentDocument & Document>("learningcomponent", LearningComponentSchema);
