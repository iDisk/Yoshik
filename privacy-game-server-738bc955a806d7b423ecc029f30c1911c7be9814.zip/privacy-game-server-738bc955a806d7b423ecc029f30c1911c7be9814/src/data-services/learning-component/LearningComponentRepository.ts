import { LearningComponentModel } from "./LearningComponentModel";
import { ILearningComponentDocument } from './ILearningComponentDocument';
import RepositoryBase from "../BaseRepository";

class LearningComponentRepository extends RepositoryBase<ILearningComponentDocument> {
  private model: any;
  constructor() {
    super(LearningComponentModel);
    this.model = LearningComponentModel;
  }

  async deleteTranslation(modelId: string, translationId: string) {
    try {
      const model = await this.model.findById(modelId);
      await model.translations.id(translationId).remove();
      await model.save();
    } catch (error) {
      console.log("Error", error)
    }
  }
}

Object.seal(LearningComponentRepository);

export default LearningComponentRepository;
