import { Document } from "mongoose";
import { ITranslationDocument } from "../translation/ITranslationDocument";

export interface ILearningComponentDocument extends Document {
    text: string;
    title: string;
    order: number;
    translations: ITranslationDocument[]
}
