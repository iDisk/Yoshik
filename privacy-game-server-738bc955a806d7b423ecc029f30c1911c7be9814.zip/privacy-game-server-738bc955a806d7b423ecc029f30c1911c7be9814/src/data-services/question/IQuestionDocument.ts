import { Document } from "mongoose";
import { IAnswerDocument } from "../answer/IAnswerDocument";
import { ITranslationDocument } from "../translation/ITranslationDocument";
import { ISubQuestionDocument } from "../subquestion/ISubQuestionDocument";

export interface IQuestionDocument extends Document {
  text: string;
  type: string;
  source: string; // i.e. pre-survey, post-survey
  order: number;
  category: string;
  answers?: IAnswerDocument[];
  allowMultipleSelection: boolean;
  randomise: boolean;
  subQuestions?: ISubQuestionDocument[]
  // startLabel?: string;
  // endLabel?: string;
  // minValue?: number;
  numberOfAnswers?: number;
  translations: ITranslationDocument[];
}
