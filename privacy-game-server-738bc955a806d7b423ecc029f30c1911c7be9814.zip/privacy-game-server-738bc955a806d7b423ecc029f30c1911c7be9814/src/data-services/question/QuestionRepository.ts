import { IQuestionDocument } from "./IQuestionDocument";
import { QuestionModel } from "./QuestionModel";
import RepositoryBase from "../BaseRepository";
import { Types } from "mongoose";

class QuestionRepository extends RepositoryBase<IQuestionDocument> {
  private questionModel: any;

  constructor() {
    super(QuestionModel);
    this.questionModel = QuestionModel;
  }

  async deleteAnswer(modelId: string, answerId: string) {
    try {
      const model = await this.questionModel.findById(modelId);
      await model.answers.id(answerId).remove();
      await model.save();
    } catch (error) {
      console.log("Error", error)
    }
  }

  async deleteTranslation(modelId: string, translationId: string) {
    try {
      const model = await this.questionModel.findById(modelId);
      await model.translations.id(translationId).remove();
      await model.save();
    } catch (error) {
      console.log("Error", error)
    }
  }

  async deleteAnswerTranslation(modelId: string, translationId: string, answerId: string) {
    try {
      const model = await this.questionModel.findById(modelId);
      const translation = model.translations.id(translationId);
      translation.answers.id(answerId).remove();
      await model.save();
    } catch (error) {
      console.log("Error", error)
    }
  }

  async deleteSubQuestion(modelId: string, subQuestionId: string) {
    try {
      const model = await this.questionModel.findById(modelId);
      await model.subQuestions.id(subQuestionId).remove();
      await model.save();
    } catch (error) {
      console.log("Error", error)
    }
  }

  async deleteSubQuestionTranslation(modelId: string, translationId: string, subQuestionId: string) {
    try {
      const model = await this.questionModel.findById(modelId);
      const subQuestions = model.subQuestions.id(subQuestionId);
      subQuestions.translations.id(translationId).remove();
      await model.save();
    } catch (error) {
      console.log("Error", error)
    }
  }

  async deleteSubQuestionAnswer(modelId: string, subQuestionId: string, answerId: string) {
    try {
      const model = await this.questionModel.findById(modelId);
      model.numberOfAnswers = model.numberOfAnswers - 1;
      const subQuestions = model.subQuestions.id(subQuestionId);
      subQuestions.answers.id(answerId).remove();
      await model.save();
    } catch (error) {
      console.log("Error", error)
    }
  }
}

Object.seal(QuestionRepository);

export default QuestionRepository;
