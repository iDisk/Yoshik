import { Answer } from "../answer/Answer";
import { SubQuestion } from "../subquestion/SubQuestion";
import { Translation } from "../translation/Translation";

export interface Question {
  _id?: string;
  text: string;
  type: string;
  source: string; // i.e. pre-survey, post-survey
  order: number;
  category: string;
  answers?: Answer[];
  allowMultipleSelection: boolean;
  randomise: boolean;
  subQuestions?: SubQuestion[]
  // startLabel?: string;
  // endLabel?: string;
  numberOfAnswers?: number;
  // maxValue?: number;
  translations: Translation[];
}
