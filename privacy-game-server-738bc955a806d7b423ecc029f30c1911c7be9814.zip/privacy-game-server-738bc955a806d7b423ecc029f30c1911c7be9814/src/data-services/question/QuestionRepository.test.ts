import QuestionRepository from "./QuestionRepository";
import { QuestionModel } from "./QuestionModel";
import { IQuestionDocument } from "./IQuestionDocument";

describe("QuestionRepository", () => {

  const sampleQuestipn: IQuestionDocument = new QuestionModel({
    text: "Hello",
    asd: 123,
    affectedLearningComponent: "1",
    affectedScenario: "2",
    type: "123"
  });

  let questionRepository: QuestionRepository;

  beforeAll(() => {
    questionRepository = new QuestionRepository();
  })

  test("should create a new question document", async () => {
    const result = questionRepository.create(sampleQuestipn);

    await expect(result).resolves.toBeDefined();
  });

  it("should remove a question document", async () => {
    const newQuestion = await questionRepository.create(sampleQuestipn);
    console.log("New question", newQuestion)

    const previousResul = await questionRepository.findById(newQuestion._id);
    console.log("Previous result", previousResul)

    await questionRepository.delete(`${newQuestion._id}`);

    expect(newQuestion._id).toBeDefined();
  });
});
