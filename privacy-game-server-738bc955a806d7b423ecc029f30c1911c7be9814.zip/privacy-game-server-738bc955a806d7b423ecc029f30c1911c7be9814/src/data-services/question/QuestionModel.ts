import * as mongoose from "mongoose";
import { IQuestionDocument } from "./IQuestionDocument";
import { QuestionSchema } from "./QuestionSchema";
import Database from "../Connection";

export type QuestionModelType = mongoose.Model<IQuestionDocument>;

export const QuestionModel: QuestionModelType = Database.mongooseConnection.model<
  IQuestionDocument
  >("question", QuestionSchema);

