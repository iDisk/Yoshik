import { Schema } from "mongoose";
import { AnswerSchema } from "../answer/AnswerSchema";
import { TranslationSchema } from "../translation/TranslationSchema";
import { SubQuestionSchema } from "../subquestion/SubQuestionSchema";

export const QuestionSchema: Schema = new Schema({
  text: {
    type: String,
    required: true
  },
  type: {
    type: String,
    required: true
  },
  order: {
    type: Number,
    required: true
  },
  source: {
    type: String,
    required: true
  },
  category: {
    type: String,
    required: true
  },
  answers: [AnswerSchema],
  randomise: {
    type: Boolean,
    required: true
  },
  allowMultipleSelection: {
    type: Boolean,
    required: true
  },
  translations: [TranslationSchema],
  subQuestions: [SubQuestionSchema],
  numberOfAnswers: {
    type: Number,
    required: false
  }
});

export default QuestionSchema;