import { Document } from "mongoose";
import { ScenarioResult, PreSurveyResult, PostSurveyResult } from "./Result";

export interface IResultDocument extends Document {
    playerUUID: string;
    languageSelected: string;
    scenarios: ScenarioResult[];
    preSurvey: PreSurveyResult[],
    postSurvey: PostSurveyResult[],
}
