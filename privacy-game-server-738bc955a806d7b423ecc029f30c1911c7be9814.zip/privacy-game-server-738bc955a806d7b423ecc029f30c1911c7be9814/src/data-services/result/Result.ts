export interface PreSurveyResult {
  questionId: String,
  answerId: String,
  timeOnScreenInSeconds: number
  openedWindowDuringGame: Boolean
}

export interface PostSurveyResult {
  questionId: String,
  answerId: String,
  timeOnScreenInSeconds: number
  openedWindowDuringGame: Boolean
}

export interface ScenarioResult {
  scenarioId: String,
  answer: String,
  timeOnScreenInSeconds: number
  openedWindowDuringGame: Boolean
}

export interface Result {
  playerUUID: string;
  languageSelected: string;
  scenarios: ScenarioResult[];
  preSurvey: PreSurveyResult[],
  postSurvey: PostSurveyResult[],
  _id?: string;
}
