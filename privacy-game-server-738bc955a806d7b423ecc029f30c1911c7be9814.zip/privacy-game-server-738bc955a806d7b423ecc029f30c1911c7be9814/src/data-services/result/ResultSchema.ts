import { Schema } from "mongoose";

const PreSurveySchema: Schema = new Schema({
  questionId: {
    type: String,
    required: true
  },
  answerId: {
    type: String,
    required: true
  },
  timeOnScreenInSeconds: {
    type: Number,
    required: true
  }
})

const PostSurveySchema: Schema = new Schema({
  questionId: {
    type: String,
    required: true
  },
  answerId: {
    type: String,
    required: true
  },
  timeOnScreenInSeconds: {
    type: Number,
    required: true
  }
})

const ScenarioSchema: Schema = new Schema({
  scenarioId: {
    type: String,
    required: true
  },
  answer: {
    type: String,
    required: true
  },
  timeOnScreenInSeconds: {
    type: Number,
    required: true
  }
})

export const ResultSchema: Schema = new Schema({
  playerUUID: {
    type: String,
    required: true
  },
  languageSelected: {
    type: String,
    required: true
  },
  preSurvey: [PreSurveySchema],
  postSurvey: [PostSurveySchema],
  scenarios: [ScenarioSchema]
});

export default ResultSchema;