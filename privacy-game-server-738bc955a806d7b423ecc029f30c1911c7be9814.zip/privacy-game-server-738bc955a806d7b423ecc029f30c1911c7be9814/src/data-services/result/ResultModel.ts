import { Model } from "mongoose";
import { IResultDocument } from "./IResultDocument";
import { ResultSchema } from "./ResultSchema";

import Database from "../Connection";

export type ResultSchemaModelType = Model<IResultDocument>;

export const ResultModel: ResultSchemaModelType = Database.mongooseConnection.model<IResultDocument>("result", ResultSchema);
