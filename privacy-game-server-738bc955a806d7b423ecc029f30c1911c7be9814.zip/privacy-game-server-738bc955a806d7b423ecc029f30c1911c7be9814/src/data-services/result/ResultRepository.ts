import { ResultModel } from "./ResultModel";
import { IResultDocument } from './IResultDocument';
import RepositoryBase from "../BaseRepository";

class ResultRepository extends RepositoryBase<IResultDocument> {
  constructor() {
    super(ResultModel);
  }
}

Object.seal(ResultRepository);

export default ResultRepository;
