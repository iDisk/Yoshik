import { Answer } from "../answer/Answer";
import { Translation } from "../translation/Translation";

export interface SubQuestion {
  _id?: string;
  text: string;
  answers?: Answer[];
  translations?: Translation[];
}
