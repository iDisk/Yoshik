import { Document } from "mongoose";
import { SubQuestion } from './SubQuestion';
import { IAnswerDocument } from "../answer/IAnswerDocument";
import { ITranslationDocument } from "../translation/ITranslationDocument";

export interface ISubQuestionDocument extends Document {
    text: string;
    answers?: IAnswerDocument[];
    translations?: ITranslationDocument[];
}
