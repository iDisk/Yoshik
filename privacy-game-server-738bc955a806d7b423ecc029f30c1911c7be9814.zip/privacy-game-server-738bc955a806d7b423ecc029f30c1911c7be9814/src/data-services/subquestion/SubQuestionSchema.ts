import { Schema } from "mongoose";
import { TranslationSchema } from "../translation/TranslationSchema";
import { AnswerSchema } from "../answer/AnswerSchema";

export const SubQuestionSchema: Schema = new Schema({
  text: {
    type: String,
    required: true
  },
  translations: [TranslationSchema],
  answers: [AnswerSchema]
});

export default SubQuestionSchema;
