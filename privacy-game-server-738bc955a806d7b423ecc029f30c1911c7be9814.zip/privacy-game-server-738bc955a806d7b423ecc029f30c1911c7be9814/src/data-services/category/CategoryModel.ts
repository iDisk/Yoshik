import { Model } from "mongoose";
import { ICategoryDocument } from "./ICategoryDocument";
import { CategorySchema } from "./CategorySchema";

import Database from "../Connection";

export type CategoryModelType = Model<ICategoryDocument>;

export const CategoryModel: CategoryModelType = Database.mongooseConnection.model<ICategoryDocument>("category", CategorySchema);
