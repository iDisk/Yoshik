import { CategoryModel } from "./CategoryModel";
import { ICategoryDocument } from "./ICategoryDocument";

import RepositoryBase from "../BaseRepository";

class CategoryRepository extends RepositoryBase<ICategoryDocument> {
    constructor() {
        super(CategoryModel);
    }
}

Object.seal(CategoryRepository);

export default CategoryRepository;
