import { Schema } from "mongoose";

export const CategorySchema: Schema = new Schema({
  text: {
    type: String,
    required: true
  }
});

export default CategorySchema;
