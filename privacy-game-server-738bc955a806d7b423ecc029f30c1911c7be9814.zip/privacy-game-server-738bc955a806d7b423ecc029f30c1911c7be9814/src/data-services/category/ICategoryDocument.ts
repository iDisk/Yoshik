import { Document } from "mongoose";
import { Category } from "./Category";

export interface ICategoryDocument extends Category, Document {

}
