export interface Category {
    text: string;
}
