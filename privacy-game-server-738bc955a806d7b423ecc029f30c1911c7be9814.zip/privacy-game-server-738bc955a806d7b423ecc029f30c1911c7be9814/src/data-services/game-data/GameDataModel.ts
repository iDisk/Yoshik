import { Model } from "mongoose";
import { IGameDataDocument } from "./IGameDataDocument";
import { GameDataSchema } from "./GameDataSchema";

import Database from "../Connection";

export type GameDataSchemaModelType = Model<IGameDataDocument>;

export const GameDataModel: GameDataSchemaModelType = Database.mongooseConnection.model<IGameDataDocument>("gamedata", GameDataSchema);
