import { Document } from "mongoose";
import { SurveyData, SceneData } from "./GameData";

export interface IGameDataDocument extends Document {
    language: string;
    preSurvey: SurveyData[];
    postSurvey: SurveyData[];
    scenes: SceneData[];
}

