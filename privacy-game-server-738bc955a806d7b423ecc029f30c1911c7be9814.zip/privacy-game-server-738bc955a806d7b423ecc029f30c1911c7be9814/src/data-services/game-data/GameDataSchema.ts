import { Schema } from "mongoose";

const SceneDataSchema: Schema = new Schema({
  scenarioId: {
    type: String,
    required: true
  },
  scenarioTitle: {
    type: String,
    required: true
  },
  scenarioText: {
    type: String,
    required: true
  },
  order: {
    type: Number,
    required: true
  },
  learningComponentId: {
    type: String,
    required: true
  },
  learningComponentTitle: {
    type: String,
    required: true
  },
  learningComponentText: {
    type: String,
    required: true
  },
  nextScenarioIfYesId: {
    type: String,
    required: true
  },
  nextScenarioIfNoId: {
    type: String,
    required: true
  },
})

const AnswerDataSchema: Schema = new Schema({
  answerId: {
    type: String,
    required: true
  },
  answerText: {
    type: String,
    required: false
  },
  score: {
    type: Number,
    required: true
  },
  isLastFixed: {
    type: Boolean,
    required: true
  }
})
const SurveyDataSchema: Schema = new Schema({
  questionOrder: {
    type: Number,
    required: true
  },
  questionId: {
    type: String,
    required: true
  },
  questionType: {
    type: String,
    required: true
  },
  questionText: {
    type: String,
    required: true
  },
  allowMultipleSelection: {
    type: Boolean,
    required: true
  },
  randomiseAnswers: {
    type: Boolean,
    required: true
  },
  subQuestionText: {
    type: String,
    required: false
  },
  answers: [AnswerDataSchema]
})

export const GameDataSchema: Schema = new Schema({
  language: {
    type: String,
    required: true
  },
  preSurvey: [SurveyDataSchema],
  postSurvey: [SurveyDataSchema],
  scenes: [SceneDataSchema]
});

export default GameDataSchema;
