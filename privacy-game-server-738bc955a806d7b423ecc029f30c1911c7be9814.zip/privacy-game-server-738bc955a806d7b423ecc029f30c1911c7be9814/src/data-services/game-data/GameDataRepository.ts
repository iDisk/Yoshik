import { GameDataModel } from "./GameDataModel";
import { IGameDataDocument } from './IGameDataDocument';
import RepositoryBase from "../BaseRepository";

class GameDataRepository extends RepositoryBase<IGameDataDocument> {
  constructor() {
    super(GameDataModel);
  }
}

Object.seal(GameDataRepository);

export default GameDataRepository;
