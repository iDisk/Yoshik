export interface GameData {
  language: string;
  preSurvey: SurveyData[];
  postSurvey: SurveyData[];
  scenes: SceneData[];
}

export interface SurveyData {
  questionOrder: number;
  questionId: String;
  questionType: String; // enum
  questionText: String;
  allowMultipleSelection: Boolean;
  randomiseAnswers: Boolean;
  answers: AnswerData[];
  subQuestionText: String;
}

export interface AnswerData {
  answerId: String;
  answerText: String;
  score: number;
  isLastFixed: Boolean;
}

export interface SceneData {
  scenarioId: String;
  scenarioTitle: String; // Free Wifi
  scenarioText: String; // Description
  order: number;
  learningComponentId: String;
  learningComponentTitle: String;
  learningComponentText: String; // VPN-Tor
  nextScenarioIfYesId: String; // scenarioId (it can be single item)
  nextScenarioIfNoId: String;
}