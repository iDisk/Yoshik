import { TermModel } from "./TermModel";
import { ITermDocument } from './ITermDocument';
import RepositoryBase from "../BaseRepository";

class TermRepository extends RepositoryBase<ITermDocument> {
  private model: any;
  constructor() {
    super(TermModel);
    this.model = TermModel;
  }

  async deleteTranslation(modelId: string, translationId: string) {
    try {
      const model = await this.model.findById(modelId);
      await model.translations.id(translationId).remove();
      await model.save();
    } catch (error) {
      console.log("Error", error)
    }
  }
}

Object.seal(TermRepository);

export default TermRepository;
