import { Schema } from "mongoose";
import { TranslationSchema } from "../translation/TranslationSchema";

export const TermSchema: Schema = new Schema({
  title: {
    type: String,
    required: true
  },
  text: {
    type: String,
    required: true
  },
  translations: [TranslationSchema]
});

export default TermSchema;
