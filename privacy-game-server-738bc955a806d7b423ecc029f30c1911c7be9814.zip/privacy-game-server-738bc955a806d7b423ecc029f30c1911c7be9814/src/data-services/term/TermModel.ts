import { Model, Document } from "mongoose";
import { ITermDocument } from "./ITermDocument";
import { TermSchema } from "./TermsSchema";

import Database from "../Connection";

export type TermModelType = Model<ITermDocument>;

export const TermModel: TermModelType = Database.mongooseConnection.model<ITermDocument & Document>("term", TermSchema);
