import { Document } from "mongoose";

export interface ITermDocument extends Document {
    text: string;
    title: string;
    order: number;
}
