import Mongoose from "mongoose";

const DB_CONNECTION_STRING: string = "mongodb://edson:edson123@ds143242.mlab.com:43242/privacygamedb";
console.log("Environment", DB_CONNECTION_STRING);

class DataAccess {
  static mongooseInstance: any;
  static mongooseConnection: Mongoose.Connection;

  static async connect(): Promise<Mongoose.Connection> {
    if (this.mongooseInstance) {
      return this.mongooseInstance;
    }

    this.mongooseConnection = Mongoose.connection;
    this.mongooseConnection.once("open", () => {
      console.log("Connected to mongodb.");
    });

    this.mongooseInstance = await Mongoose.connect(DB_CONNECTION_STRING);
    return this.mongooseInstance;
  }
}

DataAccess.connect();

export default DataAccess;
