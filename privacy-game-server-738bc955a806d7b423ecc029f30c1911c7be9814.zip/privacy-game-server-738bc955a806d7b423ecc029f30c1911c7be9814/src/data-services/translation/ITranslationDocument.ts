import { Document } from "mongoose";
import { IAnswerDocument } from "../answer/IAnswerDocument";

export interface ITranslationDocument extends Document {
    text: string;
    language: string;
    answers?: IAnswerDocument[];
}
