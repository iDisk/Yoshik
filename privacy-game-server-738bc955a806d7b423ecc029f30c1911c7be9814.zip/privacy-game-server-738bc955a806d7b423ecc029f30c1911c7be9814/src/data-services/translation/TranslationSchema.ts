import { Schema } from "mongoose";
import { AnswerSchema } from "../answer/AnswerSchema";

export const TranslationSchema: Schema = new Schema({
  text: {
    type: String,
    required: true
  },
  language: {
    type: String,
    required: true
  },
  answers: [AnswerSchema]
});

export default TranslationSchema;
