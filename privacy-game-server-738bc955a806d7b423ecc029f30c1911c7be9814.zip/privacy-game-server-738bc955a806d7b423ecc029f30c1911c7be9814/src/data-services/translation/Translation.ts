import { Answer } from "../answer/Answer";

export interface Translation {
  _id?: string;
  text: string;
  language: string;
  answers?: Answer[]
}
