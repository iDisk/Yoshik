import { Document, Model, Types } from "mongoose";
import IRead from "./interfaces/base/Read";
import IWrite from "./interfaces/base/Write";

class RepositoryBase<T extends Document> implements IRead<T>, IWrite<T> {
  private _model: Model<T>;

  constructor(schemaModel: Model<T>) {
    this._model = schemaModel;
  }

  async create(item: T) {
    return await this._model.create(item);
  }

  async retrieve(query: {} = {}): Promise<T[]> {
    const result = this._model.find(query);
    return await result.sort({ order: 1 }).exec();
  }

  async update(_id: string, item: T) {
    return await this._model.update({ _id: this.toObjectId(_id) }, item).exec();
  }

  async delete(_id: string) {
    return await this._model.remove({ _id: this.toObjectId(_id) }).exec();
  }

  async findById(_id: string): Promise<T | null> {
    return await this._model.findById(_id).exec();
  }

  private toObjectId(_id: string): Types.ObjectId {
    return Types.ObjectId.createFromHexString(_id);
  }
}

export default RepositoryBase;
