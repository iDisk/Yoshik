import { Translation } from "../translation/Translation";

export interface Scenario {
  _id?: string;
  text: string;
  title: string;
  order: number;
  translations: Translation[]
}
