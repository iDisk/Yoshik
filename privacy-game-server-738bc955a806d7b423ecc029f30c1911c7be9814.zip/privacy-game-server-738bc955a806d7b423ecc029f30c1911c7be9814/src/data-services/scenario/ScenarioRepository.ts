import { ScenarioModel } from "./ScenarioModel";
import { IScenarioDocument } from './IScenarioDocument';
import RepositoryBase from "../BaseRepository";

class ScenarioRepository extends RepositoryBase<IScenarioDocument> {
  private model: any;
  constructor() {
    super(ScenarioModel);
    this.model = ScenarioModel;
  }
  async deleteTranslation(modelId: string, translationId: string) {
    try {
      const model = await this.model.findById(modelId);
      await model.translations.id(translationId).remove();
      await model.save();
    } catch (error) {
      console.log("Error", error)
    }
  }
}

Object.seal(ScenarioRepository);

export default ScenarioRepository;
