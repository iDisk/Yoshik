import { Document } from "mongoose";
import { ITranslationDocument } from "../translation/ITranslationDocument";

export interface IScenarioDocument extends Document {
    text: string;
    title: string;
    order: number;
    translations: ITranslationDocument[]
}
