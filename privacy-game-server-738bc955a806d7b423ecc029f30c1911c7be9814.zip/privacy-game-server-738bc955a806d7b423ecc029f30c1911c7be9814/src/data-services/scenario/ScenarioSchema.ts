import { Schema } from "mongoose";
import { TranslationSchema } from "../translation/TranslationSchema";

export const ScenarioSchema: Schema = new Schema({
  text: {
    type: String,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  order: {
    type: Number,
    required: true
  },
  translations: [TranslationSchema]
});

export default ScenarioSchema;
