import { Model } from "mongoose";
import { IScenarioDocument } from "./IScenarioDocument";
import { ScenarioSchema } from "./ScenarioSchema";

import Database from "../Connection";

export type ScenarioSchemaModelType = Model<IScenarioDocument>;

export const ScenarioModel: ScenarioSchemaModelType = Database.mongooseConnection.model<IScenarioDocument>("scenario", ScenarioSchema);
