import { Schema } from "mongoose";

export const AnswerSchema: Schema = new Schema({
  text: {
    type: String,
    required: false
  },
  score: {
    type: Number,
    required: true
  },
  isLastFixed: {
    type: Boolean,
    required: true
  }
});

export default AnswerSchema;
