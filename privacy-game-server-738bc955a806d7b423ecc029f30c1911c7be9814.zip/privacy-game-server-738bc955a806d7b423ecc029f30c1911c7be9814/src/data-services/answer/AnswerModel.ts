import { Model } from "mongoose";
import { IAnswerDocument } from "./IAnswerDocument";
import { AnswerSchema } from "./AnswerSchema";

import Database from "../Connection";

export type AnswerModelType = Model<IAnswerDocument>;

export const AnswerModel: AnswerModelType = Database.mongooseConnection.model<IAnswerDocument>("answer", AnswerSchema);
