import { Document } from "mongoose";
import { Answer } from './Answer';

export interface IAnswerDocument extends Answer, Document {

}
