export interface Answer {
  text?: string;
  score: number;
  isLastFixed?: boolean;
}
