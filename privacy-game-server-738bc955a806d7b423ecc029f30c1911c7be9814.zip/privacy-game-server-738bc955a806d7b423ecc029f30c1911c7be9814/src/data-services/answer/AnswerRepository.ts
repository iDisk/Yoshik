import { AnswerModel } from "./AnswerModel";
import { IAnswerDocument } from './IAnswerDocument';
import RepositoryBase from "../BaseRepository";

class AnswerRepository extends RepositoryBase<IAnswerDocument> {
  constructor() {
    super(AnswerModel);
  }
}

Object.seal(AnswerRepository);

export default AnswerRepository;
